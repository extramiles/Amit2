



	package com.module;

	import static org.testng.Assert.assertEquals;

	import java.io.File;
	import java.io.FileInputStream;
	import java.io.FileNotFoundException;
	import java.io.FileOutputStream;
	import java.io.IOException;
	import java.util.Date;
	import java.util.LinkedHashMap;
	import java.util.Map;
	import java.util.Set;

	import org.apache.log4j.PropertyConfigurator;
	import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
	import org.apache.poi.ss.usermodel.Cell;
	import org.apache.poi.ss.usermodel.Row;
	import org.apache.poi.xssf.usermodel.XSSFCell;
	import org.apache.poi.xssf.usermodel.XSSFRow;
	import org.apache.poi.xssf.usermodel.XSSFSheet;
	import org.apache.poi.xssf.usermodel.XSSFWorkbook;
	import org.openqa.selenium.WebElement;
	import org.testng.Assert;
	import org.testng.ITestContext;
	import org.testng.ITestResult;
	import org.testng.Reporter;
	import org.testng.annotations.AfterClass;
	import org.testng.annotations.AfterMethod;
	import org.testng.annotations.BeforeClass;
	import org.testng.annotations.BeforeMethod;
	import org.testng.annotations.DataProvider;
	import org.testng.annotations.Listeners;
	import org.testng.annotations.Test;

	import com.excelutils.ReadingExcel;
	import com.opusbase.TestBase;



	public class Mobile extends SuperTestNG {

		
		@Test
		public void Wireless_Activations() throws IOException{
			//Object[] key =getDataFromExcel("Navigate_to_home_page","Sheet1");
			Reporter.log("select store D111 from DropDown");
			//Assert.assertEquals(sc.getStoreSelectionPageTitle(),"OPUS Login");
			sc.selectDropDownsd("D111");
			fullPageScreenShot("Wireless_Activation");
			Reporter.log("click ok button");
			sc.click();
			fullPageScreenShot("Wireless_Activation");
			lpa.enterUserName("ns788e");
			Reporter.log("enter username");
			fullPageScreenShot("Wireless_Activation");
			lpa.enterPassword("unix11");
			Reporter.log("enter password");
			fullPageScreenShot("Wireless_Activation");
			lpa.click();
			Reporter.log("click ok button");
			fullPageScreenShot("Wireless_Activation");
			rmlpa.click();
			hpa.switchToFrameHomePage();
			hpa.click();
			fullPageScreenShot("Wireless_Activation");
			hpa.clickTo();
			hpa.enterAddressLineOne("1202 main st");
			hpa.setCityValue("Dallas");
			hpa.selectStateHomePage("Texas");
			hpa.setZipCodeHomePage("75202");
			hpa.clickToCheckAvailability();
			cpni.clickTo();
			cpni.clickNextButton();
			pca.SelectWireless();
			pca.SetPortNumberNo();
			pca.ClickBeginOrder();
			ci.selectIndividualPostPaidPlan();
			ci.selectTaxExemptAsNo();
			ci.declineScan();
			ci.selectReasonForByPass("Customer Declined Scan");
			ci.setCustomerFirstName("nit");
			ci.setCustomerLastName("singh");
			ci.setCustomerDOB("01", "28", "1950");
			ci.setSSNNumber("123", "45", "6789");
			ci.confirmSSNNumber("123","45","6789");
			ci.selectLicenseState("Texas");
			ci.setLicenseNumber("1234567890");
			ci.setLicenseExpDate("01", "01", "2020");
			ci.setHomePhoneNumber("834", "350", "2257");
			ci.setWorkPhoneNumber("870", "250", "2260", "1111");
			ci.setPrimaryEmailAddress("ns788e@att.com");
			ci.setEmployerName("nss");
			if(ci.streetNum.isEnabled())
			{
			ci.setStreetNumber("1202");
			ci.setStreetName("main st");
			ci.setCity("Dallas");
			ci.setState("Texas");
			ci.setZipCode("75202");
			}
			ci.setAccountPasscode("1234");
			ci.setReAccountPasscode("1234");
			ci.clickNext();
			ci.clickOnAddressValidationPopUp();
			si.setSelectServiceLocation("GRANDPRARI TX");
			//GRANDPRARI TX  GREENVILLE TX
			si.clickBtnFindReqNum();
			si.setSelectAvailWlsNum();
			si.clickBtnReserveNum();
			si.setTextSimNumber("89014104259999989798");
			si.setTextIMEI("012421000000000");
			si.clickBtnNext();
			//rp.clickNewGroup();
			rp.selecPlanType("Mobile Share");
			//#Mobile Share
			rp.selectPlan("M");
			rp.clickAddPlan();
			//rp.clickServiceContractPlans();
			//rp.selectContratcLength("12 MONTHS COMMITMENT");
			rp.clickNoCommitmentPlan();
			rp.clickContinueBtn();
			de.clickSkip();
			dd.clickNext();
			rap.clickActivate();
			sp.clickPaperLessNo();
			sp.clickFinished();
			nspp.setRadioNo();
			nspp.clickBtnOk();
			co.clickonCheckOut();
			co.clickonViewSummary();
			wca.setChkboxWcaAcknowledged();
			wca.clickBtnSkip();
			wcap.clickBtnWcaStation();
			Reporter.log("Test Case Passed");
			
			}
	}
		

