package com.module.wireless;

import java.io.IOException;

import org.testng.Reporter;
import org.testng.TestNG;
import org.testng.annotations.Test;

import com.module.SuperTestNG;

public class WirelessActivation05 extends SuperTestNG {

		
	@Test
	public void Wireless_Activation() throws IOException{
	//Object[] key =getDataFromExcel("Navigate_to_home_page","Sheet1");
			Reporter.log("select store D111 from DropDown");
			//Assert.assertEquals(sc.getStoreSelectionPageTitle(),"OPUS Login");
			sc.selectDropDownsd("D112");
			fullPageScreenShot("Wireless_Activation");
			Reporter.log("click ok button");
			sc.click();
			fullPageScreenShot("Wireless_Activation");
			lpa.enterUserName("ns788e");
			Reporter.log("enter username");
			fullPageScreenShot("Wireless_Activation");
			lpa.enterPassword("unix11");
			Reporter.log("enter password");
			fullPageScreenShot("Wireless_Activation");
			lpa.click();
			Reporter.log("click ok button");
			fullPageScreenShot("Wireless_Activation");
			rmlpa.click();
			hpa.switchToFrameHomePage();
			hpa.click();
			fullPageScreenShot("Wireless_Activation");
			hpa.clickTo();
			hpa.enterAddressLineOne("1202 main st");
			hpa.setCityValue("Dallas");
			hpa.selectStateHomePage("Texas");
			hpa.setZipCodeHomePage("75202");
			hpa.clickToCheckAvailability();
			cpni.clickTo();
			cpni.clickNextButton();
			pca.SelectWireless();
			pca.SetPortNumberNo();
			pca.ClickBeginOrder();
			ci.selectIndividualPostPaidPlan();
			ci.selectTaxExemptAsNo();
			ci.clickOnFANCheckBox();
			ci.setFANNumber("2399770");
			//For D111 store only
			//ci.selectEligibilityProof("Manager Exception Override");
			//ci.clickOnIruConfirmCheckBox();
			//ci.declineScan();
			ci.declineScan();
			ci.selectReasonForByPass("Customer Declined Scan");
			ci.setCustomerFirstName("nit");
			ci.setCustomerLastName("singh");
			ci.setCustomerDOB("01", "28", "1950");
			ci.setSSNNumber("123", "45", "6789");
			ci.confirmSSNNumber("123","45","6789");
			ci.selectLicenseState("Texas");
			ci.setLicenseNumber("1234567890");
			ci.setLicenseExpDate("01", "01", "2020");
			ci.setHomePhoneNumber("834", "350", "2257");
			ci.selectHomeContactPreference("No");
			ci.setWorkPhoneNumber("870", "250", "2260", "1111");
			ci.selectWorkContactPreference("No");
			ci.setPrimaryEmailAddress("ns788e@att.com");
			ci.setEmployerName("nss");
			if(ci.streetNum.isEnabled())
			{
			ci.setStreetNumber("1202");
			ci.setStreetName("main st");
			ci.setCity("Dallas");
			ci.setState("Texas");
			ci.setZipCode("75202");
			}
			ci.setAccountPasscode("1234");
			ci.setReAccountPasscode("1234");
			ci.clickNext();
			ci.clickOnAddressValidationPopUp();
			si.setSelectServiceLocation("GRANDPRARI TX");
			//GRANDPRARI TX  GREENVILLE TX
			si.clickBtnFindReqNum();
			si.setSelectAvailWlsNum();
			si.clickBtnReserveNum();
			si.setTextSimNumber("89014104259999989798");
			si.setTextIMEI("012421000000000");
			si.clickBtnNext();
			//rp.clickNewGroup();
			rp.selecPlanType("Individual Plan");
			//#Mobile Share
			rp.selectPlan("NNNN");
			rp.clickAddPlan();
			rp.clickServiceContractPlans();
			//rp.selectContratcLength("12 MONTHS COMMITMENT");
			rp.clickNoCommitmentPlan();
			rp.clickContinueBtn();
			de.clickSkip();
			dd.clickNext();
			rap.clickActivate();
			sp.clickPaperLessNo();
			sp.clickFinished();
			nspp.setRadioNo();
			nspp.clickBtnOk();
			co.clickonCheckOut();
			co.clickonViewSummary();
//			wca.setChkboxWcaAcknowledged();
//			wca.clickBtnSkip();
//			wcap.clickBtnWcaStation();
			co.clickonCheckOutIRU();
			tp.setSelectApprover("aa101d");
			tp.setTextPassword("unix11");
			tp.clickSubmitButton();
			tc.clickOnEmailCheck();
			tc.clickOnPrintCheck();
			tc.clickOnDoneButton();
			Reporter.log("Test Case Passed");
			/*try{
				//assertEquals(true, false);
				testresultdata.put("2",new Object[] {1d, "Navigate_to_home_page", "page opens and login success","Pass"});
				
			}catch(Exception e){
				testresultdata.put("2
				",new Object[] {1d, "Navigate_to_home_page", "page opens and login success","Fail"});
			}*/
}
}
			