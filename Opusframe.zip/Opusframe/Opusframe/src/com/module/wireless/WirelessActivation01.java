package com.module.wireless;

import java.io.IOException;

import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.Test;

import com.google.common.base.Verify;
import com.module.SuperTestNG;

public class WirelessActivation01 extends SuperTestNG{
	
	@Test
	public void Wireless_Activation() throws IOException{
		String[] key =getDataFromExcel("Wireless_Activation","Sheet1");
		
		sc.selectDropDownsd(key[0]);
		Assert.assertEquals(sc.getStoreSelectionPageTitle(),"OPUS Login");
		fullPageScreenShot("Wireless_Activation");
	
		sc.click();
		lpa.enterUserName(key[1]);
		lpa.enterPassword(key[2]);
		
		fullPageScreenShot("Wireless_Activation");
		lpa.click();
	
		Reporter.log("Login successful wirelessTest01_01");
		fullPageScreenShot("Wireless_Activation");
		rmlpa.click();
		
		hpa.switchToFrameHomePage();
		hpa.click();
	
		//fullPageScreenShot("Wireless_Activation");
		hpa.clickTo();
		
		hpa.enterAddressLineOne(key[3]);
		
		//fullPageScreenShot("Wireless_Activation");
		hpa.setCityValue(key[4]);
	
		hpa.selectStateHomePage(key[5]);
		
		hpa.setZipCodeHomePage(key[6]);
		
		//fullPageScreenShot("Wireless_Activation");
		hpa.clickToCheckAvailability();
		
		cpni.clickTo();
		Reporter.log("CPNI page shall be displayed wirelessTest01_02");
	
		cpni.clickNextButton();
		Reporter.log("PCA page shall be displayed wirelessTest01_03");
		pca.SelectWireless();
	
		pca.SetPortNumberNo();
		
		pca.ClickBeginOrder();
		Reporter.log("Customer information page shall be displayed wirelessTest01_04");
		ci.selectIndividualPostPaidPlan();
		
		ci.selectTaxExemptAsNo();
	
		ci.declineScan();
		
		ci.selectReasonForByPass(key[7]);
	
		ci.setCustomerFirstName(key[8]);
	
		ci.setCustomerLastName(key[9]);
	
		ci.setCustomerDOB(key[10], key[11], key[12]);
		
		ci.setSSNNumber(key[13], key[14],key[15]);
		
		ci.confirmSSNNumber(key[16],key[17],key[18]);
	
		ci.selectLicenseState(key[19]);

		ci.setLicenseNumber(key[20]);
	
		ci.setLicenseExpDate(key[21], key[22], key[23]);
		
		ci.setHomePhoneNumber(key[24], key[25], key[26]);
	
		ci.setWorkPhoneNumber(key[27],key[28], key[29], key[30]);
	
		ci.setPrimaryEmailAddress(key[31]);
	
		ci.setEmployerName(key[32]);
	
		if(ci.streetNum.isEnabled())
		{
		ci.setStreetNumber(key[33]);
		ci.setStreetName(key[34]);
		ci.setCity(key[35]);
		ci.setState(key[36]);
		ci.setZipCode(key[37]);
		}

		ci.setAccountPasscode(key[38]);
	
		ci.setReAccountPasscode(key[39]);
	
		ci.clickNext();
		Reporter.log("Address validation pop up shall be displayed wirelessTest01_05");
		ci.clickOnAddressValidationPopUp();
		Reporter.log("Service and device page shall be displayed wirelessTest01_06");
		si.setSelectServiceLocation(key[40]);
	
		//GRANDPRARI TX  GREENVILLE TX
		si.clickBtnFindReqNum();
		Reporter.log("Available subscriber numbers shall be displayed in list wirelessTest01_07" );
		si.setSelectAvailWlsNum();
	
		si.clickBtnReserveNum();
		Reporter.log("Selected number shall be reserved wirelessTest01_08" );
		si.setTextSimNumber(key[41]);
	
		si.setTextIMEI(key[42]);

		//fullPageScreenShot("Wireless_Activation");
		si.clickBtnNext();
		//rp.clickNewGroup();
		Reporter.log("Rate plan and feature page shall be displayed wirelessTest01_09");
		rp.selecPlanType(key[43]);
	
		//#Mobile Share
		rp.selectPlan(key[44]);
		Reporter.log("Selected plan shall be dispalyed alon with contract type and associated features wirelessTest01_10");
		rp.clickAddPlan();
	
		//fullPageScreenShot("Wireless_Activation");
	//	rp.clickServiceContractPlans();
		//rp.selectContratcLength("12 MONTHS COMMITMENT");
		rp.clickNoCommitmentPlan();
	
		rp.clickContinueBtn();
		Reporter.log("Device protection enrollment page shall be displayed  wirelessTest01_11");
		//fullPageScreenShot("Wireless_Activation");
		de.clickSkip();
		Reporter.log("Decline device protection page shall be displayed wirelessTest01_12" );
		dd.clickNext();
		Reporter.log("Review and Activate page shall be displayed wirelessTest01_13");
		rap.clickActivate();
		Reporter.log("Summary page shall be displayed wirelessTest01_14");
		sp.clickPaperLessNo();
		Reporter.log("CSS shall be generated in new window wirelessTest01_15" );  //need to update
		sp.clickFinished();
		
		nspp.setRadioNo();
		
		nspp.clickBtnOk();
		
		co.clickonCheckOut();
		co.clickonViewSummary();
		Reporter.log("Customer summary page shall be displayed wirelessTest01_16");
		Reporter.log("Tax Type and Tax Information page shall be displayed wirelessTest01_17");
		wca.setChkboxWcaAcknowledged();
	
		wca.clickBtnSkip();
		Reporter.log("Transaction complete popup shall be displayed wirelessTest01_18");
		fullPageScreenShot("Wireless_Activation");
		wcap.clickBtnWcaStation();
		Reporter.log("Transaction completed page shall be displayed wirelessTest01_19" );
		String tid = tc.getTransactionId();
		String db_tid= verifyTransactions(tid, 1);
		Assert.assertEquals(tid, db_tid);
		//Verify.
		Reporter.log("Transaction shall be logged in the database wirelessTest01_20");
		Reporter.log("Test Case Passed");
	}


}
