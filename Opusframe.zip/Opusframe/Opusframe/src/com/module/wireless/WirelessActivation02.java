package com.module.wireless;

import java.io.IOException;

import org.testng.Reporter;
import org.testng.annotations.Test;

import static org.testng.Assert.assertEquals;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.PropertyConfigurator;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.ITestContext;
import org.testng.ITestResult;
import org.testng.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.excelutils.ReadingExcel;
import com.module.SuperTestNG;
import com.opusbase.TestBase;


public class WirelessActivation02 extends SuperTestNG {

	
	@Test
	public void goPhoneActivation() throws IOException{
		//Object[] key =getDataFromExcel("Navigate_to_home_page","Sheet1");
		Reporter.log("select store D111 from DropDown");
		//Assert.assertEquals(sc.getStoreSelectionPageTitle(),"OPUS Login");
		sc.selectDropDownsd("D111");
		fullPageScreenShot("Wireless_Activation");
		Reporter.log("click ok button");
		sc.click();
		fullPageScreenShot("Wireless_Activation");
		lpa.enterUserName("ns788e");
		Reporter.log("enter username");
		fullPageScreenShot("Wireless_Activation");
		lpa.enterPassword("unix11");
		Reporter.log("enter password");
		fullPageScreenShot("Wireless_Activation");
		lpa.click();
		Reporter.log("click ok button");
		fullPageScreenShot("Wireless_Activation");
		rmlpa.click();
		hpa.switchToFrameHomePage();
		hpa.click();
		fullPageScreenShot("Navigate_to_home_page");
		hpa.clickTo();
		hpa.enterAddressLineOne("1202 main st");
		hpa.setCityValue("Dallas");
		hpa.selectStateHomePage("Texas");
		hpa.setZipCodeHomePage("75202");
		hpa.clickToCheckAvailability();
		cpni.clickTo();
		cpni.clickNextButton();
		pca.SelectWireless();
		pca.SelectPPrepaidPlan();
		pca.SetPortNumberNo();
		pca.ClickBeginOrder();
		ci.selectpayAsYouGoPlan();
		
		
		ci.setCustomerFirstName("nit");
		ci.setCustomerLastName("singh");
		
		ci.setHomePhoneNumber("834", "350", "2257");
		ci.setWorkPhoneNumber("870", "250", "2260", "1111");
		ci.setPrimaryEmailAddress("ns788e@att.com");
		ci.setEmployerName("nss");
		/*if(ci.streetNum.isEnabled())
		{
		ci.setStreetNumber("1202");
		ci.setStreetName("main st");
		ci.setCity("Dallas");
		ci.setState("Texas");
		ci.setZipCode("75202");
		}*/
		
		ci.clickNext();
		ci.clickOnAddressValidationPopUp();
		
		si.setSelectServiceLocation("GRANDPRARI TX");
		//GRANDPRARI TX  GREENVILLE TX
		si.clickBtnFindReqNum();
		si.setSelectAvailWlsNum();
		si.clickBtnReserveNum();
		si.setTextSimNumber("89014104259999989798");
		si.setTextIMEI("012421000000000");
		si.clickBtnNext();
		rp.selecPlanType("Individual Plan");
		rp.selectPlan("$$$$$");
		rp.clickAddPlan();
		rp.clickNoCommitmentPlan();
		rp.clickContinueBtn();
		rap.clickActivate();
		sp.clickPinPurchase();
		sp.clickNextGoPh();
		
		spp.clickTenPin();
		spp.selectOptionNowAndLater("Print PIN For Later Use");
		spp.clickAddToCart();
		//spp.selectPayment("P");
		//spp.clickAddToCart();
		spp.clickPayNowCart();
		spp.clickPayNowCSCart();
		tp.clickSubmitButton();
		cgp.clickCash();
		cgp.enterCashAmount("16.54");
		cgp.clickSubmit();
		tc.clickOnDoneButton();
		
		//csp.clickBtnView();
		
		
		
		Reporter.log("Test Case Passed");
		//tear();
		//hpa.clickOnSales();
		
		///hpa.getSalesOptions("Sell Item");
		
		
		/*try{
			//assertEquals(true, false);
			testresultdata.put("2",new Object[] {1d, "Navigate_to_home_page", "page opens and login success","Pass"});
			
		}catch(Exception e){
			testresultdata.put("2
			",new Object[] {1d, "Navigate_to_home_page", "page opens and login success","Fail"});
		}
*/
	}

	
}