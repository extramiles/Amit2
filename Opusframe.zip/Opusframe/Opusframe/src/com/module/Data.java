package com.module;

import java.io.IOException;

import org.testng.Reporter;
import org.testng.annotations.Test;

public class Data extends SuperTestNG{

	@Test
	public void Wireless_Activation() throws IOException{
		
		String[] key =getDataFromExcel("Wireless_Activation","Sheet1");
		Reporter.log("select store D111 from DropDown");
		//Assert.assertEquals(sc.getStoreSelectionPageTitle(),"OPUS Login");
		sc.selectDropDownsd(key[0]);
		fullPageScreenShot("Wireless_Activation");
		Reporter.log("click ok button");
		sc.click();
		fullPageScreenShot("Wireless_Activation");
		lpa.enterUserName(key[1]);
		Reporter.log("enter username");
		fullPageScreenShot("Wireless_Activation");
		lpa.enterPassword(key[2]);
		Reporter.log("enter password");
		fullPageScreenShot("Wireless_Activation");
		lpa.click();
		Reporter.log("click ok button");
		fullPageScreenShot("Wireless_Activation");
		rmlpa.click();
		Reporter.log("click ok button");
		hpa.switchToFrameHomePage();
		hpa.click();
		Reporter.log("click ok button");
		//fullPageScreenShot("Wireless_Activation");
		hpa.clickTo();
		Reporter.log("click ok button");
		hpa.enterAddressLineOne(key[3]);
		fullPageScreenShot("Wireless_Activation");
		hpa.setCityValue(key[4]);
		hpa.selectStateHomePage(key[5]);
		hpa.setZipCodeHomePage(key[6]);
		fullPageScreenShot("Wireless_Activation");
		hpa.clickToCheckAvailability();
		cpni.clickTo();
		cpni.clickNextButton();
		pca.SelectWireless();
		pca.SetPortNumberNo();
		pca.ClickBeginOrder();
		ci.selectIndividualPostPaidPlan();
		ci.selectTaxExemptAsNo();
		ci.declineScan();
		ci.selectReasonForByPass(key[7]);
		ci.setCustomerFirstName(key[8]);
		ci.setCustomerLastName(key[9]);
		ci.setCustomerDOB(key[10], key[11], key[12]);
		ci.setSSNNumber(key[13], key[14],key[15]);
		ci.confirmSSNNumber(key[16],key[17],key[18]);
		ci.selectLicenseState(key[19]);
		ci.setLicenseNumber(key[20]);
		ci.setLicenseExpDate(key[21], key[22], key[23]);
		ci.setHomePhoneNumber(key[24], key[25], key[26]);
		ci.setWorkPhoneNumber(key[27],key[28], key[29], key[30]);
		ci.setPrimaryEmailAddress(key[31]);
		ci.setEmployerName(key[32]);
		if(ci.streetNum.isEnabled())
		{
		ci.setStreetNumber(key[33]);
		ci.setStreetName(key[34]);
		ci.setCity(key[35]);
		ci.setState(key[36]);
		ci.setZipCode(key[37]);
		}
		ci.setAccountPasscode(key[38]);
		ci.setReAccountPasscode(key[39]);
		ci.clickNext();
		ci.clickOnAddressValidationPopUp();
		si.setSelectServiceLocation(key[40]);
		//GRANDPRARI TX  GREENVILLE TX
		si.clickBtnFindReqNum();
		si.setSelectAvailWlsNum();
		si.clickBtnReserveNum();
		si.setTextSimNumber(key[41]);
		si.setTextIMEI(key[42]);
		fullPageScreenShot("Wireless_Activation");
		si.clickBtnNext();
		//rp.clickNewGroup();
		rp.selecPlanType(key[43]);
		//#Mobile Share
		rp.selectPlan(key[44]);
		rp.clickAddPlan();
		fullPageScreenShot("Wireless_Activation");
		rp.clickServiceContractPlans();
		//rp.selectContratcLength("12 MONTHS COMMITMENT");
		rp.clickNoCommitmentPlan();
		rp.clickContinueBtn();
		fullPageScreenShot("Wireless_Activation");
		de.clickSkip();
		
		dd.clickNext();
		rap.clickActivate();
		sp.clickPaperLessNo();
		sp.clickFinished();
		nspp.setRadioNo();
		nspp.clickBtnOk();
		co.clickonCheckOut();
		co.clickonViewSummary();
		wca.setChkboxWcaAcknowledged();
		wca.clickBtnSkip();
		fullPageScreenShot("Wireless_Activation");
		wcap.clickBtnWcaStation();
		Reporter.log("Test Case Passed");
		
		//hpa.clickOnSales();
		
		///hpa.getSalesOptions("Sell Item");
		
		
		/*try{
			//assertEquals(true, false);
			testresultdata.put("2",new Object[] {1d, "Navigate_to_home_page", "page opens and login success","Pass"});
			
		}catch(Exception e){
			testresultdata.put("2
			",new Object[] {1d, "Navigate_to_home_page", "page opens and login success","Fail"});
		}
*/
	}
}
