package com.pageobject;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public abstract class CommonPageAction 
{
	WebDriver driver;
	
	public CommonPageAction(WebDriver driver)
	{
		this.driver=driver;
		// TODO Auto-generated constructor stub
		PageFactory.initElements(driver,this);
	}
	
	@FindBy(how=How.XPATH,using="//span[@class='menuIcon sales']")
	private WebElement sales;
	
	@FindBy(how=How.XPATH,using="")
	private WebElement admin;
	
	@FindBy(how=How.XPATH,using="")
	private WebElement queue;
	
	@FindBy(how=How.XPATH,using="//ul[@class='menuList']/li/a")
	private List<WebElement> salesoption;
	
	
	
	public  void clickOnSales(){
		if(sales!=null)
		{
			sales.click();
		}
	};
	
	public  Object clickOnQueue(){
		return queue;
		
	};
	
	
	
	public  Object clickOnAdmin(){
		return admin;
		
	};
	
	public abstract Object click();	
	
	public void getSalesOptions(String option)
	{
		
		for(WebElement e: salesoption)
		{
			System.out.println(e.getText());
			String s=e.getText();
			try{
			if(s.equals(option)){
				e.click();
				break;
			}
			}
			catch(Exception es){
				es.printStackTrace();
			}
		}
	}
	
}
