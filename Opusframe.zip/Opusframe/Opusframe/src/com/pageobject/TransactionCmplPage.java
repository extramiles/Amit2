 /* ClassName            : TransactionCmplPage
  * Description          : This class identify and implement all the web
  *                        element and its corresponding action of Transaction
  *                        complete and Transaction Complete Pop-up page.
  * Version info         : V_0.1
  * Author               : Tech Mahindra
  * Copyright notice     : Tech Mahindra Ltd. 
  */
package com.pageobject;

import java.util.NoSuchElementException;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.utility.Logg;
import com.utility.Util;



public class TransactionCmplPage {
	
	Util u = new Util();
	WebDriver driver = u.getDriver();
	Logger Log = Logg.createLogger();
	
	// Constructor for class TransactionCmplPage
	public TransactionCmplPage(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver,this);
	}
	
	/* Web Element Locator for Transaction Complete Pup-up page */ 
	 
	// Locate to select Print Check
	@FindBy(how=How.ID, using = "printCheck") 
	public WebElement selectPrintCheck;
	
	// Locate to select Email Check
	@FindBy(how=How.ID, using = "emailCheck") 
	public WebElement selectEmailCheck;
	
	// Locate to select Email Check
	@FindBy(how=How.ID, using = "btncreate") 
	public WebElement doneButton;
	
	/* Web Element Locator for Transaction Complete page */ 
	 
	// Locator to click on radio button with same customer option.
	@FindBy(how=How.ID, using = "continue_with_id_1") 
	public WebElement thisCustomerRadioButton ;
	
	// Locator to click on radio button with another session.
	@FindBy(how=How.ID, using = "continue_without_id_2") 
	public WebElement anotherSessionRadioButton;
	
	// Locator to click on continue button.
	@FindBy(how=How.ID, using = "btnContinue") 
	public WebElement continueButton;
	
	// Locator to click on checkout button.
	@FindBy(how=How.ID, using = "opusmobilecheckout") 
	public WebElement checkOutButton;
	
	// Locator to click on checkout button.
	@FindBy(how=How.NAME, using = "blueButton") 
	public WebElement tradeInButton;
	
	
	@FindBy(how=How.XPATH, using = "//div[@id='CartItemsDiv']/div/div[3]//div[@class='receiptID']") 
	public WebElement transReceiptID;
	
	/* Function implementation of page Transaction Completed Pop-up page */
	
	/* Function Name    : clickOnPrintCheck
	 * Description      : This function is used click on Print Check check box.
	 * Parameter        : None
	 * Return           : None 
	 */
	//used in 1706 release   Receipt ID: XD111B7HFDRMB
	public String getTransactionId() {  
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(transReceiptID));
		String transid = null;
		if (transReceiptID!=null) {
			try {
				transid=transReceiptID.getText();
				int inttranid = transid.indexOf('X');
				String transds=transid.substring(inttranid);
				System.out.println(transds);
				transid=transds;
				//int finaltranid =transid.lastIndexOf(arg0)
				Log.info(TaxTypeInfoPage.class.getName()+ " getTransactionId ");
			} catch(NoSuchElementException e) {
				e.printStackTrace();
				Log.info("Failed " + TaxTypeInfoPage.class.getName()
				+ " unable to getTransactionId ");
			}
		}	
		return transid;
	}
	
	
	public void clickOnPrintCheck() {  
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(selectPrintCheck));
		if (selectPrintCheck!=null) {
			try {
				selectPrintCheck.click();
				Log.info(TaxTypeInfoPage.class.getName()+ " button click");
			} catch(NoSuchElementException e) {
				e.printStackTrace();
				Log.info("Failed " + TaxTypeInfoPage.class.getName()
				+ " unable to click on button ");
			}
		}	
	} // function clickOnPrintCheck ends here
	
	/* Function Name    : clickOnEmailCheck
	 * Description      : This function is used click on Print Check check box.
	 * Parameter        : None
	 * Return           : None 
	 */
	public void clickOnEmailCheck() { 
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(selectEmailCheck));
		if (selectEmailCheck!=null) {
			try {
				selectPrintCheck.click();
				Log.info(TaxTypeInfoPage.class.getName()+ " button click");
			} catch(NoSuchElementException e) {
				e.printStackTrace();
				Log.info("Failed " + TaxTypeInfoPage.class.getName()
				+ " unable to click on button ");
			}
		}	
	} // function clickOnEmailCheck ends here
	
	/* Function Name    : clickOnDoneButton
	 * Description      : This function is used click on Print Check check box.
	 * Parameter        : None
	 * Return           : None 
	 */
	public void clickOnDoneButton() { 
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(doneButton));

		if (doneButton!=null) {
			try {
				doneButton.click();
				Log.info(TaxTypeInfoPage.class.getName()+ " button click");
			} catch(NoSuchElementException e) {
				e.printStackTrace();
				Log.info("Failed " + TaxTypeInfoPage.class.getName()
				+ " unable to click on button ");
			}
		}	
	} // function clickOnDoneButton ends here
	
    /* Function implementation of page Transaction Completed page */
	
	/* Function Name    : continueWithSameCustomer
	 * Description      : This function is used click on first radio button.
	 * Parameter        : None
	 * Return           : None 
	 */
	public void continueWithSameCustomer() {  
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(thisCustomerRadioButton));

		if (thisCustomerRadioButton!=null) {
			try {
				thisCustomerRadioButton.click();
				Log.info(TaxTypeInfoPage.class.getName()+ " button click");
			} catch(NoSuchElementException e) {
				e.printStackTrace();
				Log.info("Failed " + TaxTypeInfoPage.class.getName()
				+ " unable to click on button ");
			}
		}	
	} // function continueWithSameCustomer ends here
	
	/* Function Name    : continueWithAnotherSession
	 * Description      : This function is used click on second radio button.
	 * Parameter        : None
	 * Return           : None 
	 */
	public void continueWithAnotherSession() {  
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(anotherSessionRadioButton));

		if (anotherSessionRadioButton!=null) {
			try {
				anotherSessionRadioButton.click();
				Log.info(TaxTypeInfoPage.class.getName()+ " button click");
			} catch(NoSuchElementException e) {
				e.printStackTrace();
				Log.info("Failed " + TaxTypeInfoPage.class.getName()
				+ " unable to click on button ");
			}
		}	
	} // function continueWithAnotherSession ends here
	
	/* Function Name    : clickContinueButton
	 * Description      : This function is used click continue button.
	 * Parameter        : None
	 * Return           : None 
	 */
	public void clickContinueButton() {  
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(continueButton));

		if (continueButton!=null) {
			try {
				continueButton.click();
				Log.info(TaxTypeInfoPage.class.getName()+ " button click");
			} catch(NoSuchElementException e) {
				e.printStackTrace();
				Log.info("Failed " + TaxTypeInfoPage.class.getName()
				+ " unable to click on button ");
			}
		}	
	} // function clickContinueButton ends here
	
	/* Function Name    : clickTradeInButton
	 * Description      : This function is used click on Trade-In button.
	 * Parameter        : None
	 * Return           : None 
	 */
	public void clickTradeInButton() {  
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(tradeInButton));

		if (tradeInButton!=null) {
			try {
				tradeInButton.click();
				Log.info(TaxTypeInfoPage.class.getName()+ " button click");
			} catch(NoSuchElementException e) {
				e.printStackTrace();
				Log.info("Failed " + TaxTypeInfoPage.class.getName()
				+ " unable to click on button ");
			}
		}	
	} // function clickTradeInButton ends here
	
	/* Function Name    : clickCheckOutButtonButton
	 * Description      : This function is used click on Check Out button.
	 * Parameter        : None
	 * Return           : None 
	 */
	public void clickCheckOutButtonButton() {  
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(checkOutButton));

		if (checkOutButton!=null) {
			try {
				checkOutButton.click();
				Log.info(TaxTypeInfoPage.class.getName()+ " button click");
			} catch(NoSuchElementException e) {
				e.printStackTrace();
				Log.info("Failed " + TaxTypeInfoPage.class.getName()
				+ " unable to click on button ");
			}
		}	
	} // function clickCheckOutButtonButton ends here

} // class TransactionCmplPage ends here
