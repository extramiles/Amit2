/*
Description : This class identify and implement all the web
element and its corresponding action of Installment plan agreement page three 
of four.
Version info : V_0.1
Date : 08/06/2017
Author : Devendra Bhavsar
Copyright notice : Tech Mahindra Ltd
 */
package com.pageobject;

import java.util.NoSuchElementException;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;
import org.openqa.selenium.support.ui.Select;

import com.utility.Logg;
import com.utility.Util;


public class InstallmentPlanPageThree {
Util u = new Util();
	
	WebDriver driver = u.getDriver();
	 Logger Log = Logg.createLogger();
	public InstallmentPlanPageThree(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(new AjaxElementLocatorFactory(driver,20),this);
	}
		
	
/*-------------------------------------------------------- Page objects ---------------------------------------------------- */
	
	@FindBy(how = How.NAME, using = "emeraldAcknowledged")
	private WebElement chkboxAcknowledge;
	
	@FindBy(how = How.NAME, using = "salesRep")
	private WebElement selectSalesRep;

	@FindBy(how = How.NAME, using = "password")
	private WebElement textPassword;

	@FindBy(how = How.NAME, using = "btnEmeraldNext")
	private WebElement btnNext;
	
	
	/*-------------------------------------------------------- Page actions ---------------------------------------------------- */
	
	/*Method: setChkboxAcknowledge
	 Description : To set the value of input(check box) chkboxAcknowledge.
	 Parameter : None
	 Return type : WebElement */
	public WebElement setChkboxAcknowledge(){
		WebElement wePh = chkboxAcknowledge; // WebElement object
				String webElementName = "chkboxAcknowledge"; // WebElement object name string
		if(wePh.isEnabled()){
			try {
				wePh.click();
				Log.info("Passed : "+ InstallmentPlanPageThree.class.getName() + "- CheckBox : " + webElementName + " is checked.");
			} catch(NoSuchElementException e) {
				e.printStackTrace();
				Log.info("Failed :" + InstallmentPlanPageThree.class.getName() + "- CheckBox : " + webElementName + " not found.");
			}
		}
		else{
			Log.info("Failed :" + InstallmentPlanPageThree.class.getName() + "- CheckBox : " + webElementName + " is disabled.");
		}
		return wePh;
	}
	
	/*Method: setSelectSalesRep
	Description : To select the value of Select selectSalesRep.
	Parameter : @value -  
	Return type : WebElement */
	public WebElement setSelectSalesRep(String value)
	{ 
		WebElement wePh = selectSalesRep; // WebElement object
		String webElementName = "selectSalesRep"; // WebElement object name string
		if (value!=null) {
			try {
				 Select selectWE = new Select(wePh);
				 selectWE.selectByValue(value);
				 Log.info("Passed : "+ InstallmentPlanPageThree.class.getName() + "- Select : " + webElementName + " is set to " + value + ".");
			} catch(NoSuchElementException e) {
				e.printStackTrace();
				Log.info("Failed :" + InstallmentPlanPageThree.class.getName() + "- Select : " + webElementName + " not found.");
			}
		}
		return wePh;
	}
	
	/*Method: setTextPassword
	 Description : To set the value of input(text) textPassword.
	 Parameter : @value - 
	 Return type : WebElement */
	
	public WebElement setTextPassword(String value)
	{
		WebElement wePh = textPassword; // WebElement object 
		String webElementName = "textPassword"; // WebElement object name string
		if(value!=null){
			try
			{
				wePh.clear();
				Log.info("Passed : "+ InstallmentPlanPageThree.class.getName() + "- Textbox : " + webElementName + " is cleared.");
				wePh.sendKeys(value);
				Log.info("Passed : "+ InstallmentPlanPageThree.class.getName() + "- Textbox : " + webElementName + " is set to " + value + ".");
			}
			catch(NoSuchElementException e)
			{
				e.printStackTrace();
				Log.info("Failed :" + InstallmentPlanPageThree.class.getName() + "- Textbox : " + webElementName + " not found.");
			}
		}
		return wePh;
	}
	
	/*Method: clickBtnNext
	Description : To click on  button btnNext.
	Parameter : None
	Return type : void */
	public void clickBtnNext()
	{
		WebElement wePh = btnNext; // WebElement object 
		String webElementName = "btnNext"; // WebElement object name string
		try {
			wePh.click();
			Log.info("Passed : "+ InstallmentPlanPageThree.class.getName() + "- Button : " + webElementName + " is clicked.");
			} catch(NoSuchElementException e) {
			e.printStackTrace();
			Log.info("Failed :" + InstallmentPlanPageThree.class.getName() + "- Button : " + webElementName + " not found.");
			}
	}
}
