 /* ClassName            : CustomerInfoPage
  * Description          : This class identify and implement all the web
  *                        element and its corresponding action of Customer
  *                        Information page.
  * Version info         : V_0.1
  * Author               : Tech Mahindra
  * Copyright notice     : Tech Mahindra Ltd. 
  */

package com.pageobject;

import java.util.Iterator;
import java.util.NoSuchElementException;

import org.apache.log4j.Logger;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;

import com.sun.xml.internal.bind.v2.schemagen.xmlschema.List;
import com.utility.Logg;
import com.utility.Util;

public class CustomerInfoPage {
	
	Util u = new Util();
	WebDriver driver = u.getDriver();
	Logger Log = Logg.createLogger();	
	// Constructor for class HomePage
	public CustomerInfoPage(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver,this);
	}
	
	/* Web Element Locator for Account Type */ 
	
	// Radio button for selecting Individual Post paid Plan
	@FindBy(how=How.ID, using = "addnlCustomerChoice_1") 
	public WebElement individualPostPaid;
	
	// Radio button for selecting Family Talk Plan
	@FindBy(how=How.ID, using = "addnlCustomerChoice_2") 
	public WebElement familyTalk;
		
	// Radio button for selecting Pay As You Go Plan
	@FindBy(how=How.ID, using = "addnlCustomerChoice_3") 
	public WebElement payAsYouGo;
	
	// To select Market drop-down
	@FindBy(how=How.ID, using = "marketSelection") 
	public WebElement selectMarket;
	
	// To select Sales Representative drop-down
	@FindBy(how=How.ID, using = "salesrep") 
	public WebElement selectSalesRep;
	
	// To select No. Of Lines to be activated drop-down
	@FindBy(how=How.ID, using = "numberOfLines") 
	public WebElement selectNumberOfLines;
			 
	// To set tax exempt as Yes
	@FindBy(how=How.XPATH, using = "(//input[@id='taxExemptFlag'])[0]") 
	public WebElement taxExemptTrue;
	
	// To set tax exempt as Yes
	@FindBy(how=How.XPATH, using = "//div/input[@id='taxExemptFlag' and @value='N']") 
	public WebElement taxExemptFalse;
	
	// To click on checkbox of FAN
	@FindBy(how=How.NAME, using = "selectFan") 
	public WebElement fanCheckBox;
	
	// To click on check-box of FAN
	@FindBy(how=How.ID, using = "fan")  
	public WebElement fanValue;
	
	// To select proof of eligibility select tag
	@FindBy(how=How.ID, using = "poeType")  
	public WebElement eligibilityProof;
	
	// Text box to provide user notes
	@FindBy(how=How.ID, using = "userNote")  
	public WebElement userNoteInput;
	
	// To click on check-box of FAN
	@FindBy(how=How.NAME, using = "iruConfirm")  
	public WebElement checkIruConfirm;
	
	/* Web Element Locator for Account Holders Personal Information */ 
	
	// Text box to select Customer Title from select tag
	@FindBy(how=How.ID, using = "customernametitle")  
	public WebElement customerPreffix;
	
	// Text box to provide customer first name
	@FindBy(how=How.ID, using = "firstName")  
	public WebElement custFirstName;
		
	// Text box to provide customer Middle name
	@FindBy(how=How.ID, using = "MI")  
	public WebElement custMiddletName;
		
	// Text box to provide customer first name
	@FindBy(how=How.XPATH, using = "//tbody/tr[1]/td[4]/input[@name='customerNameLast']")  
	public WebElement custLastName;	
	
	// Text box to select Customer Title from select tag
	@FindBy(how=How.ID, using = "customernamesuffix")  
	public WebElement customerSuffix;
	
	// check box to click customer former last name
	@FindBy(how=How.NAME, using = "customerFormerNameLastExists")  
	public WebElement checkFormerLastName;
	
	// Text box to locate text box of customer former last name
	@FindBy(how=How.ID, using = "formerNameLast")  
	public WebElement customerFormaerLastName;
	
	// Text box to locate text box of customer DOB Month
	@FindBy(how=How.XPATH, using = "//div[@id='divcustomerDOB']/input[@name='customerDOB.month']")  
	public WebElement customerDOBMonth;
	
	// Text box to locate text box of customer DOB Day
	@FindBy(how=How.ID, using = "customerDOB_day")  
	public WebElement customerDOBDay;
		
	// Text box to locate text box of customer DOB year
	@FindBy(how=How.ID, using = "customerDOB_year")  
	public WebElement customerDOBYear;
	
	// Text box to locate text box of customer SSN Area
	@FindBy(how=How.ID, using = "customerSSN_area")  
	public WebElement sSNArea;
		
	// Text box to locate text box of customer SSN Group
	@FindBy(how=How.ID, using = "customerSSN_group")  
	public WebElement sSNGroup;
	
	// Text box to locate text box of customer SSN Serial
	@FindBy(how=How.ID, using = "customerSSN_serial")  
	public WebElement sSNSerial;
	
	// Text box to locate text box of customer SSN Area confirmation 
	@FindBy(how=How.ID, using = "confirmSSN_area")  
	public WebElement retypeSsnArea;
	
	// Text box to locate text box of customer SSN Group confirmation 
	@FindBy(how=How.ID, using = "confirmSSN_group")  
	public WebElement retypeSsnGroup;
		
	// Text box to locate text box of customer SSN Serial confirmation 
	@FindBy(how=How.ID, using = "confirmSSN_serial")  
	public WebElement retypeSsnSerial;
	
	// Text box to locate select tag of customer DL state drop-down 
	@FindBy(how=How.XPATH, using = "//div[@id='divcustomerdlstate']/select[@name='customerDriversLicense.state']")
	public WebElement selectDlState;
	
	// Text box to locate select tag of customer DL Number state drop-down 
	@FindBy(how=How.NAME, using = "customerDriversLicense.number")  
	public WebElement selectDlNumber;
	
	// Text box to locate text box of customer DL Expiration month  
	@FindBy(how=How.NAME, using = "customerDriversLicense.expirationDate.month")  
	public WebElement dlExpMonth;
	
	// Text box to locate text box of customer DL Expiration day  
	@FindBy(how=How.NAME, using = "customerDriversLicense.expirationDate.day")  
	public WebElement dlExpDate;
		
	// Text box to locate text box of customer DL Expiration year  
	@FindBy(how=How.NAME, using = "customerDriversLicense.expirationDate.year")  
	public WebElement dlExpYear;
	
	/* Web Element Locator for contact information detail */ 

	// Text box to locate first text box of home phone
	@FindBy(how=How.ID, using = "customerhomephone_npa")  
	public WebElement homePhoneFirst;
	
	// Text box to locate second text box of home phone
	@FindBy(how=How.ID, using = "customerhomephone_nxx")  
	public WebElement homePhoneSecond;
	// Text box to locate third text box of home phone
	@FindBy(how=How.ID, using = "customerhomephone_line")  
	public WebElement homePhoneThird;
	// Text box to locate first text box of home phone
	@FindBy(how=How.ID, using = "homePhoneDropDown")  
	public WebElement homePhoneContactPref;
	
	// Text box to locate first text box of work phone
	@FindBy(how=How.ID, using = "customerworkphone_npa")  
	public WebElement workPhoneFirst;
		
	// Text box to locate second text box of work phone
	@FindBy(how=How.ID, using = "customerworkphone_nxx")  
	public WebElement workPhoneSecond;
	// Text box to locate third text box of work phone
	@FindBy(how=How.ID, using = "customerworkphone_line")  
	public WebElement workPhoneThird;
	
	// Text box to locate fourth text box of work phone (extension)
	@FindBy(how=How.ID, using = "customerworkphone")  
	public WebElement workPhoneExtension;
	
	// Text box to locate first text box of work phone
	@FindBy(how=How.ID, using = "workPhoneDropDown")  
	public WebElement workPhoneContactPref;
	
	// Text box to locate primary email-id text box
	@FindBy(how=How.ID, using = "customeremailprimary_emailId")  
	public WebElement primaryEmailId;
	
	// Text box to locate secondary email-id text box
	@FindBy(how=How.ID, using = "customeremailsecondary_emailId")  
	public WebElement secondaryEmailId;
	
	// Text box to locate check box if primary email is not available
	@FindBy(how=How.NAME, using = "primaryEmailOverride")  
	public WebElement primaryEmailCheckbox;
	// Text box to locate text box of employer name
	@FindBy(how=How.XPATH, using = "//table/tbody/tr[5]/td[1]/input[@name='employerName']")  
	public WebElement employerName;
	
	/* Web Element Locator for Billing Address */ 
	
	// Select tag drop-down locator for select Address Type
	@FindBy(how=How.ID, using = "billingAddressType")  
	public WebElement setBillingAddress;
	
	// Text box for Zip Code
	@FindBy(how=How.NAME, using = "address.zip.zip")  
	public WebElement setZipCode;
	
	// Text box for setting any attention note if required
	@FindBy(how=How.ID, using = "incareof")  
	public WebElement setAttentionIfAny;
	
	// Text box for setting value in address line 1
	@FindBy(how=How.NAME, using = "address.street.name")  
	public WebElement setStreetName;
	
	// Text box for setting City Value
	@FindBy(how=How.NAME, using = "address.city")  
	public WebElement setCity;
	
	// Select tag drop-down locator for select state
	@FindBy(how=How.NAME, using = "address.state")  
	public WebElement selectState;
	
	@FindBy(how=How.NAME, using = "address.street.number")  
	public WebElement streetNum;
	/* Web Element Locator for Additional Info */
	
	// Text box for setting Account Pass-code
	@FindBy(how=How.XPATH, using = "//table/tbody/tr[1]/td[1]/input[@name='billingPassword']")  
	public WebElement setAccPasscode;
	
	// Text box for setting again Account Pass-code
	@FindBy(how=How.XPATH, using = "//table/tbody/tr[2]/td[1]/input[@name='reenteredPassword']")  
	public WebElement reconfirmAccPasscode;
	
	// Locator to click on Use Station button
	@FindBy(how=How.ID, using = "confirmPasswordFromSigcapId")  
	public WebElement clickOnUseStation;
	
	/* Web Element Locator for Security Preferences */
	
	// To click radio button on Extra Security
	@FindBy(how=How.XPATH, using = "(//input[@id='selectedOption'])[1]") 
	public WebElement optExtraSecurity;
	
	// To click radio button on Extra Security
	@FindBy(how=How.XPATH, using = "(//input[@id='selectedOption'])[2]") 
	public WebElement optStandardSecurity;
	
	// Locator to click on Address Validation pop-up
	@FindBy(how=How.ID, using = "continuaddress")
	public WebElement continueAddress;
	
	@FindBy(how=How.ID, using = "declineScan")
	private WebElement declineScan;
		
	@FindBy(how=How.XPATH, using="//div[@id='byPassCodes']/div[3]/label/select[@name='selectedByPassOverrideId']")
	private WebElement selectReasonForBypass;
	
	@FindBy(how=How.XPATH, using = "//button[@id='nextButtonBlock']/b/em/u[text()='Next']")
	private WebElement clickNext;
	
	/* Function Name    : selectIndividualPostPaidPlan
	 * Description      : This function is used to select Post-paid plan.
	 * Parameter        : None
	 * Return           : None 
	 */
	
	public void selectIndividualPostPaidPlan( ){  
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(individualPostPaid));
		if (individualPostPaid!=null) {
			try {
				individualPostPaid.click();
			} catch(NoSuchElementException e) {
				e.printStackTrace();
			 }
		}
	}
	
	public void clickNext( ){  
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(clickNext));
		if (clickNext!=null) {
			try {
				clickNext.click();
			} catch(NoSuchElementException e) {
				e.printStackTrace();
			 }
		}
	}
	
	/* Function Name    : selectpayAsYouGoPlan
	 * Description      : This function is used to select Pay As You Go plan.
	 * Parameter        : None
	 * Return           : None 
	 */
	
	public void selectpayAsYouGoPlan( ){  
		if (payAsYouGo!=null) {
			try {
				payAsYouGo.click();
			} catch(NoSuchElementException e) {
				e.printStackTrace();
			 }
		}
	}
	
	/* Function Name    : selectFamilyTalkPlan
	 * Description      : This function is used to select family talk plan.
	 * Parameter        : None
	 * Return           : None 
	 */
	
	public void selectFamilyTalkPlan( ){  
		if (familyTalk!=null) {
			try {
				familyTalk.click();
			} catch(NoSuchElementException e) {
				e.printStackTrace();
			 }
		}
	}
	
	
	public void selectMarketFromDropdown(String marketArea ) {  
		if (selectMarket!=null) {
			try {
				Select market = new Select(selectMarket);
				market.selectByVisibleText(marketArea);
				Log.info("store " + marketArea + " selected from " + CustomerInfoPage.class.getName());
			} catch(NoSuchElementException e) {
				e.printStackTrace();
				Log.info("Failed Store " + marketArea  + "Not Found in " + CustomerInfoPage.class.getName());
			}
		}	
	}
	
	
	public void selectReasonForByPass(String reasonforbypass) { 
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(selectReasonForBypass));
		if (selectReasonForBypass!=null) {
			try {
				selectReasonForBypass.click();
				/*Select market = new Select(selectReasonForBypass);
				market.selectByVisibleText(reasonforbypass);*/
			/*java.util.List<WebElement> ls = 	market.getOptions();
			for(WebElement ele : ls){
				String s = ele.getText();
				if(s.equals(reasonforbypass)){
					ele.click();
					break;
				}*/
			//}
				//market.selectByVisibleText(reasonforbypass);
				/*JavascriptExecutor js = (JavascriptExecutor)driver;
				js.executeScript("arguments[0].click();",selectReasonForBypass);*/
				selectReasonForBypass.sendKeys(reasonforbypass);
				
				//u.waitForElement(driver).until(ExpectedConditions.(selectReasonForBypass));
				Log.info("store " + reasonforbypass + " selected from " + CustomerInfoPage.class.getName());
			} catch(NoSuchElementException e) {
				e.printStackTrace();
				Log.info("Failed Store " + reasonforbypass  + "Not Found in " + CustomerInfoPage.class.getName());
			}
		}	
	}
	/* Function Name    : selectSalesRepFromDropdown
	 * Description      : This function is used to select sales representative
	 *                    from the drop-down.
	 * Parameter        : 
	 * @salesRepValue   : Parameter to hold name of sales representative.
	 * Return           : None 
	 */
	
	public void selectSalesRepFromDropdown(String salesRepValue ) {  
		if (selectSalesRep!=null) {
			try {
				Select salesPerson = new Select(selectSalesRep);
				salesPerson.selectByVisibleText(salesRepValue);
				Log.info("Sales Representative " +salesRepValue
						+" selected from " + CustomerInfoPage.class.getName());
			} catch(NoSuchElementException e) {
				e.printStackTrace();
				Log.info("Failed ! Sales Representative "+ salesRepValue 
						+ "Not Found in " + CustomerInfoPage.class.getName());
			}
		}	
	}
	
	
	public WebElement setStreetNumber(String streetnum ) { 
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(streetNum));
		if (streetNum!=null) {
			try {
				streetNum.clear();
				streetNum.sendKeys(streetnum);
				Log.info("Sales Representative " +streetNum
						+" selected from " + CustomerInfoPage.class.getName());
			} catch(NoSuchElementException e) {
				e.printStackTrace();
				Log.info("Failed ! Sales Representative "+ streetNum 
						+ "Not Found in " + CustomerInfoPage.class.getName());
			}
		}
		return streetNum;	
	}
	
	public void setStreetName(String streetname ) { 
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(setStreetName));
		if (setStreetName!=null) {
			try {
				setStreetName.clear();
				setStreetName.sendKeys(streetname);
				Log.info("Sales Representative " +streetname
						+" selected from " + CustomerInfoPage.class.getName());
			} catch(NoSuchElementException e) {
				e.printStackTrace();
				Log.info("Failed ! Sales Representative "+ streetname 
						+ "Not Found in " + CustomerInfoPage.class.getName());
			}
		}	
	}
	
	public void setState(String state ) { 
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(selectState));
		if (selectState!=null) {
			try {
				selectState.click();
				selectState.sendKeys(state);
				Log.info("Sales Representative " +state
						+" selected from " + CustomerInfoPage.class.getName());
			} catch(NoSuchElementException e) {
				e.printStackTrace();
				Log.info("Failed ! Sales Representative "+ state 
						+ "Not Found in " + CustomerInfoPage.class.getName());
			}
		}	
	}
	
	public void setCity(String city ) { 
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(setCity));
		if (setCity!=null) {
			try {
				setCity.clear();
				setCity.sendKeys(city);
				Log.info("Sales Representative " +city
						+" selected from " + CustomerInfoPage.class.getName());
			} catch(NoSuchElementException e) {
				e.printStackTrace();
				Log.info("Failed ! Sales Representative "+ city 
						+ "Not Found in " + CustomerInfoPage.class.getName());
			}
		}	
	}
	
	public void setZipCode(String zip ) { 
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(setZipCode));
		if (setZipCode!=null) {
			try {
				setZipCode.clear();
				setZipCode.sendKeys(zip);
				Log.info("Sales Representative " +zip
						+" selected from " + CustomerInfoPage.class.getName());
			} catch(NoSuchElementException e) {
				e.printStackTrace();
				Log.info("Failed ! Sales Representative "+ zip 
						+ "Not Found in " + CustomerInfoPage.class.getName());
			}
		}	
	}
	/* Function Name    : setNumberOfLinesToActivate
	 * Description      : This function is used to select how many No of
	 *                    lines to activate.
	 * Parameter        : 
	 * @inputValue      : Parameter to hold value of no. of lines
	 * Return           : None 
	 */
	
	public void setNumberOfLinesToActivate(String inputValue ) {  
		if (selectNumberOfLines!=null) {
			try {
				Select noOfLines = new Select(selectNumberOfLines);
				noOfLines.selectByVisibleText(inputValue);
				Log.info("Sales Representative " +inputValue
						+" selected from " + CustomerInfoPage.class.getName());
			} catch(NoSuchElementException e) {
				e.printStackTrace();
				Log.info("Failed ! Sales Representative "+ inputValue 
						+ "Not Found in " + CustomerInfoPage.class.getName());
			}
		}	
	}
	
	/* Function Name    : selectTaxExemptAsYes
	 * Description      : This function is used to select tax exempt as Yes.
	 * Parameter        : 
	 * @inputValue      : Parameter to hold value of no. of lines
	 * Return           : None 
	 */
	
	public void selectTaxExemptAsYes() {  
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(taxExemptTrue));
		if (taxExemptTrue!=null) {
			try {
				taxExemptTrue.click();
				Log.info(CustomerInfoPage.class.getName()+ " button click");
			} catch(NoSuchElementException e) {
				e.printStackTrace();
				Log.info("Failed " + CustomerInfoPage.class.getName()
				+ " unable to click on button ");
			}
		}	
	}
	
	public void declineScan() {  
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(declineScan));
		if (declineScan!=null) {
			try {
				declineScan.click();
				u.waits(2000);
				Log.info(CustomerInfoPage.class.getName()+ " button click");
			} catch(NoSuchElementException e) {
				e.printStackTrace();
				Log.info("Failed " + CustomerInfoPage.class.getName()
				+ " unable to click on button ");
			}
		}	
	}
	
	
	/* Function Name    : selectTaxExemptAsNo
	 * Description      : This function is used to select tax exempt as No.
	 * Parameter        : 
	 * @inputValue      : Parameter to hold value of no. of lines
	 * Return           : None 
	 */
	
	public void selectTaxExemptAsNo() {  
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(taxExemptFalse));
		if (taxExemptFalse!=null) {
			try {
				taxExemptFalse.click();
				Log.info(CustomerInfoPage.class.getName()+ " button click");
			} catch(NoSuchElementException e) {
				e.printStackTrace();
				Log.info("Failed " + CustomerInfoPage.class.getName()
				+ " unable to click on button ");
			}
		}	
	}
	
	/* Function Name    : clickOnFANCheckBox
	 * Description      : This function is used to click/un-click on FAN
	 *                    check-box.
	 * Parameter        : None
	 * Return           : None 
	 */
	
	public void clickOnFANCheckBox() {  
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(fanCheckBox));

		if (fanCheckBox!=null) {
			try {
				fanCheckBox.click();
				Log.info(CustomerInfoPage.class.getName()+ " button click");
			} catch(NoSuchElementException e) {
				e.printStackTrace();
				Log.info("Failed " + CustomerInfoPage.class.getName()
				+ " unable to click on button ");
			}
		}	
	}
	
	/* Function Name    : setFANNumber
	 * Description      : This function is used enter FAN Number in text box.
	 *                    check-box.
	 * Parameter        : None
	 * Return           : None 
	 */
	
	public void setFANNumber(String fanValue) {  
		if (fanCheckBox!=null) {
			try {
				fanCheckBox.click();
				Log.info("Passed : "+ CustomerInfoPage.class.getName()
						+ "- Textbox : fanCheckBox is cleared.");
				Log.info(CustomerInfoPage.class.getName()+ " button click");
			} catch(NoSuchElementException e) {
				e.printStackTrace();
				Log.info("Passed : "+ CustomerInfoPage.class.getName()
						+ "- Textbox : unable to click on button");
			}
		}	
	}
	
	/* Function Name    : selectPrefixWithName
	 * Description      : This function is used to provide prefix with
	 *                    customer name.
	 * Parameter        : 
	 * @prefixValue     : Parameter to hold prefix value with customer name.
	 * Return           : None 
	 */
	
	public void selectPrefixWithName(String prefixValue ) {  
		if (customerPreffix!=null) {
			try {
				Select noOfLines = new Select(customerPreffix);
				noOfLines.selectByVisibleText(prefixValue);
				Log.info("Customer Prefix " +prefixValue
						+" selected from " + CustomerInfoPage.class.getName());
			} catch(NoSuchElementException e) {
				e.printStackTrace();
				Log.info("Failed ! Customer Prefix "+ prefixValue 
						+ "Not Found in " + CustomerInfoPage.class.getName());
			}
		}	
	}
	
	
	/* Function Name    : setCustomerFirstName
	 * Description      : This function is used to provide input for
	 *                    customer first name.
	 * Parameter        : 
	 * @prefixValue     : Parameter to hold input value for customer first name
	 * Return           : None 
	 */
	
	public void setCustomerFirstName(String firstNameValue ) {  
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(custFirstName));

		if (custFirstName!=null) {
			try {
				custFirstName.clear();
				Log.info("Passed : "+ CustomerInfoPage.class.getName()
						+ "- Textbox : " + custFirstName + " is cleared.");
				custFirstName.sendKeys(firstNameValue);
				Log.info("Passed : "+ CustomerInfoPage.class.getName()
						+ "- Textbox : " + custFirstName + " is set to "
						+ firstNameValue + ".");
			} catch(NoSuchElementException e) {
				e.printStackTrace();
				Log.info("Failed :" + CustomerInfoPage.class.getName()
						+ "- Textbox : " + custFirstName + " not found.");
			}
		}	
	} // function setCustomerFirstName ends here
	
	/* Function Name    : setCustomerMiddleName
	 * Description      : This function is used to provide input for
	 *                    customer Middle name.
	 * Parameter        : 
	 * @middleNameValue : Parameter to hold input value for customer Middle
	 *                    name.
	 * Return           : None 
	 */
	
	public void setCustomerMiddleName(String middleNameValue ) {  
		if (custLastName!=null) {
			try {
				custLastName.clear();
				Log.info("Passed : "+ CustomerInfoPage.class.getName()
						+ "- Textbox : " + custLastName + " is cleared.");
				custFirstName.sendKeys(middleNameValue);
				Log.info("Passed : "+ CustomerInfoPage.class.getName()
						+ "- Textbox : " + custLastName + " is set to "
						+ middleNameValue + ".");
			} catch(NoSuchElementException e) {
				e.printStackTrace();
				Log.info("Failed :" + CustomerInfoPage.class.getName()
						+ "- Textbox : " + middleNameValue + " not found.");
			}
		}	
	} // function setCustomerMiddleName ends here
	
	/* Function Name    : setCustomerLastName
	 * Description      : This function is used to provide input for
	 *                    customer first name.
	 * Parameter        : 
	 * @LastNameValue   : Parameter to hold input value for customer last name
	 * Return           : None 
	 */
	
	public void setCustomerLastName(String LastNameValue ) {  
		if (custLastName!=null) {
			try {
				custLastName.clear();
				Log.info("Passed : "+ CustomerInfoPage.class.getName()
						+ "- Textbox : " + custLastName + " is cleared.");
				custLastName.sendKeys(LastNameValue);
				Log.info("Passed : "+ CustomerInfoPage.class.getName()
						+ "- Textbox : " + custLastName + " is set to "
						+ LastNameValue + ".");
			} catch(NoSuchElementException e) {
				e.printStackTrace();
				Log.info("Failed :" + CustomerInfoPage.class.getName()
						+ "- Textbox : " + LastNameValue + " not found.");
			}
		}	
	} // function setCustomerLastName ends here
	
	
	/* Function Name    : selectSuffixWithName
	 * Description      : This function is used to provide Suffix with
	 *                    customer name.
	 * Parameter        : 
	 * @prefixValue     : Parameter to hold Suffix value with customer name.
	 * Return           : None 
	 */
	
	public void selectSuffixWithName(String suffixValue ) {  
		if (customerSuffix!=null) {
			try {
				Select noOfLines = new Select(customerSuffix);
				noOfLines.selectByVisibleText(suffixValue);
				Log.info("Customer Suffix " +suffixValue
						+" selected from " + CustomerInfoPage.class.getName());
			} catch(NoSuchElementException e) {
				e.printStackTrace();
				Log.info("Failed ! Customer Suffix "+ suffixValue 
						+ "Not Found in " + CustomerInfoPage.class.getName());
			}
		}	
	}
	
	/* Function Name    : clickOnCustomerFormerLastName
	 * Description      : This function is used to click/un-click on
	 *                    customer former last name checkbox.
	 *                    check-box.
	 * Parameter        : None
	 * Return           : None 
	 */
	
	public void clickOnCustomerFormerLastName() {  
		if (checkFormerLastName!=null) {
			try {
				checkFormerLastName.click();
				Log.info(CustomerInfoPage.class.getName()+ " button click");
			} catch(NoSuchElementException e) {
				e.printStackTrace();
				Log.info("Failed " + CustomerInfoPage.class.getName()
				+ " unable to click on button ");
			}
		}	
	}
	
	/* Function Name    : setCustomerFormerLastName
	 * Description      : This function is used to provide input for
	 *                    customer former last name.
	 * Parameter        : 
	 * @formerLastNameValue : Parameter to hold input value for customer
	 *                        former last name
	 * Return           : None 
	 */
	public void setCustomerFormerLastName(String formerLastNameValue ) {  
		if (customerFormaerLastName!=null) {
			try {
				customerFormaerLastName.clear();
				Log.info("Passed : "+ CustomerInfoPage.class.getName()
						+ "- Textbox : " + customerFormaerLastName + " is cleared.");
				custFirstName.sendKeys(formerLastNameValue);
				Log.info("Passed : "+ CustomerInfoPage.class.getName()
						+ "- Textbox : " + customerFormaerLastName + " is set to "
						+ formerLastNameValue + ".");
			} catch(NoSuchElementException e) {
				e.printStackTrace();
				Log.info("Failed :" + CustomerInfoPage.class.getName()
						+ "- Textbox : " + formerLastNameValue + " not found.");
			}
		}	
	} // function setCustomerFormerLastName ends here
	
	/* Function Name    : setCustomerDOB
	 * Description      : This function is used to set input for
	 *                    customer DOB.
	 * Parameter        : 
	 * @ monthDOBValue  : Input value for Month of DOB.
	 * @ dayDOBValue    : Input value for Day of DOB.
	 * @ yearDOBValue   : Input value for Year of DOB.
	 * Return           : None 
	 */
	public void setCustomerDOB(String monthDOBValue, String dayDOBValue
			                   , String yearDOBValue) {  
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(customerDOBMonth));
		if (customerDOBMonth!=null) {
			try {
				customerDOBMonth.clear();
				Log.info("Passed : "+ CustomerInfoPage.class.getName()
						+ "- Textbox : " + customerDOBMonth + " is cleared.");
				customerDOBMonth.sendKeys(monthDOBValue);
				Log.info("Passed : "+ CustomerInfoPage.class.getName()
						+ "- Textbox : " + customerDOBMonth + " is set to "
						+ monthDOBValue + ".");
			} catch(NoSuchElementException e) {
				e.printStackTrace();
				Log.info("Failed :" + CustomerInfoPage.class.getName()
						+ "- Textbox : " + monthDOBValue + " not found.");
			}
		}
		if (customerDOBMonth!=null) {
			try {
				customerDOBDay.clear();
				Log.info("Passed : "+ CustomerInfoPage.class.getName()
						+ "- Textbox : " + customerDOBMonth + " is cleared.");
				customerDOBDay.sendKeys(dayDOBValue);
				Log.info("Passed : "+ CustomerInfoPage.class.getName()
						+ "- Textbox : " + customerDOBMonth + " is set to "
						+ dayDOBValue + ".");
			} catch(NoSuchElementException e) {
				e.printStackTrace();
				Log.info("Failed :" + CustomerInfoPage.class.getName()
						+ "- Textbox : " + dayDOBValue + " not found.");
			}
		}
		if (customerDOBYear!=null) {
			try {
				customerDOBYear.clear();
				Log.info("Passed : "+ CustomerInfoPage.class.getName()
						+ "- Textbox : " + customerDOBMonth + " is cleared.");
				customerDOBYear.sendKeys(yearDOBValue);
				Log.info("Passed : "+ CustomerInfoPage.class.getName()
						+ "- Textbox : " + customerDOBMonth + " is set to "
						+ yearDOBValue + ".");
			} catch(NoSuchElementException e) {
				e.printStackTrace();
				Log.info("Failed :" + CustomerInfoPage.class.getName()
						+ "- Textbox : " + yearDOBValue + " not found.");
			}
		}
	} // function setCustomerDOB ends here

	/* Function Name    : setSSNNumber
	 * Description      : This function is used to set input for
	 *                    customer SSN Number.
	 * Parameter        : 
	 * @ ssnAreaValue   : Input value for SSN Area number.
	 * @ ssnGroupValue  : Input value for SSN group number.
	 * @ ssnSerialValue : Input value for SSN Serial number
	 * Return           : None 
	 */
	public void setSSNNumber(String ssnAreaValue, String ssnGroupValue
			                   , String ssnSerialValue) {  
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(sSNArea));

		if (sSNArea!=null) {
			try {
				sSNArea.clear();
				Log.info("Passed : "+ CustomerInfoPage.class.getName()
						+ "- Textbox : " + sSNArea + " is cleared.");
				sSNArea.sendKeys(ssnAreaValue);
				Log.info("Passed : "+ CustomerInfoPage.class.getName()
						+ "- Textbox : " + sSNArea + " is set to "
						+ ssnAreaValue + ".");	
			} catch(NoSuchElementException e) {
				e.printStackTrace();
				Log.info("Failed :" + CustomerInfoPage.class.getName()
						+ "- Textbox : " + ssnAreaValue + " not found.");
			}
		}
		if (sSNGroup!=null) {
			try {
				sSNGroup.clear();
				Log.info("Passed : "+ CustomerInfoPage.class.getName()
						+ "- Textbox : " + sSNGroup + " is cleared.");
				sSNGroup.sendKeys(ssnGroupValue);
				Log.info("Passed : "+ CustomerInfoPage.class.getName()
						+ "- Textbox : " + sSNGroup + " is set to "
						+ ssnGroupValue + ".");
			} catch(NoSuchElementException e) {
				e.printStackTrace();
				Log.info("Failed :" + CustomerInfoPage.class.getName()
						+ "- Textbox : " + ssnGroupValue + " not found.");
			}
		}
		if (sSNSerial!=null) {
			try {
				sSNSerial.clear();
				Log.info("Passed : "+ CustomerInfoPage.class.getName()
						+ "- Textbox : " + sSNSerial + " is cleared.");
				sSNSerial.sendKeys(ssnSerialValue);
				Log.info("Passed : "+ CustomerInfoPage.class.getName()
						+ "- Textbox : " + sSNSerial + " is set to "
						+ ssnSerialValue + ".");
			} catch(NoSuchElementException e) {
				e.printStackTrace();
				Log.info("Failed :" + CustomerInfoPage.class.getName()
						+ "- Textbox : " + ssnSerialValue + " not found.");
			}
		}
	} // function setSSNNumber ends here
	
	
	/* Function Name    : confirmSSNNumber
	 * Description      : This function is used to set input for
	 *                    customer SSN Number confirmation.
	 * Parameter        : 
	 * @ ssnAreaValue   : Input value for SSN Area number.
	 * @ ssnGroupValue  : Input value for SSN group number.
	 * @ ssnSerialValue : Input value for SSN Serial number
	 * Return           : None 
	 */
	public void confirmSSNNumber(String ssnAreaValue, String ssnGroupValue
			                   , String ssnSerialValue) {  
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(retypeSsnArea));
		if (retypeSsnArea!=null) {
			try {
				retypeSsnArea.clear();
				Log.info("Passed : "+ CustomerInfoPage.class.getName()
						+ "- Textbox : " + retypeSsnArea + " is cleared.");
				retypeSsnArea.sendKeys(ssnAreaValue);
				Log.info("Passed : "+ CustomerInfoPage.class.getName()
						+ "- Textbox : " + retypeSsnArea + " is set to "
						+ ssnAreaValue + ".");	
			} catch(NoSuchElementException e) {
				e.printStackTrace();
				Log.info("Failed :" + CustomerInfoPage.class.getName()
						+ "- Textbox : " + ssnAreaValue + " not found.");
			}
		}
		if (retypeSsnGroup!=null) {
			try {
				retypeSsnGroup.clear();
				Log.info("Passed : "+ CustomerInfoPage.class.getName()
						+ "- Textbox : " + retypeSsnGroup + " is cleared.");
				retypeSsnGroup.sendKeys(ssnGroupValue);
				Log.info("Passed : "+ CustomerInfoPage.class.getName()
						+ "- Textbox : " + retypeSsnGroup + " is set to "
						+ ssnGroupValue + ".");
			} catch(NoSuchElementException e) {
				e.printStackTrace();
				Log.info("Failed :" + CustomerInfoPage.class.getName()
						+ "- Textbox : " + ssnGroupValue + " not found.");
			}
		}
		if (retypeSsnSerial!=null) {
			try {
				retypeSsnSerial.clear();
				Log.info("Passed : "+ CustomerInfoPage.class.getName()
						+ "- Textbox : " + retypeSsnSerial + " is cleared.");
				retypeSsnSerial.sendKeys(ssnSerialValue);
				Log.info("Passed : "+ CustomerInfoPage.class.getName()
						+ "- Textbox : " + retypeSsnSerial + " is set to "
						+ ssnSerialValue + ".");
			} catch(NoSuchElementException e) {
				e.printStackTrace();
				Log.info("Failed :" + CustomerInfoPage.class.getName()
						+ "- Textbox : " + ssnSerialValue + " not found.");
			}
		}
	} // function confirmSSNNumber ends here
	
	/* Function Name    : selectLicenseState
	 * Description      : This function is used to select customer DL state.
	 * Parameter        : 
	 * @stateName       : Name of the state license belong to.
	 * Return           : None 
	 */
	
	public void selectLicenseState(String stateName) {  
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(selectDlState));

		if (selectDlState!=null) {
			try {
				/*Select setState = new Select(selectDlState);
				setState.selectByVisibleText(stateName);*/
				//selectDlState.sendKeys(stateName);
				/*JavascriptExecutor js = (JavascriptExecutor)driver;
				js.executeScript("arguments[0].click();",selectDlState);*/
				//selectDlState.sendKeys(stateName);
				//selectDlState.click();
			/*	Select market = new Select(selectDlState);
			java.util.List<WebElement> ls = 	market.getOptions();
			for(WebElement ele : ls){
				String s = ele.getText();
				if(s.equals(stateName)){
					ele.click();
					break;
				}*/
				selectDlState.click();
				selectDlState.sendKeys(stateName);
				Log.info("Sales Representative " +stateName
						+" selected from " + CustomerInfoPage.class.getName());
			}
				
			 catch(NoSuchElementException e) {
				e.printStackTrace();
				Log.info("Failed ! Sales Representative "+ stateName 
						+ "Not Found in " + CustomerInfoPage.class.getName());
			}
		}	
	}
	 // function selectLicenseState ends here
	
	/* Function Name    : setCustomerLastName
	 * Description      : This function is used to provide input for
	 *                    customer first name.
	 * Parameter        : 
	 * @LastNameValue   : Parameter to hold input value for customer last name
	 * Return           : None 
	 */
	public void setLicenseNumber(String licenseNumberValue ) {  
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(selectDlNumber));

		if (selectDlNumber!=null) {
			try {
				selectDlNumber.clear();
				Log.info("Passed : "+ CustomerInfoPage.class.getName()
						+ "- Textbox : " + selectDlNumber + " is cleared.");
				selectDlNumber.sendKeys(licenseNumberValue);
				Log.info("Passed : "+ CustomerInfoPage.class.getName()
						+ "- Textbox : " + selectDlNumber + " is set to "
						+ licenseNumberValue + ".");
			} catch(NoSuchElementException e) {
				e.printStackTrace();
				Log.info("Failed :" + CustomerInfoPage.class.getName()
						+ "- Textbox : " + licenseNumberValue + " not found.");
			}
		}	
	} // function setCustomerLastName ends here
	
	/* Function Name    : setLicenseExpDate
	 * Description      : This function is used to set input for
	 *                    DL Expiration date.
	 * Parameter        : 
	 * @ monthValue     : Input value of month of DL expiration.
	 * @ dateValue      : Input value of date of DL expiration.
	 * @ yearValue      : Input value of year of DL expiration.
	 * Return           : None 
	 */
	public void setLicenseExpDate(String monthValue, String dateValue
			                   , String yearValue) {  
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(dlExpMonth));

		if (dlExpMonth!=null) {
			try {
				dlExpMonth.clear();
				Log.info("Passed : "+ CustomerInfoPage.class.getName()
						+ "- Textbox : " + dlExpMonth + " is cleared.");
				dlExpMonth.sendKeys(monthValue);
				Log.info("Passed : "+ CustomerInfoPage.class.getName()
						+ "- Textbox : " + dlExpMonth + " is set to "
						+ monthValue + ".");	
			} catch(NoSuchElementException e) {
				e.printStackTrace();
				Log.info("Failed :" + CustomerInfoPage.class.getName()
						+ "- Textbox : " + monthValue + " not found.");
			}
		}
		if (dlExpDate!=null) {
			try {
				dlExpDate.clear();
				Log.info("Passed : "+ CustomerInfoPage.class.getName()
						+ "- Textbox : " + dlExpDate + " is cleared.");
				dlExpDate.sendKeys(dateValue);
				Log.info("Passed : "+ CustomerInfoPage.class.getName()
						+ "- Textbox : " + dlExpDate + " is set to "
						+ dateValue + ".");
			} catch(NoSuchElementException e) {
				e.printStackTrace();
				Log.info("Failed :" + CustomerInfoPage.class.getName()
						+ "- Textbox : " + dateValue + " not found.");
			}
		}
		if (dlExpYear!=null) {
			try {
				dlExpYear.clear();
				Log.info("Passed : "+ CustomerInfoPage.class.getName()
						+ "- Textbox : " + dlExpYear + " is cleared.");
				dlExpYear.sendKeys(yearValue);
				Log.info("Passed : "+ CustomerInfoPage.class.getName()
						+ "- Textbox : " + dlExpYear + " is set to "
						+ yearValue + ".");
			} catch(NoSuchElementException e) {
				e.printStackTrace();
				Log.info("Failed :" + CustomerInfoPage.class.getName()
						+ "- Textbox : " + yearValue + " not found.");
			}
		}
	} // function setLicenseExpDate ends here
	
	/* Function Name    : setHomePhoneNumber
	 * Description      : This function is used to set input for
	 *                    DL Expiration date.
	 * Parameter        : 
	 * @ monthValue     : Input value of month of DL expiration.
	 * @ dateValue      : Input value of date of DL expiration.
	 * @ yearValue      : Input value of year of DL expiration.
	 * Return           : None 
	 */
	public void setHomePhoneNumber(String inputValueOne, String inputValueTwo
			                   , String inputValueThree) {  
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(homePhoneFirst));

		if (homePhoneFirst!=null) {
			try {
				homePhoneFirst.clear();
				Log.info("Passed : "+ CustomerInfoPage.class.getName()
						+ "- Textbox : " + homePhoneFirst + " is cleared.");
				homePhoneFirst.sendKeys(inputValueOne);
				Log.info("Passed : "+ CustomerInfoPage.class.getName()
						+ "- Textbox : " + homePhoneFirst + " is set to "
						+ inputValueOne + ".");	
			} catch(NoSuchElementException e) {
				e.printStackTrace();
				Log.info("Failed :" + CustomerInfoPage.class.getName()
						+ "- Textbox : " + inputValueOne + " not found.");
			}
		}
		if (homePhoneSecond!=null) {
			try {
				homePhoneSecond.clear();
				Log.info("Passed : "+ CustomerInfoPage.class.getName()
						+ "- Textbox : " + homePhoneSecond + " is cleared.");
				homePhoneSecond.sendKeys(inputValueTwo);
				Log.info("Passed : "+ CustomerInfoPage.class.getName()
						+ "- Textbox : " + homePhoneSecond + " is set to "
						+ inputValueTwo + ".");
			} catch(NoSuchElementException e) {
				e.printStackTrace();
				Log.info("Failed :" + CustomerInfoPage.class.getName()
						+ "- Textbox : " + inputValueTwo + " not found.");
			}
		}
		if (homePhoneThird!=null) {
			try {
				homePhoneThird.clear();
				Log.info("Passed : "+ CustomerInfoPage.class.getName()
						+ "- Textbox : " + homePhoneThird + " is cleared.");
				homePhoneThird.sendKeys(inputValueThree);
				Log.info("Passed : "+ CustomerInfoPage.class.getName()
						+ "- Textbox : " + homePhoneThird + " is set to "
						+ inputValueThree + ".");
			} catch(NoSuchElementException e) {
				e.printStackTrace();
				Log.info("Failed :" + CustomerInfoPage.class.getName()
						+ "- Textbox : " + inputValueThree + " not found.");
			}
		}
	} // function setHomePhoneNumber ends here
	
	/* Function Name    : selectHomeContactPreference
	 * Description      : This function is used to select contact preference
	 *                    at home phone number.
	 * Parameter        : 
	 * @contactType     : Value of the contact preference.
	 * Return           : None 
	 */
	public void selectHomeContactPreference(String contactType ) {
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(homePhoneContactPref));

		if (homePhoneContactPref!=null) {
			try {
				Select contactValue = new Select(homePhoneContactPref);
				contactValue.selectByVisibleText(contactType);
				Log.info("Sales Representative " +contactType
						+" selected from " + CustomerInfoPage.class.getName());
			} catch(NoSuchElementException e) {
				e.printStackTrace();
				Log.info("Failed ! Sales Representative "+ contactType 
						+ "Not Found in " + CustomerInfoPage.class.getName());
			}
		}	
	} // function selectHomeContactPreference ends here
	
	
	/* Function Name    : setHomePhoneNumber
	 * Description      : This function is used to set input for
	 *                    work phone with extension number.
	 * Parameter        : 
	 * @ monthValue     : Input value of work phone set one.
	 * @ dateValue      : Input value of work phone set two.
	 * @ yearValue      : Input value of work phone set three.
	 * @ inputValueFour : Input value of work phone extension
	 * Return           : None 
	 */
	public void setWorkPhoneNumber(String inputValueOne, String inputValueTwo
			                       , String inputValueThree
			                       , String inputValueFour ) {  
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(workPhoneFirst));

		if (workPhoneFirst!=null) {
			try {
				workPhoneFirst.clear();
				Log.info("Passed : "+ CustomerInfoPage.class.getName()
						+ "- Textbox : " + workPhoneFirst + " is cleared.");
				workPhoneFirst.sendKeys(inputValueOne);
				Log.info("Passed : "+ CustomerInfoPage.class.getName()
						+ "- Textbox : " + workPhoneFirst + " is set to "
						+ inputValueOne + ".");	
			} catch(NoSuchElementException e) {
				e.printStackTrace();
				Log.info("Failed :" + CustomerInfoPage.class.getName()
						+ "- Textbox : " + inputValueOne + " not found.");
			}
		}
		if (workPhoneSecond!=null) {
			try {
				workPhoneSecond.clear();
				Log.info("Passed : "+ CustomerInfoPage.class.getName()
						+ "- Textbox : " + workPhoneSecond + " is cleared.");
				workPhoneSecond.sendKeys(inputValueTwo);
				Log.info("Passed : "+ CustomerInfoPage.class.getName()
						+ "- Textbox : " + workPhoneSecond + " is set to "
						+ inputValueTwo + ".");
			} catch(NoSuchElementException e) {
				e.printStackTrace();
				Log.info("Failed :" + CustomerInfoPage.class.getName()
						+ "- Textbox : " + inputValueTwo + " not found.");
			}
		}
		if (workPhoneThird!=null) {
			try {
				workPhoneThird.clear();
				Log.info("Passed : "+ CustomerInfoPage.class.getName()
						+ "- Textbox : " + workPhoneThird + " is cleared.");
				workPhoneThird.sendKeys(inputValueThree);
				Log.info("Passed : "+ CustomerInfoPage.class.getName()
						+ "- Textbox : " + workPhoneThird + " is set to "
						+ inputValueThree + ".");
			} catch(NoSuchElementException e) {
				e.printStackTrace();
				Log.info("Failed :" + CustomerInfoPage.class.getName()
						+ "- Textbox : " + inputValueThree + " not found.");
			}
		}
		if (workPhoneExtension!=null) {
			try {
				workPhoneExtension.clear();
				Log.info("Passed : "+ CustomerInfoPage.class.getName()
						+ "- Textbox : " + workPhoneExtension + " is cleared.");
				workPhoneExtension.sendKeys(inputValueFour);
				Log.info("Passed : "+ CustomerInfoPage.class.getName()
						+ "- Textbox : " + workPhoneExtension + " is set to "
						+ inputValueFour + ".");
			} catch(NoSuchElementException e) {
				e.printStackTrace();
				Log.info("Failed :" + CustomerInfoPage.class.getName()
						+ "- Textbox : " + inputValueFour + " not found.");
			}
		}
		
	} // function setLicenseExpDate ends here
	
	/* Function Name    : selectWorkContactPreference
	 * Description      : This function is used to select contact preference
	 *                    at work phone number.
	 * Parameter        : 
	 * @contactType     : Value of the contact preference.
	 * Return           : None 
	 */
	public void selectWorkContactPreference(String contactType ) {  
		if (workPhoneContactPref!=null) {
			try {
				Select contactValue = new Select(workPhoneContactPref);
				contactValue.selectByVisibleText(contactType);
				Log.info("Sales Representative " +contactType
						+" selected from " + CustomerInfoPage.class.getName());
			} catch(NoSuchElementException e) {
				e.printStackTrace();
				Log.info("Failed ! Sales Representative "+ contactType 
						+ "Not Found in " + CustomerInfoPage.class.getName());
			}
		}	
	} // function selectWorkContactPreference ends here
	
	/* Function Name    : setPrimaryEmailAddress
	 * Description      : This function is used to set value for
	 *                    primary email address.
	 * Parameter        : 
	 * @LastNameValue   : Parameter to hold input value for primary
	 *                    email address
	 * Return           : None 
	 */
	public void setPrimaryEmailAddress(String primaryEmailValue ) {  
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(primaryEmailId));

		if (primaryEmailId!=null) {
			try {
				primaryEmailId.clear();
				Log.info("Passed : "+ CustomerInfoPage.class.getName()
						+ "- Textbox : " + primaryEmailId + " is cleared.");
				primaryEmailId.sendKeys(primaryEmailValue);
				Log.info("Passed : "+ CustomerInfoPage.class.getName()
						+ "- Textbox : " + primaryEmailId + " is set to "
						+ primaryEmailValue + ".");
			} catch(NoSuchElementException e) {
				e.printStackTrace();
				Log.info("Failed :" + CustomerInfoPage.class.getName()
						+ "- Textbox : " + primaryEmailValue + " not found.");
			}
		}	
	} // function setPrimaryEmailAddress ends here
	
	/* Function Name    : setSecondaryEmailAddress
	 * Description      : This function is used to set value for
	 *                    secondary email address.
	 * Parameter        : 
	 * @LastNameValue   : Parameter to hold input value for secondary
	 *                    email address
	 * Return           : None 
	 */
	public void setSecondaryEmailAddress(String secondryEmailValue ) {  
		if (secondaryEmailId!=null) {
			try {
				secondaryEmailId.clear();
				Log.info("Passed : "+ CustomerInfoPage.class.getName()
						+ "- Textbox : " + secondaryEmailId + " is cleared.");
				secondaryEmailId.sendKeys(secondryEmailValue);
				Log.info("Passed : "+ CustomerInfoPage.class.getName()
						+ "- Textbox : " + secondaryEmailId + " is set to "
						+ secondryEmailValue + ".");
			} catch(NoSuchElementException e) {
				e.printStackTrace();
				Log.info("Failed :" + CustomerInfoPage.class.getName()
						+ "- Textbox : " + secondryEmailValue + " not found.");
			}
		}	
	} // function setSecondaryEmailAddress ends here
	
	/* Function Name    : clickOnPrimaryEmailCheckBox
	 * Description      : This function is used to click on
	 *                    primary email not available check-box.
	 *                    check-box.
	 * Parameter        : None
	 * Return           : None 
	 */
	public void clickOnPrimaryEmailCheckBox() {  
		if (primaryEmailCheckbox!=null) {
			try {
				primaryEmailCheckbox.click();
				Log.info(CustomerInfoPage.class.getName()+ " button click");
			} catch(NoSuchElementException e) {
				e.printStackTrace();
				Log.info("Failed " + CustomerInfoPage.class.getName()
				+ " unable to click on button ");
			}
		}	
	}
	
	/* Function Name    : setEmployerName
	 * Description      : This function is used to set value for
	 *                    employer name.
	 * Parameter        : 
	 * @LastNameValue   : Parameter to hold value of employer name
	 * Return           : None 
	 */
	public void setEmployerName(String employerNameValue ) {  
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(employerName));

		if (employerName!=null) {
			try {
				employerName.clear();
				Log.info("Passed : "+ CustomerInfoPage.class.getName()
						+ "- Textbox : " + employerName + " is cleared.");
				employerName.sendKeys(employerNameValue);
				Log.info("Passed : "+ CustomerInfoPage.class.getName()
						+ "- Textbox : " + employerName + " is set to "
						+ employerNameValue + ".");
			} catch(NoSuchElementException e) {
				e.printStackTrace();
				Log.info("Failed :" + CustomerInfoPage.class.getName()
						+ "- Textbox : " + employerNameValue + " not found.");
			}
		}	
	} // function setSecondaryEmailAddress ends here
	
	/* Function Name    : setAccountPasscode
	 * Description      : This function is used to set account pass-code
	 *                    and re-confirm account pass-code.
	 * Parameter        : 
	 * @ passcodeValue  : Input value account pass-code.
	 * Return           : None 
	 */
	public void setAccountPasscode(String passcodeValue) { 
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(setAccPasscode));

		if (setAccPasscode!=null) {
			try {
				setAccPasscode.clear();
				Log.info("Passed : "+ CustomerInfoPage.class.getName()
						+ "- Textbox : " + setAccPasscode + " is cleared.");
				setAccPasscode.sendKeys(passcodeValue);
				Log.info("Passed : "+ CustomerInfoPage.class.getName()
						+ "- Textbox : " + setAccPasscode + " is set to "
						+ passcodeValue + ".");	
			} catch(NoSuchElementException e) {
				e.printStackTrace();
				Log.info("Failed :" + CustomerInfoPage.class.getName()
						+ "- Textbox : " + passcodeValue + " not found.");
			}
		}
		
		
	} // function setHomePhoneNumber ends here
	
	public void setReAccountPasscode(String passcodeValue) {  
		
		if (reconfirmAccPasscode!=null) {
			try {
				reconfirmAccPasscode.clear();
				Log.info("Passed : "+ CustomerInfoPage.class.getName()
						+ "- Textbox : " + reconfirmAccPasscode + " is cleared.");
				reconfirmAccPasscode.sendKeys(passcodeValue);
				Log.info("Passed : "+ CustomerInfoPage.class.getName()
						+ "- Textbox : " + reconfirmAccPasscode + " is set to "
						+ passcodeValue + ".");
			} catch(NoSuchElementException e) {
				e.printStackTrace();
				Log.info("Failed :" + CustomerInfoPage.class.getName()
						+ "- Textbox : " + passcodeValue + " not found.");
			}
		}
	}
	
	/* Function Name    : clickOnUseStationButton
	 * Description      : This function is used to click on
	 *                    Use Station button.
	 *                    check-box.
	 * Parameter        : None
	 * Return           : None 
	 */
	public void clickOnUseStationButton() {  
		if (clickOnUseStation!=null) {
			try {
				clickOnUseStation.click();
				Log.info(CustomerInfoPage.class.getName()+ " button click");
			} catch(NoSuchElementException e) {
				e.printStackTrace();
				Log.info("Failed " + CustomerInfoPage.class.getName()
				+ " unable to click on button ");
			}
		}	
	} // function clickOnUseStationButton ends here
	
	/* Function Name    : selectExtraSecurity
	 * Description      : This function is used to select Extra Security
	 *                    radio button.
	 * Parameter        : None
	 * Return           : None 
	 */
	public void selectExtraSecurity() {  
		if (optExtraSecurity!=null) {
			try {
				optExtraSecurity.click();
				Log.info(CustomerInfoPage.class.getName()+ " button click");
			} catch(NoSuchElementException e) {
				e.printStackTrace();
				Log.info("Failed " + CustomerInfoPage.class.getName()
				+ " unable to click on button ");
			}
		}	
	} // function selectExtraSecurity ends here
	
	/* Function Name    : selectStandardSecurity
	 * Description      : This function is used to select Standard Security
	 *                    radio button.
	 * Parameter        : None
	 * Return           : None 
	 */
	public void selectStandardSecurity() {  
		if (optStandardSecurity!=null) {
			try {
				optStandardSecurity.click();
				Log.info(CustomerInfoPage.class.getName()+ " button click");
			} catch(NoSuchElementException e) {
				e.printStackTrace();
				Log.info("Failed " + CustomerInfoPage.class.getName()
				+ " unable to click on button ");
			}
		}	
	} // function selectStandardSecurity ends here
	
	/* Function Name    : selectMarketFromDropdown
	 * Description      : This function is used to select market from the
	 *                    drop-down.
	 *  Parameter       : 
	 * @marketArea      : Parameter to hold value of market drop-down value
	 * Return           : None 
	 */
	
	public ServiceDevicePage clickOnAddressValidationPopUp() {
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(continueAddress));

		if (continueAddress!=null) {
		try {
		continueAddress.click();
		Log.info(CustomerInfoPage.class.getName()+ " button click");
		} catch(NoSuchElementException e) {
		e.printStackTrace();
		Log.info("Failed " + CustomerInfoPage.class.getName()
		+ " unable to click on button ");
		}
		}
		return  new ServiceDevicePage(driver);
		} // function clickOnAddressValidationPopUp ends here
	
} // class CustomerInfoPage ends here
