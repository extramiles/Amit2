/*
Description : This class identify and implement all the web
element and its corresponding action of Installment plan agreement page two
 of four.
Version info : V_0.1
Date : 08/06/2017
Author : Devendra Bhavsar
Copyright notice : Tech Mahindra Ltd
 */
package com.pageobject;

import java.util.NoSuchElementException;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;


import com.utility.Logg;
import com.utility.Util;
public class InstallmentPlanPageTwo {
Util u = new Util();
	
	WebDriver driver = u.getDriver();
	 Logger Log = Logg.createLogger();
	public InstallmentPlanPageTwo(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(new AjaxElementLocatorFactory(driver,20),this);
	}
		
	
/*-------------------------------------------------------- Page objects ---------------------------------------------------- */
	
	@FindBy(how = How.ID, using = "emailSigCapButtonId")
	private WebElement btnUseStation;
	
	@FindBy(how = How.ID, using = "btnUseIVR")
	private WebElement btnUseIVR;
	
	@FindBy(how = How.ID, using = "btnSkip")
	private WebElement btnSkip;
	/*-------------------------------------------------------- Page actions ---------------------------------------------------- */
	
	/*Method: clickBtnUseStation
	Description : To click on  button btnUseStation.
	Parameter : None
	Return type : void */
	public void clickBtnUseStation()
	{
		WebElement wePh = btnUseStation; // WebElement object 
		String webElementName = "btnUseStation"; // WebElement object name string
		try {
			wePh.click();
			Log.info("Passed : "+ InstallmentPlanPageTwo.class.getName() + "- Button : " + webElementName + " is clicked.");
			} catch(NoSuchElementException e) {
			e.printStackTrace();
			Log.info("Failed :" + InstallmentPlanPageTwo.class.getName() + "- Button : " + webElementName + " not found.");
			}
	}
	
	/*Method: clickBtnUseIVR
	Description : To click on  button btnUseIVR.
	Parameter : None
	Return type : void */
	public void clickBtnUseIVR()
	{
		WebElement wePh = btnUseIVR; // WebElement object 
		String webElementName = "btnUseIVR"; // WebElement object name string
		try {
			wePh.click();
			Log.info("Passed : "+ InstallmentPlanPageTwo.class.getName() + "- Button : " + webElementName + " is clicked.");
			} catch(NoSuchElementException e) {
			e.printStackTrace();
			Log.info("Failed :" + InstallmentPlanPageTwo.class.getName() + "- Button : " + webElementName + " not found.");
			}
	}
	
	/*Method: clickBtnSkip
	Description : To click on  button btnSkip.
	Parameter : None
	Return type : void */
	public void clickBtnSkip()
	{
		WebElement wePh = btnSkip; // WebElement object 
		String webElementName = "btnSkip"; // WebElement object name string
		try {
			wePh.click();
			Log.info("Passed : "+ InstallmentPlanPageTwo.class.getName() + "- Button : " + webElementName + " is clicked.");
			} catch(NoSuchElementException e) {
			e.printStackTrace();
			Log.info("Failed :" + InstallmentPlanPageTwo.class.getName() + "- Button : " + webElementName + " not found.");
			}
	}
}
