/* * ClassName : SummaryPage
Description : This class identifies and implements all the web
elements and their corresponding actions of Summary page.
Version info : V_0.1
Date : 01/06/2017
Author : Tech Mahindra
Copyright notice : Tech Mahindra Ltd 
 */

package com.pageobject;

import org.apache.log4j.Logger;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.utility.Logg;
import com.utility.Util;

public class SellPinPage {

	String webElementName;
	Util u = new Util();
	WebDriver driver = u.getDriver();
	Logger Log = Logg.createLogger();

	public SellPinPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(new AjaxElementLocatorFactory(driver, 20),
				this);
		
		}
	@FindBy(how = How.XPATH, using = "//table[@class='grid']/tbody/tr[2]/td[1]/label/input")
	private WebElement radioTen$Pin;
	
	
	@FindBy(how = How.ID, using = "pinlist_1")
	private WebElement selectPrintApply;
	
	/*@FindBy(how = How.ID, using = "btnnext")
	private WebElement btnAddToCart;*/
	@FindBy(how = How.XPATH, using = "//button[@id='btnnext']/b/em/u[text()='Add to Cart']")
	private WebElement btnAddToCart;
	
	@FindBy(how = How.ID, using = "btncancel")
	private WebElement btnCancel;
	
	
	@FindBy(how = How.ID, using = "btnaddfeature")
	private WebElement btnAddFeatures;
	
	
	@FindBy(how = How.XPATH, using = "//button[@id='paynowbutton']/b/em/u[text()='Pay Now']")
	private WebElement btnPayNowCart;
	
	@FindBy(how = How.XPATH, using = "//button[@id='paynowbutton']/b/em/u[text()='Pay Now']")
	private WebElement btnPayNowCSCart;
	
	@FindBy(how = How.XPATH, using = "//table[@class='grid']/tbody/tr[2]/td[2]/select")
	private WebElement selectNowAndLater;
	/*
	 * Method: public void clickTenPin() Description : To click select $10 PIN. Parameter : None
	 * Return type : Void
	 */
	public void clickTenPin() {
		webElementName = "radioTen$Pin";
		try {
			u.closeAllOtherWindows(driver);
			u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(radioTen$Pin));
			if (radioTen$Pin.isSelected()) {
				Log.info("Passed" + SellPinPage.class.getName() + ","
						+ "$10 PIN is pre selected");
			} else {
				radioTen$Pin.click();
				Log.info("Passed" + SellPinPage.class.getName() + ","
						+ "$10 PIN selected");
			}
		} catch (NoSuchElementException e) {
			e.printStackTrace();
			Log.info("Failed" + SellPinPage.class.getName() + webElementName
					+ " not found ");
		}
	}
	//Apply Funds Now     //Print PIN For Later Use
	public void selectOptionNowAndLater(String option) {
		webElementName = "selectNowAndLater";
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(selectNowAndLater));
		try {
			selectNowAndLater.click();
			selectNowAndLater.sendKeys(option);
			selectNowAndLater.click();
				Log.info("Passed" + SellPinPage.class.getName() + ","
						+ "$10 PIN selected");
			}
		catch (NoSuchElementException e) {
			e.printStackTrace();
			Log.info("Failed" + SellPinPage.class.getName() + webElementName
					+ " not found ");
		}
	}
	
	/*
	 * Method: selectPayment Description : To select payment from Apply Funds and Print for Later. Parameter :
	 * 
	 * @setApplyOrPrint : Parameter to hold input value of primary email id.(A or P)
	 * Return type : Void
	 */

	public void selectPayment(String setApplyOrPrint) {
		webElementName = "selectPrintApply";
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(selectPrintApply));
		if (setApplyOrPrint != null) {
			try {
				selectPrintApply.click();
				
				selectPrintApply.sendKeys(setApplyOrPrint);
				Log.info("Passed" + SellPinPage.class.getName() + ","
						+  " Apply Funds or Print option selected ");
			} catch (NoSuchElementException e) {
				e.printStackTrace();
				Log.info("Failed" + SellPinPage.class.getName()
						+ webElementName + " not found ");
			}
		}
	}
	
	/*
	 * Method: clickAddToCart Description : To click on Add To Cart button.
	 * Parameter : None Return type : Void
	 */
	public SellPinPage clickAddToCart() {
		webElementName = "btnAddToCart";
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(btnAddToCart));
		try {
			btnAddToCart.click();
			Log.info("Passed" + SellPinPage.class.getName() + ","
					+ "Add To cart  clicked");
		} catch (NoSuchElementException e) {
			e.printStackTrace();
			Log.info("Failed" + SellPinPage.class.getName() + webElementName
					+ " not found ");
		}
		return new SellPinPage(driver);
	}
	
	/*
	 * Method: clickCancel Description : To click on Cancel button.
	 * Parameter : None Return type : Void
	 */
	public void clickCancel() {
		webElementName = "btnCancel";
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(btnCancel));
		try {
			btnCancel.click();
			Log.info("Passed" + SellPinPage.class.getName() + ","
					+ "Cancel button clicked");
		} catch (NoSuchElementException e) {
			e.printStackTrace();
			Log.info("Failed" + SellPinPage.class.getName() + webElementName
					+ " not found ");
		}
	}
	
	/*
	 * Method: clickAddFeatures Description : To click on Add Features button.
	 * Parameter : None Return type : Void
	 */
	public void clickAddFeatures() {
		webElementName = "btnAddFeatures";
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(btnAddFeatures));
		try {
			btnAddFeatures.click();
			Log.info("Passed" + SellPinPage.class.getName() + ","
					+ "Finished clicked");
		} catch (NoSuchElementException e) {
			e.printStackTrace();
			Log.info("Failed" + SellPinPage.class.getName() + webElementName
					+ " not found ");
		}
	}
	
	/*
	 * Method: clickPayNowCart Description : To click on Pay Now button.
	 * Parameter : None Return type : Void
	 */
	public void clickPayNowCart() {
		webElementName = "btnPayNowCart";
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(btnPayNowCart));
		try {
			btnPayNowCart.click();
			Log.info("Passed" + SellPinPage.class.getName() + ","
					+ "Pay Now clicked");
		} catch (NoSuchElementException e) {
			e.printStackTrace();
			Log.info("Failed" + SellPinPage.class.getName() + webElementName
					+ " not found ");
		}
		//return new TaxTypeInfoPage(driver);
	}
	
	
	
	public TaxTypeInfoPage clickPayNowCSCart() {
		webElementName = "btnPayNowCSCart";
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(btnPayNowCSCart));
		try {
			btnPayNowCSCart.click();
			Log.info("Passed" + SellPinPage.class.getName() + ","
					+ "Pay Now clicked");
		} catch (NoSuchElementException e) {
			e.printStackTrace();
			Log.info("Failed" + SellPinPage.class.getName() + webElementName
					+ " not found ");
		}
		return new TaxTypeInfoPage(driver);
	}
	
}
