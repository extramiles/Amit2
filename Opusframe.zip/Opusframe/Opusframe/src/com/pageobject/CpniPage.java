 /* ClassName            : CpniPage
  * Description          : This class identify and implement all the web
  *                        element and its corresponding action of CPNI
  *                        Consent page.
  * Version info         : V_0.1
  * Date                 : 01/06/2017
  * Author               : Tech Mahindra
  * Copyright notice     : Tech Mahindra Ltd 
  */

package com.pageobject;

import java.util.NoSuchElementException;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.utility.Logg;
import com.utility.Util;

public class CpniPage {
	Util u = new Util();
	WebDriver driver = u.getDriver();
	Logger l = Logg.createLogger();
	// Constructor for class CpniPage
	public CpniPage (WebDriver driver) {
		this.driver=driver;

		PageFactory.initElements(driver,this);
	} // Constructor CpniPage ends here
	
	// Web element locator for On Hold Transactions Page
	
	@FindBy(how=How.NAME, using = "cpniConsent")
	public WebElement customerResponseYes;
	
	@FindBy(how=How.ID,using="btnNextCPNI")
	public WebElement nextButton;
	
	@FindBy(how=How.ID,using="btnCancel")
	public WebElement cancelButton;
	
	
	public void clickTo() {
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(customerResponseYes));
		if (customerResponseYes!=null) {
			try {
				customerResponseYes.click();
				l.info(CpniPage.class.getName() +"able to click button");

			} catch(NoSuchElementException e) {
					e.printStackTrace();
					l.info(CpniPage.class.getName() + "unable to click on button");

			}
		}
	} // function clickTo ends here
	
	public PcaPage clickNextButton() {  
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(nextButton));
		if (nextButton!=null) {
			try {
				nextButton.click();
				l.info(CpniPage.class.getName()+ " able to click button");

			} catch(NoSuchElementException e){
					e.printStackTrace();
					l.info("Failed" + CpniPage.class.getName()+ "unable to click on button");

		    }
		}
		return new PcaPage(driver);
	} // function clickNextButton ends here
	
} // class ends here
