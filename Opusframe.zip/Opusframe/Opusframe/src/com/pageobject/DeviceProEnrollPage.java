/* * ClassName : DeviceProEnrollPage
Description : This class identifies and implements all the web
elements and their corresponding actions of Device Enrollment page.
Version info : V_0.1
Date : 02/06/2017
Author : Tech Mahindra
Copyright notice : Tech Mahindra Ltd 
 */

package com.pageobject;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.utility.Logg;
import com.utility.Util;

public class DeviceProEnrollPage {

	Util u = new Util();
	WebDriver driver = u.getDriver();
	Logger Log = Logg.createLogger();
	//WebDriver driver;
	String webElementName;

	public DeviceProEnrollPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(new AjaxElementLocatorFactory(driver, 20),
				this);
	}

	@FindBy(how = How.CLASS_NAME, using = "leftArrow")
	private WebElement btnChangeFeatures;

	@FindBy(how = How.ID, using = "btnSkip")
	private WebElement btnSkip;

	@FindBy(how = How.ID, using = "emailSigCapButtonId")
	private WebElement btnUseStation;

	/*
	 * Method: clickChangeFeatures Description : To click on Change Features
	 * button which takes you back to Rate Plan page. Parameter : None Return
	 * type : Void
	 */
	public void clickChangeFeatures() {
		webElementName = "btnChangeFeatures";
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(btnChangeFeatures));
		try {
			btnChangeFeatures.click();
			Log.info("Passed" + DeviceProEnrollPage.class.getName() + ","
					+ "Change Features button clicked");
		} catch (NoSuchElementException e) {
			e.printStackTrace();
			Log.info("Failed" + DeviceProEnrollPage.class.getName()
					+ webElementName + " not found ");
		}
	}

	/*
	 * Method: clickSkip Description : To click on Skip button to skip Signature
	 * Capture. Parameter : None Return type : Void
	 */
	public DeclineDeviceProEnrollPage clickSkip() {
		webElementName = "btnSkip";
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(btnSkip));
		try {
			btnSkip.click();
			Log.info("Passed" + DeviceProEnrollPage.class.getName() + ","
					+ "Skip button clicked");
		} catch (NoSuchElementException e) {
			e.printStackTrace();
			Log.info("Failed" + DeviceProEnrollPage.class.getName()
					+ webElementName + " not found ");
		}
		return new DeclineDeviceProEnrollPage(driver);
	}

	/*
	 * Method: clickUseStation Description : To click on USe Station button to
	 * launch Signature Capture. Parameter : None Return type : Void
	 */
	public void clickUseStation() {
		webElementName = "btnUseStation";
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(btnUseStation));
		try {
			btnUseStation.click();
			Log.info("Passed" + DeviceProEnrollPage.class.getName() + ","
					+ "Use Station button clicked");
		} catch (NoSuchElementException e) {
			e.printStackTrace();
			Log.info("Failed" + DeviceProEnrollPage.class.getName()
					+ webElementName + " not found ");
		}
	}

}
