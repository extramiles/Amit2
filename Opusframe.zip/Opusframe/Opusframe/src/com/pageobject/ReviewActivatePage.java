/* * ClassName : ReviewActivatePage
Description : This class identifies and implements all the web
elements and their corresponding actions of Review and Activate page.
Version info : V_0.1
Date : 01/06/2017
Author : Tech Mahindra
Copyright notice : Tech Mahindra Ltd 
 */

package com.pageobject;

import org.apache.log4j.Logger;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;




import com.utility.Logg;
import com.utility.Util;

public class ReviewActivatePage {

	//WebDriver driver;
	Select selectD;
	String webElementName;
	Util u = new Util();
	WebDriver driver = u.getDriver();
	Logger Log = Logg.createLogger();

	public ReviewActivatePage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(new AjaxElementLocatorFactory(driver, 20),
				this);
	}

	/*
	 * @FindBy(how=How.ID,using="selectedPAH") private WebElement
	 * primaryAccountHolderDropdown;
	 */

	@FindBy(how = How.XPATH, using = "//div[@class='buttonArea']/button[text()='Cancel']")
	private WebElement btnCancel;

	@FindBy(how = How.XPATH, using = "//div[@class='buttonArea']/button[text()='Previous']")
	private WebElement btnPrevious;

	@FindBy(how = How.ID, using = "activationButton")
	private WebElement btnActivate;

	/*
	 * Method: clickCancel Description : To click on Cancel button to cancel the
	 * transaction. Parameter : None Return type : Void
	 */
	public void clickCancel() {
		webElementName = "btnCancel";
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(btnCancel));
		try {
			btnCancel.click();
			Log.info("Passed" + ReviewActivatePage.class.getName() + ","
					+ "Cancel button clicked");
		} catch (NoSuchElementException e) {
			e.printStackTrace();
			Log.info("Failed" + ReviewActivatePage.class.getName()
					+ webElementName + " not found ");
		}
	}

	/*
	 * Method: clickPrevious Description : To click on Previous button to go
	 * back to Rate Plan page. Parameter : None Return type : Void
	 */
	public void clickPrevious() {
		webElementName = "btnPrevious";
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(btnPrevious));
		try {
			btnPrevious.click();
			Log.info("Passed" + ReviewActivatePage.class.getName() + ","
					+ "Previous button clicked");
		} catch (NoSuchElementException e) {
			e.printStackTrace();
			Log.info("Failed" + ReviewActivatePage.class.getName()
					+ webElementName + " not found ");
		}
	}

	/*
	 * Method: clickActivate Description : To click on Activate button to
	 * proceed. Parameter : None Return type : Void
	 */
	public SummaryPage clickActivate() {
		webElementName = "btnActivate";
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(btnActivate));
		try {
			if (btnActivate.isEnabled()) {
				btnActivate.click();
				Log.info("Passed" + ReviewActivatePage.class.getName() + ","
						+ "Next button clicked");
			} else {
				Log.info("Failed" + ReviewActivatePage.class.getName()
						+ webElementName + " is disabled ");
			}
		} catch (NoSuchElementException e) {
			e.printStackTrace();
			Log.info("Failed" + ReviewActivatePage.class.getName()
					+ webElementName + " not found ");
		}
		return new SummaryPage(driver);
	}

}
