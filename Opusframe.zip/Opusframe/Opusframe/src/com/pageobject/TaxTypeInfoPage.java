 /* ClassName            : TaxTypeInfoPage
  * Description          : This class identify and implement all the web
  *                        element and its corresponding action of Tax Type
  *                        and Information page.
  * Version info         : V_0.1
  * Author               : Tech Mahindra
  * Copyright notice     : Tech Mahindra Ltd. 
  */
package com.pageobject;

import java.util.NoSuchElementException;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;

import com.utility.Logg;
import com.utility.Util;



public class TaxTypeInfoPage {
	
	Util u = new Util();
	WebDriver driver = u.getDriver();
	Logger Log = Logg.createLogger();
	
	// Constructor for class HomePage
	public TaxTypeInfoPage(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver,this);
	}
	
	/* Web Element Locator for Tax Type & Tax Information page */ 
	 
	// Select tag for tax type
	@FindBy(how=How.ID, using = "tax_type") 
	public WebElement selectTaxType;
	
	// Select tag for submit button
	@FindBy(how=How.ID, using = "btnSubmit") 
	public WebElement submitButton;
		
	// Locator for cancel button
	@FindBy(how=How.ID, using = "btnCancel") 
	public WebElement cancelButton;
	
	// Locator for Trade-In button
	@FindBy(how=How.NAME, using = "blueButton") 
	public WebElement tradeInButton;
	
	// Locator for check-out button
	@FindBy(how=How.ID, using = "opusmobilecheckout") 
	public WebElement checkoutButton;

	@FindBy(how=How.NAME, using = "overrideManagerID") 
	public WebElement selectApprover;
	
	
	@FindBy(how=How.NAME, using = "managerPassword") 
	public WebElement textPassword;
	/* Function implementation of page Tax Type & Tax Information */
	
	/* Function Name    : selectMarketFromDropdown
	 * Description      : This function is used to select market from the
	 *                    drop-down.
	 *  Parameter       : 
	 * @taxTypeValue    : Parameter to hold value of market drop-down value
	 * Return           : None 
	 */
	public void setTaxType(String taxTypeValue ) { 
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(selectTaxType));

		if (selectTaxType!=null) {
			try {
				Select getTaxType = new Select(selectTaxType);
				getTaxType.selectByVisibleText(taxTypeValue);
				Log.info("store " + taxTypeValue + " selected from "
				+ TaxTypeInfoPage.class.getName());
			} catch(NoSuchElementException e) {
				e.printStackTrace();
				Log.info("Failed Store " + taxTypeValue 
						+ "Not Found in " + TaxTypeInfoPage.class.getName());
			}
		}	
	}
	
	/* Function Name    : clickCancelButton
	 * Description      : This function is used click on Cancel Button.
	 * Parameter        : None
	 * Return           : None 
	 */
	public void clickCancelButton() { 
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(cancelButton));

		if (cancelButton!=null) {
			try {
				cancelButton.click();
				Log.info(TaxTypeInfoPage.class.getName()+ " button click");
			} catch(NoSuchElementException e) {
				e.printStackTrace();
				Log.info("Failed " + TaxTypeInfoPage.class.getName()
				+ " unable to click on button ");
			}
		}	
	} // function clickCancelButton ends here
	
	/* Function Name    : clickSubmitButton
	 * Description      : This function is used click on Submit Button.
	 * Parameter        : None
	 * Return           : None 
	 */
	public TransactionCmplPage clickSubmitButton() {  
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(submitButton));

		if (submitButton!=null) {
			try {
				submitButton.click();
				Log.info(TaxTypeInfoPage.class.getName()+ " button click");
			} catch(NoSuchElementException e) {
				e.printStackTrace();
				Log.info("Failed " + TaxTypeInfoPage.class.getName()
				+ " unable to click on button ");
			}
		}
		return new TransactionCmplPage(driver);
	} // function clickSubmitButton ends here
	
	/* Function Name    : clickTradeInButton
	 * Description      : This function is used click on Trade-In Button.
	 * Parameter        : None
	 * Return           : None 
	 */
	public void clickTradeInButton() {  
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(tradeInButton));

		if (tradeInButton!=null) {
			try {
				tradeInButton.click();
				Log.info(TaxTypeInfoPage.class.getName()+ " button click");
			} catch(NoSuchElementException e) {
				e.printStackTrace();
				Log.info("Failed " + TaxTypeInfoPage.class.getName()
				+ " unable to click on button ");
			}
		}	
	} // function clickTradeInButton ends here
	
	/* Function Name    : clickCheckoutButton
	 * Description      : This function is used click on Check-out Button.
	 * Parameter        : None
	 * Return           : None 
	 */
	public void clickCheckoutButton() {  
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(checkoutButton));

		if (checkoutButton!=null) {
			try {
				checkoutButton.click();
				Log.info(TaxTypeInfoPage.class.getName()+ " button click");
			} catch(NoSuchElementException e) {
				e.printStackTrace();
				Log.info("Failed " + TaxTypeInfoPage.class.getName()
				+ " unable to click on button ");
			}
		}	
	} // function clickTradeInButton ends here
	
	
	
	/*Method: set
	Description : To select the value of Select .
	Parameter : @value -  
	Return type : WebElement */
	public WebElement setSelectApprover(String value)
	{ 
		WebElement wePh = selectApprover; // WebElement object
		String webElementName = "selectApprover"; // WebElement object name string
		if (value!=null) {
			try {
				 Select selectWE = new Select(wePh);
				 selectWE.selectByValue(value);
				 Log.info("Passed : "+ ServiceDevicePage.class.getName() + "- Select : " + webElementName + " is set to " + value + ".");
			} catch(NoSuchElementException e) {
				e.printStackTrace();
				Log.info("Failed :" + ServiceDevicePage.class.getName() + "- Select : " + webElementName + " not found.");
			}
		}
		return wePh;
	}
	
	
	
	/*Method: setTextPassword
	 Description : To set the value of input(text) textPassword.
	 Parameter : @value - 
	 Return type : WebElement */
	
	public WebElement setTextPassword(String value)
	{
		WebElement wePh = textPassword; // WebElement object 
		String webElementName = "textPassword"; // WebElement object name string
		if(value!=null){
			try
			{
				wePh.clear();
				Log.info("Passed : "+ ServiceDevicePage.class.getName() + "- Textbox : " + webElementName + " is cleared.");
				wePh.sendKeys(value);
				Log.info("Passed : "+ ServiceDevicePage.class.getName() + "- Textbox : " + webElementName + " is set to " + value + ".");
			}
			catch(NoSuchElementException e)
			{
				e.printStackTrace();
				Log.info("Failed :" + ServiceDevicePage.class.getName() + "- Textbox : " + webElementName + " not found.");
			}
		}
		return wePh;
	}
} // class TaxTypeInfoPage ends here
