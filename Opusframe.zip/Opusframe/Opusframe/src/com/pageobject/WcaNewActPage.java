package com.pageobject;

import java.util.NoSuchElementException;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.utility.Logg;
import com.utility.Util;

public class WcaNewActPage {
	Util u = new Util();
	WebDriver driver = u.getDriver();
	Logger Log = Logg.createLogger();

	public WcaNewActPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(new AjaxElementLocatorFactory(driver,20),this);
	}
	
	@FindBy(how = How.XPATH, using = "//button[@id='btnOk']/b/em/u[text()='Ok']")
	private WebElement btnwca;
	
	public void clickBtnWcaStation()
	{
		WebElement wePh = btnwca; // WebElement object 
		//String webElementName = "btnwca"; // WebElement object name string
		u.waits(15000);
		u.closeAllOtherWindows(driver);
		
		
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(btnwca));
		try {
			wePh.click();
			Log.info("Passed : "+ WcaPage.class.getName() + "- Button : " + wePh + " is clicked.");
			} catch(NoSuchElementException e) {
			e.printStackTrace();
			Log.info("Failed :" + WcaPage.class.getName() + "- Button : " + wePh + " not found.");
			}
	}
	
}
