package code.jjava;

import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;

public class ListCollection {
	
	public static void main(String []args){
		ListCollection classObj = new ListCollection();
		//classObj.removeDuplicate();
		classObj.forEachIterate();
	}
	
	public void forEachIterate(){
		List<String> listObj = new LinkedList<String>();
		listObj.add("ABC");
		listObj.add("XYZ");
		listObj.add("ABC");
		listObj.add("PQR");
		listObj.add("PQR");
		listObj.add("XYZ");
		for(String str : listObj ){
		System.out.println(" String Value is *****<<<<< -->>>>>            "+str);
		}
	}
	
	public void removeDuplicate(){
        List<String> listObj = new LinkedList<String>();
		listObj.add("ABC");
		listObj.add("XYZ");
		listObj.add("ABC");
		listObj.add("PQR");
		listObj.add("PQR");
		listObj.add("XYZ");
		System.out.println("Items present currently in List -->>>>>            "+listObj);
		Set<String> setObj = new LinkedHashSet<String>(listObj);
		System.out.println("Items present After removal of duplicacy in set ********----->>>>>>      "+setObj);
		//Set<String> setObj = new LinkedHashSet<String>();
		setObj.addAll(listObj);
		//listObj.addAll(setObj);
		System.out.println("Again printing******Items present After removal of duplicacy in set -->>>>>            "+setObj);
	} // function removeDuplicate ends here

}
