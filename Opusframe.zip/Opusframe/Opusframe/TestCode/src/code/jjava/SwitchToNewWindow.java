package code.jjava;

import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;

public class SwitchToNewWindow {
	
	WebDriver driver;
	
	@Test
	public void testSwitchToNewWindow() {
		
		System.setProperty("webdriver.ie.driver","D://VM00505968//TECHM//Selenium//OPUS//OpusAutomation//DriverFile//IEDriverServer.exe");
		
		driver = new InternetExplorerDriver();
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		driver.navigate().to("http://toolsqa.com/automation-practice-switch-windows/");
		//Wait for the frame to be available and switch to it
		WebDriverWait wait = new WebDriverWait(driver, 5);
		
		//wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(By.xpath(".//*[@id='button1']")));

		driver.get("http://toolsqa.wpengine.com/automation-practice-switch-windows/");
		 
        // Store and Print the name of the First window on the console

        String handle= driver.getWindowHandle();

        System.out.println(handle);
        // Click on the Button "New Message Window"
        driver.findElement(By.xpath(".//*[@id='button1']")).click();
        // Store and Print the name of all the windows open	              
        Set handles = driver.getWindowHandles();
        System.out.println(handles);
        // Pass a window handle to the other window
        for (String handle1 : driver.getWindowHandles()) {
        	System.out.println(handle1);
        	driver.switchTo().window(handle1);
        	driver.manage().window().maximize();
        	System.out.println(driver.getTitle());
        	}
        // Closing Pop Up window
        //driver.close();
        // Close Original window
        //driver.quit();
	}

}
