package code.jjava;

import java.awt.AWTException;
import java.awt.Robot;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
public class WebTable {
public static void main(String[] args) throws AWTException {
	
	System.setProperty("webdriver.ie.driver","D://VM00505968//TECHM//Selenium//OPUS//OpusAutomation//DriverFile//IEDriverServer.exe");
	
	WebDriver driver = new InternetExplorerDriver();
	driver.manage().window().maximize();
	
	driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	driver.get("http://toolsqa.wpengine.com/automation-practice-table");
	
	//Here we are storing the value from the cell in to the string variable
	String sCellValue = driver.findElement(By.xpath(".//*[@id='content']/table/tbody/tr[1]/td[2]")).getText();
	System.out.println(sCellValue);
	
	// Here we are clicking on the link of first row and the last column
	//driver.findElement(By.xpath(".//*[@id='content']/table/tbody/tr[1]/td[6]/a")).click();        
	System.out.println("Link has been clicked otherwise an exception would have thrown");
	//driver.close();
	
	Robot robot = new Robot();
	
	
	
}
}