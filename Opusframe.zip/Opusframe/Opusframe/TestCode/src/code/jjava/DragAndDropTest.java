package code.jjava;

import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;

	public class DragAndDropTest {

		WebDriver driver;
		
		@Test
		public void testDragAndDropExample() {
			
			System.setProperty("webdriver.ie.driver","D://VM00505968//TECHM//Selenium//OPUS//OpusAutomation//DriverFile//IEDriverServer.exe");
			
			driver = new InternetExplorerDriver();
			driver.manage().window().maximize();
			driver.manage().deleteAllCookies();
			driver.navigate().to("http://jqueryui.com/droppable/");
			//Wait for the frame to be available and switch to it
			WebDriverWait wait = new WebDriverWait(driver, 5);
			wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(By.cssSelector(".demo-frame")));
			WebElement Sourcelocator = driver.findElement(By.cssSelector(".ui-draggable"));
			WebElement Destinationlocator = driver.findElement(By.cssSelector(".ui-droppable"));
			Actions builder = new Actions(driver);
			builder.dragAndDrop(Sourcelocator,Destinationlocator).build().perform();
			String actualText=driver.findElement(By.cssSelector("#droppable>p")).getText();
			Assert.assertEquals(actualText, "Dropped!");
		}
	}

