package code.jjava;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

public class ElementDup {
	 
	    public static void main(String[] args) { 
	    	int i;
	    	String a1,a2;
	        List<String> l = new ArrayList<String>();  
	        l.add("Mango");  
	        l.add("Mango");
	        l.add("Apple");
	      //  l.add("Mango");  
	        l.add("Apple");  
	       // System.out.println(l.toString());
	        System.out.println("Value"+l);
	        int len = l.size();
	        System.out.println("Length....."+len);
	        /*
	        for (i = 0; i < len; i++ ){
	        	a1 = l.get(i);
	        	a2 = l.get(i+0);
	        	
	        	if(a1.equals(a2)){
	        		l.remove(a1);
	        	} 
	        } */
	        System.out.println("Value"+l);
	        /*  
	        Set<String> s = new LinkedHashSet<String>(l);  
	        System.out.println(s); 
	        */
	        }  
}  

