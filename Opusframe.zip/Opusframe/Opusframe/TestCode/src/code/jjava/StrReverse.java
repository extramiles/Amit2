package code.jjava;

import java.util.Scanner;

public class StrReverse {
	
	public static void main(String args[]){
		
		StrReverse obj = new StrReverse();
		//obj.lengthString();
		//obj.reverseString();
		obj.eachStringReverse();
		
	} // main method ends here
	
	// function to reverse each string in an statement
	public void eachStringReverse(){
		int len = 0;
		Scanner sc = new Scanner(System.in);
		System.out.println("Pls enetr statement to reverse individially **** >>>>\n");
		String str = sc.nextLine();
		for(char ch : str.toCharArray()){
			if(ch!='\0'){
				len++;
			}
		}
		System.out.println("Length of enetered string is**** "+len);
		len = len-1;
		String strRev = "";
		String []arrStr = str.split(" ");
		for(int i = 0; i < arrStr.length; i++) {
			for (int j = arrStr[i].length()-1; j >=0; j--){
				strRev = strRev + arrStr[i].charAt(j);	
			}
			strRev = strRev + " ";
		}
		System.out.println("String after reversal of words >>>>> "+strRev);
	}
	
	// function to reverse an string
	public void reverseString(){
		int len = 0;
		String revStr = "";
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter string to reverse\n");
		String str = sc.nextLine();
		for(char ch : str.toCharArray()){
			if(ch!='\0'){
				len++;
			}
		}
		len = len-1;
		System.out.println("Length of enetered string is**** "+len);
		for (int i = len; i >=0; i--){
			revStr = revStr + str.charAt(i);
		}
		
		System.out.println("String after reversal is **** "+revStr);
	}
	
	
	// Function to find/calculate string length
	public void lengthString(){
		int count = 0;
		Scanner sc = new Scanner(System.in);
		System.out.println("Please enter string to find its length \n");
		String str = sc.nextLine();
		
		//str = str + '\0';
		
		for(char c : str.toCharArray()) {
			if(c!='\0'){
			
				count++;
			} 
		}
		
		System.out.println("String length is ******* "+count);
	} //

} // class ends here
