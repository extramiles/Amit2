package com.module.wireless;

import java.io.IOException;

import org.testng.Reporter;
import org.testng.annotations.Test;

import static org.testng.Assert.assertEquals;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.PropertyConfigurator;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.ITestContext;
import org.testng.ITestResult;
import org.testng.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.excelutils.ReadingExcel;
import com.module.SuperTestNG;
import com.opusbase.TestBase;


public class WirelessActivation02 extends SuperTestNG {

	
	@Test
	public void goPhoneActivation() throws IOException
	{
		String[] key =getDataFromExcel("goPhoneActivation","Sheet1");
		
		sc.selectDropDownsd(key[0]);
		Assert.assertEquals(sc.getStoreSelectionPageTitle(),"OPUS Login");
		//fullPageScreenShot("Wireless_Activation");
	

		sc.click();
		lpa.enterUserName(key[1]);
		lpa.enterPassword(key[2]);
		
		
		fullPageScreenShot("Wireless_Activation");
		lpa.click();
		
		fullPageScreenShot("Wireless_Activation");
		rmlpa.click();
		Reporter.log("Login successful wirelessTest02_01");
		hpa.switchToFrameHomePage();
		hpa.click();
		//fullPageScreenShot("Navigate_to_home_page");
		Reporter.log("Home page shall be displayed");

		Assert.assertEquals(verifyPageHeader(hpa.homePageHeader,driver).substring(0, 9),"Home Page");
		Reporter.log("Home page Validated");

		hpa.clickTo();
		hpa.enterAddressLineOne(key[3]);
		hpa.setCityValue(key[4]);
		
		hpa.selectStateHomePage(key[5]);
		
		hpa.setZipCodeHomePage(key[6]);
		hpa.clickToCheckAvailability();
		Reporter.log("CPNI page shall be displayed wirelessTest02_02");
		Assert.assertEquals(verifyPageHeader(cpni.cpniHeader,driver),"CPNI");
		Reporter.log("Cpni page Validated");
		cpni.clickTo();
		cpni.clickNextButton();
		Reporter.log("PCA page shall be displayed wirelessTest02_03");
		Assert.assertEquals(verifyPageHeader(pca.pcaHeader,driver).substring(0, 15),"Service Profile");
		Reporter.log("PCA page Validated");
		pca.SelectWireless();
		pca.SelectPPrepaidPlan();
		pca.SetPortNumberNo();
		pca.ClickBeginOrder();
		Reporter.log("Customer information page shall be displayed wirelessTest02_04");
		Assert.assertEquals(verifyPageHeader(ci.custinfoHeader,driver),"Customer Information");
		Reporter.log("Customer Info page Validated");
		ci.selectpayAsYouGoPlan();
		
		ci.setCustomerFirstName(key[7]);
		
		ci.setCustomerLastName(key[8]);
		
		ci.setHomePhoneNumber(key[9], key[10], key[11]);
		
		ci.setWorkPhoneNumber(key[12],key[13], key[14], key[15]);
	
		ci.setPrimaryEmailAddress(key[16]);
		ci.setEmployerName(key[17]);
		/*if(ci.streetNum.isEnabled())
		{
		ci.setStreetNumber("1202");
		ci.setStreetName("main st");
		ci.setCity("Dallas");
		ci.setState("Texas");
		ci.setZipCode("75202");
		}*/
		
		ci.clickNext();
		Reporter.log("Address validation pop up shall be displayed wirelessTest02_05");
		Assert.assertEquals(verifyPageHeader(ci.custinfoAddressValidHeader,driver),"Address Validation");
		Reporter.log("Customer Info Address popup Validated");
		ci.clickOnAddressValidationPopUp();
		Reporter.log("Service and device page shall be displayed wirelessTest02_06");
		Assert.assertEquals(verifyPageHeader(si.serviceDevicePageHeader,driver),"Service & Device");
		Reporter.log("Service Device page Validated");
		si.setSelectServiceLocation(key[18]);
		//GRANDPRARI TX  GREENVILLE TX
		si.clickBtnFindReqNum();
		Reporter.log("Available subscriber numbers shall be displayed in list wirelessTest02_07");
		si.setSelectAvailWlsNum();
		si.clickBtnReserveNum();
		Reporter.log("Selected number shall be reserved wirelessTest02_08");
		si.setTextSimNumber(key[19]);
		si.setTextIMEI(key[20]);
		si.clickBtnNext();
		Reporter.log("Rate plan and feature page shall be displayed wirelessTest02_09");
		Assert.assertEquals(verifyPageHeader(rp.rateplanPageHeader,driver).substring(0, 22),"Select Plan & Features");
		Reporter.log("Rate Plan page Validated");
		rp.selecPlanType(key[21]);
		rp.selectPlanInd(key[22]);
		rp.clickAddPlan();
		rp.clickNoCommitmentPlan();
		Reporter.log("Selected plan shall be dispalyed alon with contract type and associated features wirelessTest02_10");
		rp.clickContinueBtn();
		Reporter.log("Review and Activate page shall be displayed wirelessTest02_11");
		Assert.assertEquals(verifyPageHeader(rap.reviewAndActivatePageHeader,driver).substring(0, 19),"Review and Activate");
		Reporter.log("Review and Activate page Validated");
		rap.clickActivate();
		Reporter.log("Summary page shall be displayed wirelessTest02_12");
		Assert.assertEquals(verifyPageHeader(sp.summaryPageHeader,driver),"Summary");
		Reporter.log("Summary page Validated");
		sp.clickPinPurchase();
		sp.clickNextGoPh();
		Reporter.log("Customer summary page shall be displayed wirelessTest02_13");
		spp.clickTenPin();  /// Print PIN For Later Use"
		spp.selectOptionNowAndLater(key[23]);
		spp.clickAddToCart();
		Reporter.log("Pin shall be added to tha cart wirelessTest02_14");
		//spp.selectPayment("P");
		//spp.clickAddToCart();
		spp.clickPayNowCart();
		Reporter.log("Tax Type and Tax Information page shall be displayed wirelessTest02_15");
		spp.clickPayNowCSCart();
		Reporter.log("Customer checkout page shall be displayed wirelessTest02_16");
		tp.clickSubmitButton();
		cgp.clickCash();
		String amount = verifyPageHeader(cgp.amountDue,driver).substring(1);
		cgp.enterCashAmount(amount);
		cgp.clickSubmit();
		Reporter.log("Transaction complete popup shall be displayed wirelessTest02_17");
		tc.clickOnDoneButton();
		Reporter.log("Transaction completed page shall be displayed wirelessTest02_18");
		//csp.clickBtnView();
		
		
		
		Reporter.log("Test Case Passed");
		//tear();
		//hpa.clickOnSales();
		
		///hpa.getSalesOptions("Sell Item");
		
		
		/*try{
			//assertEquals(true, false);
			testresultdata.put("2",new Object[] {1d, "Navigate_to_home_page", "page opens and login success","Pass"});
			
		}catch(Exception e){
			testresultdata.put("2
			",new Object[] {1d, "Navigate_to_home_page", "page opens and login success","Fail"});
		}
*/
	}

	
}