package com.module.wireless;

import java.io.IOException;

import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.Test;

import com.google.common.base.Verify;
import com.module.SuperTestNG;

public class WirelessActivation01 extends SuperTestNG
{
	
	@Test(description="Wireless Postpaid Activation")
	public void Wireless_Activation() throws IOException{
		String[] key =getDataFromExcel("Wireless_Activation","Sheet1");
		
		sc.selectDropDownsd(key[0]);
		Assert.assertEquals(sc.getStoreSelectionPageTitle(),"OPUS Login");
		fullPageScreenShot("Wireless_Activation");
	
		sc.click();
		lpa.enterUserName(key[1]);
		lpa.enterPassword(key[2]);
		
		fullPageScreenShot("Wireless_Activation");
		lpa.click();
	
		Reporter.log("Login successful wirelessTest01_01");
		fullPageScreenShot("Wireless_Activation");
		rmlpa.click();
		
		hpa.switchToFrameHomePage();
		
		hpa.click();
		Reporter.log("Home page shall be displayed wirelessTest01_01");
		Assert.assertEquals(verifyPageHeader(hpa.homePageHeader,driver).substring(0, 9),"Home Page");
		Reporter.log("Home page Validated");
		//fullPageScreenShot("Wireless_Activation");
		hpa.clickTo();
		
		hpa.enterAddressLineOne(key[3]);
		
		//fullPageScreenShot("Wireless_Activation");
		hpa.setCityValue(key[4]);
	
		hpa.selectStateHomePage(key[5]);
		
		hpa.setZipCodeHomePage(key[6]);
		
		//fullPageScreenShot("Wireless_Activation");
		hpa.clickToCheckAvailability();
		Reporter.log("CPNI page shall be displayed wirelessTest01_02");
		Assert.assertEquals(verifyPageHeader(cpni.cpniHeader,driver),"CPNI");
		Reporter.log("Cpni page Validated");
		cpni.clickTo();
		
		cpni.clickNextButton();
		Reporter.log("PCA page shall be displayed wirelessTest01_03");
		Assert.assertEquals(verifyPageHeader(pca.pcaHeader,driver).substring(0, 15),"Service Profile");
		Reporter.log("PCA page Validated");
		pca.SelectWireless();
	
		pca.SetPortNumberNo();
		
		pca.ClickBeginOrder();
		Reporter.log("Customer information page shall be displayed wirelessTest01_04");
		Assert.assertEquals(verifyPageHeader(ci.custinfoHeader,driver),"Customer Information");
		Reporter.log("Customer Info page Validated");
		ci.selectIndividualPostPaidPlan();
		
		ci.selectTaxExemptAsNo();
	
		ci.declineScan();
		
		ci.selectReasonForByPass(key[7]);
	
		ci.setCustomerFirstName(key[8]);
	
		ci.setCustomerLastName(key[9]);
	
		ci.setCustomerDOB(key[10], key[11], key[12]);
		
		ci.setSSNNumber(key[13], key[14],key[15]);
		
		ci.confirmSSNNumber(key[16],key[17],key[18]);
	
		ci.selectLicenseState(key[19]);

		ci.setLicenseNumber(key[20]);
	
		ci.setLicenseExpDate(key[21], key[22], key[23]);
		
		ci.setHomePhoneNumber(key[24], key[25], key[26]);
	
		ci.setWorkPhoneNumber(key[27],key[28], key[29], key[30]);
	
		ci.setPrimaryEmailAddress(key[31]);
	
		ci.setEmployerName(key[32]);
	
		if(ci.streetNum.isEnabled())
		{
		ci.setStreetNumber(key[33]);
		ci.setStreetName(key[34]);
		ci.setCity(key[35]);
		ci.setState(key[36]);
		ci.setZipCode(key[37]);
		}

		ci.setAccountPasscode(key[38]);
	
		ci.setReAccountPasscode(key[39]);
	
		ci.clickNext();
		Reporter.log("Address validation pop up shall be displayed wirelessTest01_05");
		Assert.assertEquals(verifyPageHeader(ci.custinfoAddressValidHeader,driver),"Address Validation");
		Reporter.log("Customer Info Address popup Validated");
		ci.clickOnAddressValidationPopUp();
		Reporter.log("Service and device page shall be displayed wirelessTest01_06");
		Assert.assertEquals(verifyPageHeader(si.serviceDevicePageHeader,driver),"Service & Device");
		Reporter.log("Service Device page Validated");
		si.setSelectServiceLocation(key[40]);
	
		//GRANDPRARI TX  GREENVILLE TX
		si.clickBtnFindReqNum();
		Reporter.log("Available subscriber numbers shall be displayed in list wirelessTest01_07" );
		si.setSelectAvailWlsNum();
	
		si.clickBtnReserveNum();
		Reporter.log("Selected number shall be reserved wirelessTest01_08" );
		si.setTextSimNumber(key[41]);
	
		si.setTextIMEI(key[42]);

		//fullPageScreenShot("Wireless_Activation");
		si.clickBtnNext();
		//rp.clickNewGroup();
		Reporter.log("Rate plan and feature page shall be displayed wirelessTest01_09");
		Assert.assertEquals(verifyPageHeader(rp.rateplanPageHeader,driver).substring(0, 22),"Select Plan & Features");
		Reporter.log("Rate Plan page Validated");
		rp.selecPlanType(key[43]);
	
		//#Mobile Share
		rp.selectPlanInd(key[44]);
		Reporter.log("Selected plan shall be dispalyed alon with contract type and associated features wirelessTest01_10");
		rp.clickAddPlan();
	
		//fullPageScreenShot("Wireless_Activation");
	//	rp.clickServiceContractPlans();
		//rp.selectContratcLength("12 MONTHS COMMITMENT");
		rp.clickNoCommitmentPlan();
	
		rp.clickContinueBtn();
		Reporter.log("Device protection enrollment page shall be displayed  wirelessTest01_11");
		//fullPageScreenShot("Wireless_Activation");
		Assert.assertEquals(verifyPageHeader(de.declineProtectionPageHeader,driver),"Device Protection Enrollment");
		Reporter.log("Decline Page Validated");
		de.clickSkip();
		Reporter.log("Decline device protection page shall be displayed wirelessTest01_12" );
		Assert.assertEquals(verifyPageHeader(dd.declineDProtectionPageHeader,driver).substring(17),"Decline Device Protection");
		Reporter.log("Decline Device Page Validated"); //(214) 202-5954 - Decline Device Protection
		dd.clickNext();
		Reporter.log("Review and Activate page shall be displayed wirelessTest01_13");
		Assert.assertEquals(verifyPageHeader(rap.reviewAndActivatePageHeader,driver).substring(0, 19),"Review and Activate");
		Reporter.log("Review and Activate page Validated");
		rap.clickActivate();
		Reporter.log("Summary page shall be displayed wirelessTest01_14");
		Assert.assertEquals(verifyPageHeader(sp.summaryPageHeader,driver),"Summary");
		Reporter.log("Summary page Validated");
		sp.clickPaperLessNo();
		Reporter.log("CSS shall be generated in new window wirelessTest01_15" );  //need to update
		sp.clickFinished();
		Assert.assertEquals(verifyPageHeader(nspp.nextStepPageHeader,driver),"Next Steps");
		Reporter.log("next step promo page Validated");
		nspp.setRadioNo();
		nspp.clickBtnOk();
		Assert.assertEquals(verifyPageHeader(co.customersummaryPageHeader,driver).substring(0,16),"Customer Summary");
		Reporter.log("customer summary page Validated");
		co.clickonCheckOut();
		Assert.assertEquals(verifyPageHeader(co.reviewMySummaryPageHeader,driver),"Review MySummary and CSS");
		Reporter.log("view summary popup  Validated");
		co.clickonViewSummary();
		Reporter.log("Customer summary page shall be displayed wirelessTest01_16");
		Reporter.log("Tax Type and Tax Information page shall be displayed wirelessTest01_17");
		wca.setChkboxWcaAcknowledged();
		wca.clickBtnSkip();
		Reporter.log("Transaction complete popup shall be displayed wirelessTest01_18");
		//fullPageScreenShot("Wireless_Activation");
		wcap.clickBtnWcaStation();
		Reporter.log("Transaction completed page shall be displayed wirelessTest01_19" );
		String tid = tc.getTransactionId();
		String db_tid= verifyTransactions(tid, 1);
		Assert.assertEquals(tid, db_tid);
		//Verify.
		Reporter.log("Transaction shall be logged in the database wirelessTest01_20");
		Reporter.log("Test Case Passed");
	}


}
