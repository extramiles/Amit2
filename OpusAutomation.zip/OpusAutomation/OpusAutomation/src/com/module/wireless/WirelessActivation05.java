package com.module.wireless;

import java.io.IOException;

import org.testng.Reporter;
import org.testng.annotations.Test;

import com.module.SuperTestNG;

public class WirelessActivation05 extends SuperTestNG {
	@Test
	public void Wireless_Activation_IRU() throws IOException{
		String[] key =getDataFromExcel("Wireless_Activation_IRU","Sheet1");
			//System.out.println(key[0]);
		//Assert.assertEquals(sc.getStoreSelectionPageTitle(),"OPUS Login");
			Reporter.log("----------Store Select Page----------");
			sc.selectDropDownsd("D112");
			Reporter.log("select store D111 from DropDown");
			fullPageScreenShot("Wireless_Activation");
			
			sc.click();
			Reporter.log("Click ok button");
			fullPageScreenShot("Wireless_Activation");
			
			Reporter.log("----------AT&T Logon Page----------");
			lpa.enterUserName(key[1]);
			Reporter.log("Set username");
			fullPageScreenShot("Wireless_Activation");
			
			lpa.enterPassword(key[2]);
			Reporter.log("Set password");
			fullPageScreenShot("Wireless_Activation");
			
			lpa.click();
			Reporter.log("Click Login button");
			fullPageScreenShot("Wireless_Activation");
			
			Reporter.log("-----------Remind me later Page----------");
			rmlpa.click();
			Reporter.log("Click Remind me later button");
			fullPageScreenShot("Wireless_Activation");
			
			Reporter.log("-----------Home Page----------");
			hpa.switchToFrameHomePage();
			Reporter.log("Switch to Home page");
			fullPageScreenShot("Wireless_Activation");
			
			hpa.click();
			Reporter.log("Click Process later");
			fullPageScreenShot("Wireless_Activation");
			
			hpa.clickTo();
			Reporter.log("Click expand button");
			fullPageScreenShot("Wireless_Activation");
			
			hpa.enterAddressLineOne(key[3]);
			Reporter.log("Set");
			fullPageScreenShot("Wireless_Activation");
			
			hpa.setCityValue(key[4]);
			Reporter.log("Set City");
			fullPageScreenShot("Wireless_Activation");
			
			
			hpa.selectStateHomePage(key[5]);
			Reporter.log("Select State");
			fullPageScreenShot("Wireless_Activation");
			
			hpa.setZipCodeHomePage(key[6]);
			Reporter.log("Set Zip code");
			fullPageScreenShot("Wireless_Activation");
			
			hpa.clickToCheckAvailability();
			Reporter.log("Click on check availability button");
			fullPageScreenShot("Wireless_Activation");
			
			Reporter.log("-----------CPNI Page----------");
			cpni.clickTo();
			Reporter.log("Click on Yes");
			fullPageScreenShot("Wireless_Activation");
			
			cpni.clickNextButton();
			Reporter.log("Click on Next button");
			fullPageScreenShot("Wireless_Activation");
			
			Reporter.log("-----------PCA Page----------");
			pca.SelectWireless();
			Reporter.log("Click on wireless checkbox");
			fullPageScreenShot("Wireless_Activation");
			
			pca.SetPortNumberNo();
			Reporter.log("Click Port No");
			fullPageScreenShot("Wireless_Activation");

			
			pca.ClickBeginOrder();
			Reporter.log("Click Begin order");
			fullPageScreenShot("Wireless_Activation");
			

			Reporter.log("-----------Customer Information Page----------");
			ci.selectIndividualPostPaidPlan();
			Reporter.log("Select Individual PostPaid Plan");
			fullPageScreenShot("Wireless_Activation");
			
			ci.selectTaxExemptAsNo();
			Reporter.log("Select Tax exempt");
			fullPageScreenShot("Wireless_Activation");
			
			ci.clickOnFANCheckBox();
			Reporter.log("Click on FAN checkBox");
			//fullPageScreenShot("Wireless_Activation");
			
			ci.setFANNumber(key[45]);
			Reporter.log("Set FAN number");
			fullPageScreenShot("Wireless_Activation");
			
			//For D111 store only
			/*ci.selectEligibilityProof("Manager Exception Override");
			ci.clickOnIruConfirmCheckBox();
			ci.declineScan();*/
			
			ci.clickRadioBypass();
			Reporter.log("Click on FAN checkBox");
			fullPageScreenShot("Wireless_Activation");
			
			ci.selectReasonForByPass(key[7]);
			Reporter.log("Click on FAN checkBox");
			fullPageScreenShot("Wireless_Activation");
			
			ci.setCustomerFirstName(key[8]);
			Reporter.log("Set Customer First Name");
			fullPageScreenShot("Wireless_Activation");
			ci.setCustomerLastName(key[9]);
			Reporter.log("Set Customer Last Name");
			fullPageScreenShot("Wireless_Activation");
			ci.setCustomerDOB(key[10], key[11], key[12]);
			Reporter.log("Set Customer DOB");
			fullPageScreenShot("Wireless_Activation");
			ci.setSSNNumber(key[13], key[14],key[15]);
			Reporter.log("Set SSN Number");
			fullPageScreenShot("Wireless_Activation");
			ci.confirmSSNNumber(key[16],key[17],key[18]);
			Reporter.log("Confirm SSN Number");
			fullPageScreenShot("Wireless_Activation");
			ci.selectLicenseState(key[19]);
			Reporter.log("select License State");
			fullPageScreenShot("Wireless_Activation");
			ci.setLicenseNumber(key[20]);
			Reporter.log("set License Number");
			fullPageScreenShot("Wireless_Activation");
			ci.setLicenseExpDate(key[21], key[22], key[23]);
			Reporter.log("set License ExpDate");
			fullPageScreenShot("Wireless_Activation");
			ci.setHomePhoneNumber(key[24], key[25], key[26]);
			Reporter.log("set Home Phone Number");
			fullPageScreenShot("Wireless_Activation");
//			ci.selectHomeContactPreference("No");
			ci.setWorkPhoneNumber(key[27],key[28], key[29], key[30]);
			Reporter.log("set Work Phone Number");
			fullPageScreenShot("Wireless_Activation");
//			ci.selectWorkContactPreference("No");
			ci.setPrimaryEmailAddress(key[31]);
			Reporter.log("set Primary Email Address");
			fullPageScreenShot("Wireless_Activation");
			ci.setEmployerName(key[32]);
			Reporter.log("set Employer Name");
			fullPageScreenShot("Wireless_Activation");

//			if(ci.streetNum.isEnabled())
//			{
//			ci.setStreetNumber(key[33]);
//			ci.setStreetName(key[34]);
//			ci.setCity(key[35]);
//			ci.setState(key[36]);
//			ci.setZipCode(key[37]);
//			}
			
			ci.setAccountPasscode(key[38]);
			Reporter.log("set Account Passcode");
			fullPageScreenShot("Wireless_Activation");
			ci.setReAccountPasscode(key[39]);
			Reporter.log("set agin Account Passcode");
			fullPageScreenShot("Wireless_Activation");

			ci.clickNext();
			Reporter.log("click Next");
			fullPageScreenShot("Wireless_Activation");
			
			ci.clickOnAddressValidationPopUp();
			Reporter.log("click on Address Validation PopUp");
			fullPageScreenShot("Wireless_Activation");
			
			
			Reporter.log("-----------Service and Device Page----------");
			si.setSelectServiceLocation(key[40]);
			Reporter.log("Select Service Location");
			fullPageScreenShot("Wireless_Activation");
			//GRANDPRARI TX  GREENVILLE TX
			si.clickBtnFindReqNum();
			Reporter.log("click Button Find Requested Number");
			fullPageScreenShot("Wireless_Activation");
			si.setSelectAvailWlsNum();
			Reporter.log("Select Available Wireless Number");
			fullPageScreenShot("Wireless_Activation");
			si.clickBtnReserveNum();
			Reporter.log("click Btn Reserve Num");
			fullPageScreenShot("Wireless_Activation");
			si.setTextSimNumber(key[41]);
			Reporter.log("set Text Sim Number");
			fullPageScreenShot("Wireless_Activation");
			si.setTextIMEI(key[42]);
			Reporter.log("set Text IMEI");
			fullPageScreenShot("Wireless_Activation");
			si.clickBtnNext();
			Reporter.log("click Button Next");
			fullPageScreenShot("Wireless_Activation");

			Reporter.log("-----------Rate Plan and Features Page----------");
			//rp.clickNewGroup();
			rp.selecPlanType(key[43]);
			Reporter.log("select Plan Type");
			fullPageScreenShot("Wireless_Activation");
			//#Mobile Share
			rp.selectPlanInd(key[44]);
			Reporter.log("select Plan");
			fullPageScreenShot("Wireless_Activation");
			rp.clickAddPlan();
			Reporter.log("click Add Plan");
			fullPageScreenShot("Wireless_Activation");
			rp.clickServiceContractPlans();
			Reporter.log("click Service Contract Plans");
			fullPageScreenShot("Wireless_Activation");
			//rp.selectContratcLength("12 MONTHS COMMITMENT");
			rp.clickNoCommitmentPlan();
			Reporter.log("click No Commitment Plan");
			fullPageScreenShot("Wireless_Activation");
			rp.clickContinueBtn();
			Reporter.log("click Continue Btn");
			fullPageScreenShot("Wireless_Activation");
			
			Reporter.log("-----------Device Protection Page----------");
			de.clickSkip();
			Reporter.log("click Skip");
			fullPageScreenShot("Wireless_Activation");
			
			Reporter.log("-----------Decline Device Protection Page----------");
			dd.clickNext();
			Reporter.log("click Next");
			fullPageScreenShot("Wireless_Activation");
			
			Reporter.log("-----------Review and Activate Page----------");
			rap.clickActivate();
			Reporter.log("click Activate ");
			fullPageScreenShot("Wireless_Activation");
			
			Reporter.log("-----------Summary Page----------");
			sp.clickPaperLessNo();
			Reporter.log("click Paper Less No");
			fullPageScreenShot("Wireless_Activation");
			sp.clickFinished();
			Reporter.log("click Finished");
			fullPageScreenShot("Wireless_Activation");
			
			Reporter.log("-----------Next Step Promo Page----------");
			nspp.setRadioNo();
			Reporter.log("set Radio No");
			fullPageScreenShot("Wireless_Activation");
			nspp.clickBtnOk();
			Reporter.log("click Btn Ok");
			fullPageScreenShot("Wireless_Activation");
			
			Reporter.log("-----------Customer Summary Page----------");
			co.clickonCheckOut();
			Reporter.log("click on CheckOut");
			fullPageScreenShot("Wireless_Activation");
			co.clickonViewSummary();
			Reporter.log("click on View Summary");
			fullPageScreenShot("Wireless_Activation");
			
//			Reporter.log("-----------WCA Page----------");
//			wca.setChkboxWcaAcknowledged();
//			wca.clickBtnSkip();
//			wcap.clickBtnWcaStation();
			
			Reporter.log("-----------Customer Summary Page----------");
			co.clickonCheckOutIRU();
			Reporter.log("click on CheckOut IRU");
			fullPageScreenShot("Wireless_Activation");
			
			Reporter.log("-----------Tax type Info Page----------");
			tp.setSelectApprover(key[46]);
			Reporter.log("set Select Approver");
			fullPageScreenShot("Wireless_Activation");
			tp.setTextPassword(key[47]);
			Reporter.log("set Text Password");
			fullPageScreenShot("Wireless_Activation");
			tp.clickSubmitButton();
			Reporter.log("click Submit Button");
			fullPageScreenShot("Wireless_Activation");
			
			Reporter.log("-----------Transaction complete Page----------");
			tc.clickOnEmailCheck();
			Reporter.log("click on Email Checkbox");
			fullPageScreenShot("Wireless_Activation");
			tc.clickOnPrintCheck();
			Reporter.log("click on Print Checkbox");
			fullPageScreenShot("Wireless_Activation");
			tc.clickOnDoneButton();
			Reporter.log("click On Done Button");
			fullPageScreenShot("Wireless_Activation");
			Reporter.log("Test Case Passed");
			/*try{
				//assertEquals(true, false);
				testresultdata.put("2",new Object[] {1ld, "Navigate_to_home_page", "page opens and login success","Pass"});
				
			}catch(Exception e){
				testresultdata.put("2
				",new Object[] {1d, "Navigate_to_home_page", "page opens and login success","Fail"});
			}*/
}
}
			