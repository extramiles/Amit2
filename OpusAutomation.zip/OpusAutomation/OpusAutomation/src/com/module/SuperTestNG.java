package com.module;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.testng.ITestContext;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;

import com.opusbase.TestBase;
import com.pageobject.ConfirmOrderPage;
import com.pageobject.CpniPage;
import com.pageobject.CssPage;
import com.pageobject.CustomerCheckoutGoPhPage;
import com.pageobject.CustomerCheckoutPage;
import com.pageobject.CustomerInfoPage;
import com.pageobject.CustomerSignPage;
import com.pageobject.DeclineDeviceProEnrollPage;
import com.pageobject.DeviceProEnrollPage;
import com.pageobject.HomePage;
import com.pageobject.LoginPageObject;
import com.pageobject.NextStepPromoPage;
import com.pageobject.PcaPage;
import com.pageobject.RatePlanPage;
import com.pageobject.RemainedMeLaterPageObject;
import com.pageobject.ReviewActivatePage;
import com.pageobject.SellPinPage;
import com.pageobject.ServiceDevicePage;
import com.pageobject.ShipmentInfoPage;
import com.pageobject.StoreSelectPage;
import com.pageobject.SummaryPage;
import com.pageobject.TaxTypeInfoPage;
import com.pageobject.TransactionCmplPage;
import com.pageobject.WcaNewActPage;
import com.pageobject.WcaPage;



public class SuperTestNG extends TestBase {
	protected StoreSelectPage sc;
	protected LoginPageObject lpa;
	protected RemainedMeLaterPageObject rmlpa;
	protected HomePage hpa;
	protected CpniPage cpni;
	protected PcaPage pca;
	protected CustomerInfoPage ci;
	protected ServiceDevicePage si;
	protected RatePlanPage rp;
	protected DeviceProEnrollPage de;
	protected DeclineDeviceProEnrollPage dd;
	protected ReviewActivatePage rap;
	protected SummaryPage sp;
	protected NextStepPromoPage nspp;
	protected CssPage co;
	protected WcaPage wca;
	protected WcaNewActPage wcap;
	protected SellPinPage spp;
	protected TaxTypeInfoPage tp;
	protected CustomerCheckoutGoPhPage cgp;
	protected TransactionCmplPage tc;
	protected ConfirmOrderPage cop;
	protected CustomerCheckoutPage cgps;
	protected CustomerSignPage csinp;
	protected ShipmentInfoPage shp;
	
	public static FileInputStream fis=null;
	public static File f = null;
	public static XSSFWorkbook wb = null;
	public static XSSFSheet sheet = null;
	public static XSSFRow row=null;
	public static XSSFCell cell=null;
	public static Object[][]  ob=null;
	public static Map<String, Object[]> testresultdata;

	//PageActionFlow ts;
	
	@BeforeMethod(alwaysRun=true)
	public void setup() throws InterruptedException
	{
		setUp();
		//ts = new PageActionFlow(driver);
		 sc = new StoreSelectPage(driver);
		 lpa = new LoginPageObject(driver);
		 rmlpa = new RemainedMeLaterPageObject(driver);
		 hpa=new HomePage(driver);
		 cpni=new CpniPage(driver);
		 pca = new PcaPage(driver);
		 ci= new CustomerInfoPage(driver);
		 si=new ServiceDevicePage(driver);
		 rp=new RatePlanPage(driver);
		 de=new DeviceProEnrollPage(driver);
		 dd=new DeclineDeviceProEnrollPage(driver);
		 rap= new ReviewActivatePage(driver);
		 sp=new SummaryPage(driver);
		 nspp= new NextStepPromoPage(driver);
		 co= new CssPage(driver);
		 wca= new WcaPage(driver);
		 wcap = new WcaNewActPage(driver);
		 spp=new SellPinPage(driver);
		 tp=new TaxTypeInfoPage(driver);
		 cgp=new CustomerCheckoutGoPhPage(driver);
		 tc = new TransactionCmplPage(driver);
		 cop= new ConfirmOrderPage(driver);
		 cgps=new CustomerCheckoutPage(driver);
		 csinp = new CustomerSignPage(driver);
		 shp = new ShipmentInfoPage(driver);
	}

	@AfterMethod(alwaysRun=true)
	public void tear(){
		tearDown();
	}
		
}
