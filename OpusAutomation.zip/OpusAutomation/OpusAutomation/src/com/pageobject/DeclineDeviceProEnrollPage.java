/* * ClassName : DeclineDeviceProEnrollPage
Description : This class identifies and implements all the web
elements and their corresponding actions of Decline Device Enrollment page.
Version info : V_0.1
Date : 02/06/2017
Author : Tech Mahindra
Copyright notice : Tech Mahindra Ltd 
 */

package com.pageobject;

import org.apache.log4j.Logger;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;


import com.utility.Logg;
import com.utility.Util;

public class DeclineDeviceProEnrollPage {
	Util u = new Util();
	WebDriver driver = u.getDriver();
	Logger Log = Logg.createLogger();
	//WebDriver driver;
	String webElementName;
	Select selectD;

	public DeclineDeviceProEnrollPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(new AjaxElementLocatorFactory(driver, 20),
				this);
	}

	@FindBy(how = How.ID, using = "salesrep")
	private WebElement selectApproverId;

	@FindBy(how = How.ID, using = "password")
	private WebElement textPassword;

	@FindBy(how = How.CLASS_NAME, using = "leftArrow")
	private WebElement btnBack;

	@FindBy(how = How.XPATH, using = "//button[@id='btnNext']/b/em/u[text()='Next']")
	private WebElement btnNext;


	@FindBy(how = How.XPATH, using = "//div[@id='column1of1']/h2/b/em[contains(text(),'Decline Device Protection')]")
	public WebElement declineDProtectionPageHeader;
	/*
	 * Method: selectApproverFor Description : To Select eligible manager id to
	 * from drop down. Parameter :
	 * 
	 * @setManagerId : Parameter to hold input value of sales manager id Return
	 * type : Void
	 */
	public void selectApproverFor(String setManagerId) {
		webElementName = "selectApproverId";
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(selectApproverId));
		if (setManagerId != null) {
			try {
				selectD = new Select(selectApproverId);
				selectD.selectByValue(setManagerId);
				Log.info("Passed" + DeclineDeviceProEnrollPage.class.getName()
						+ "," + setManagerId + " selected ");
			} catch (NoSuchElementException e) {
				e.printStackTrace();
				Log.info("Failed" + DeclineDeviceProEnrollPage.class.getName()
						+ webElementName + " not found ");
			}
		}
	}

	/*
	 * Method: enterPassword Description : To enter password corresponding to
	 * manager id selected. Parameter :
	 * 
	 * @setPassword : Parameter to hold input value of password. Return type :
	 * Void
	 */

	public void enterPassword(String setPassword) {
		webElementName = "textPassword";
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(textPassword));
		if (setPassword != null) {
			try {
				textPassword.clear();
				Log.info("Passed" + DeclineDeviceProEnrollPage.class.getName()
						+ "," + webElementName + " cleared ");
				textPassword.sendKeys(setPassword);
				Log.info("Passed" + DeclineDeviceProEnrollPage.class.getName()
						+ "," + setPassword + " entered ");
			} catch (NoSuchElementException e) {
				e.printStackTrace();
				Log.info("Failed" + DeclineDeviceProEnrollPage.class.getName()
						+ webElementName + " not found ");
			}
		}
	}

	/*
	 * Method: clickBack Description : To click on Back button to go back to
	 * Plan and Features page. Parameter : None Return type : Void
	 */
	public void clickBack() {
		webElementName = "btnBack";
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(btnBack));
		try {
			btnBack.click();
			Log.info("Passed" + DeclineDeviceProEnrollPage.class.getName()
					+ "," + "Back button clicked");
		} catch (NoSuchElementException e) {
			e.printStackTrace();
			Log.info("Failed" + DeclineDeviceProEnrollPage.class.getName()
					+ webElementName + " not found ");
		}
	}

	/*
	 * Method: clickNext Description : To click on Next button to proceed.
	 * Parameter : None Return type : Void
	 */
	public ReviewActivatePage clickNext() {
		webElementName = "btnNext";
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(btnNext));
		try {
			btnNext.click();
			Log.info("Passed" + DeclineDeviceProEnrollPage.class.getName()
					+ "," + "Next button clicked");
		} catch (NoSuchElementException e) {
			e.printStackTrace();
			Log.info("Failed" + DeclineDeviceProEnrollPage.class.getName()
					+ webElementName + " not found ");
		}
		return new ReviewActivatePage(driver);
	}

}
