/*
Description : This class identify and implement all the web
element and its corresponding action of Service and device page
Consent page.
Version info : V_0.1
Date : 02/06/2017
Author : Devendra Bhavsar
Copyright notice : Tech Mahindra Ltd
 */

package com.pageobject;

import java.util.List;
import java.util.NoSuchElementException;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;

import com.utility.Logg;
import com.utility.Util;

public class ServiceDevicePage {
	//WebDriver driver;
	Util u = new Util();
	WebDriver driver = u.getDriver();
	Logger Log = Logg.createLogger();
	String webElementName;
	Select selectD;

	public ServiceDevicePage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(new AjaxElementLocatorFactory(driver, 20),this );
	}

	

	/*-------------------------------------------------------- Page objects ---------------------------------------------------- */
	/* page header */
	
	@FindBy(how = How.ID, using = "deviceSource_2") // Scan or type device information
	private WebElement radioDFDeviceOptions;
	
	@FindBy(how = How.NAME, using = "salesRep")
	private WebElement selectSalesRep;
	@FindBy(how = How.XPATH, using = "//div[@id='column1of1']/h2/b/em[text()='Service & Device']")
	public WebElement serviceDevicePageHeader;
	/* Line */
	@FindBy(how = How.NAME, using = "sameAsBillAddr")
	private WebElement chkboxPrimaryAddress;

	/* Select wireless number */
	//@FindBy(how = How.NAME, using = "wirelessOption")
	//private WebElement radioWirelessOption;

	@FindBy(how = How.XPATH, using = "//input[@name = 'wirelessOption' and @value = 'Regular']") //Display Available Wireless Numbers
	private WebElement radioWirelessOption;
	
	//@FindBy(how = How.NAME, using = "serviceCityOption")
	//private WebElement radioServiceLocation;
	@FindBy(how = How.ID, using = "serviceCityOptionDispay1") // Retrieve Service Cities by Market
	private WebElement radioServiceLocation;
	
	
	@FindBy(how = How.NAME, using = "selectedNewMarket")
	private WebElement selectNewMarket;

	@FindBy(how = How.NAME, using = "npaNxx.npa")
	private WebElement textAreaCode;

	@FindBy(how = How.NAME, using = "npaNxx.nxx")
	private WebElement textExchange;

	@FindBy(how = How.ID, using = "getServiceLocations")
	private WebElement btnGetServiceLocations;

	@FindBy(how = How.XPATH, using = "//div/select[@name='selectedServiceCity']")
	private WebElement selectServiceLocation;

	@FindBy(how = How.NAME, using = "selectedNpaNxx")
	private WebElement selectSpecialNumberReq;

	@FindBy(how = How.NAME, using = "selectedXxxx")
	private WebElement textSpecialNumberReq;

	@FindBy(how = How.XPATH, using = "//div[@id='specialnumbers']/button/b/em/u[text()='Find Requested Numbers']")
	private WebElement btnFindReqNum;

	@FindBy(how = How.XPATH, using = "//div[@id='tlgwirelessnumbers']/label[text()='3. Choose Available Wireless Number']/following-sibling::select[@name='subscriber']")
	private WebElement selectAvailWlsNum;
	///child::option(starts-with(text(),'('))
	@FindBy(how = How.XPATH, using = "//button[@id='reserveNumberBtnId']/b/em/u[text()='Reserve Number']")
	private WebElement btnReserveNum;

	
	@FindBy(how = How.ID, using = "sendSubscribersToSigcapId")
	private WebElement btnUseStation;

	@FindBy(how = How.NAME, using = "selectedActivationDate")
	private WebElement selectActivationDate;

	@FindBy(how = How.ID, using = "deviceSource_1") // Scan or type device information
	private WebElement radioDeviceOptions;

	@FindBy(how = How.NAME, using = "sim")
	private WebElement textSimNumber;

	@FindBy(how = How.NAME, using = "imei")
	private WebElement textIMEI;

	@FindBy(how = How.NAME, using = "selectedLineType")
	private WebElement selectLineSource;

	@FindBy(how = How.NAME, using = "itemID")
	private WebElement textItemID;

	@FindBy(how = How.ID, using = "searchBtn")
	private WebElement btnSearchItem;

	@FindBy(how = How.XPATH, using = "//div[@id='newResultsDiv']/table[1]/tbody/tr/td/input[@name = 'selectedItem' and @type = 'radio']")
	private WebElement radioFirstItem;

	/* Billing Options */
	@FindBy(how = How.NAME, using = "selectedLanguage")
	private WebElement selectBillingLanguage;

	@FindBy(how = How.NAME, using = "selectedBillCycle")
	private WebElement selectBillingCycleDate;

	/* User Information */

	@FindBy(how = How.NAME, using = "ppuCustomerNameFirst")
	private WebElement textFirstName;

	@FindBy(how = How.NAME, using = "ppuCustomerNameLast")
	private WebElement textLastName;

	/* Additional Information */

	@FindBy(how = How.NAME, using = "selectAuthorizedUser")
	private WebElement chkboxAddAuthUser;

	@FindBy(how = How.NAME, using = "authorizedUserNameTitle")
	private WebElement selectAuthTitle;

	@FindBy(how = How.NAME, using = "authorizedUserFirstName")
	private WebElement textAuthUserFname;

	@FindBy(how = How.NAME, using = "authorizedUserMidName")
	private WebElement textAuthUserMname;

	@FindBy(how = How.NAME, using = "authorizedUserLastName")
	private WebElement textAuthUserLname;

	@FindBy(how = How.NAME, using = "authorizedUserSuffixName")
	private WebElement selectAuthSuffix;

	@FindBy(how = How.NAME, using = "authUserComments")
	private WebElement textAuthComments;

	@FindBy(how = How.XPATH, using = "//div[@id='authorizedUserInfoDiv']/button[text()='Add Authorized User']")
	private WebElement btnAddAuthUser;

	/* Bottom Button Area */
	@FindBy(how = How.XPATH, using = "//div[@id='buttonBlock' and @class='buttonArea']/button[text()='Cancel']")
	private WebElement btnCancel;

	@FindBy(how = How.XPATH, using = "//div[@id='buttonBlock' and @class='buttonArea']/button[text()='Previous']")
	private WebElement btnPrevious;

	@FindBy(how = How.XPATH, using = "//div/div[1]/div[@id='showNextButtonDiv']/button[@id='nextButton']/b/em/u[text()='Next']")
	private WebElement btnNext;

	
	
	/*-------------------------------------------------------- Page actions ---------------------------------------------------- */
	/*Method: setSelectSalesRep
	Description : To select the value of Select .
	Parameter : @value -  : sales rep's ATT UID (username value from config)
	Return type : WebElement */
	public WebElement setSelectSalesRep(String value)
	{ 
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(selectSalesRep));
		WebElement wePh = selectSalesRep; // WebElement object
		String webElementName = "selectSalesRep"; // WebElement object name string
		if (value!=null) {
			try {
				 Select selectWE = new Select(wePh);
				 selectWE.selectByValue(value);
				 Log.info("Passed : "+ ServiceDevicePage.class.getName() + "- Select : " + webElementName + " is set to " + value + ".");
			} catch(NoSuchElementException e) {
				e.printStackTrace();
				Log.info("Failed :" + ServiceDevicePage.class.getName() + "- Select : " + webElementName + " not found.");
			}
		}
		return wePh;
	}

	/*Method: setChkboxPrimaryAddress
	Parameter : None
	Return type : WebElement */
	public WebElement setChkboxPrimaryAddress(){
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(chkboxPrimaryAddress));
		WebElement wePh = chkboxPrimaryAddress; // WebElement object
		String webElementName = "chkboxPrimaryAddress"; // WebElement object name string
		if(wePh.isEnabled()){
			try {
				 wePh.click();
				 Log.info("Passed : "+ ServiceDevicePage.class.getName() + "- CheckBox : " + webElementName + " is checked.");
			} catch(NoSuchElementException e) {
				e.printStackTrace();
				Log.info("Failed :" + ServiceDevicePage.class.getName() + "- CheckBox : " + webElementName + " not found.");
			}
		}
		else{
			Log.info("Failed :" + ServiceDevicePage.class.getName() + "- CheckBox : " + webElementName + " is disabled.");
		}
		return wePh;
	}
	
	/*Method: setRadioWirelessOption
	Description : To set the value of input(radio) .
	Parameter : None
	Return type : WebElement */
	public WebElement setRadioWirelessOption(){
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(radioWirelessOption));
		WebElement wePh = radioWirelessOption; // WebElement object
		String webElementName = " radioWirelessOption"; // WebElement object name string
		if(wePh.isEnabled()){	
		try {
				 wePh.click();
				 Log.info("Passed : "+ ServiceDevicePage.class.getName() + "- Radio button : " + webElementName + " is set.");
			} catch(NoSuchElementException e) {
				e.printStackTrace();
				Log.info("Failed :" + ServiceDevicePage.class.getName() + "- Radio button : " + webElementName + " not found.");
			}
		}
		else{
			Log.info("Failed :" + ServiceDevicePage.class.getName() + "- Radio button : " + webElementName + " is disabled.");
		}
		return wePh;
	}
	
	/*Method: setRadioServiceLocation
	 Description : To set the value of input(radio) radioServiceLocation.
	 Parameter : None
	 Return type : WebElement */
	public WebElement setRadioServiceLocation(){
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(radioServiceLocation));
		WebElement wePh = radioServiceLocation; // WebElement object
		String webElementName = "radioServiceLocation"; // WebElement object name string
		if(wePh.isEnabled()){ 
			try {
				wePh.click();
				Log.info("Passed : "+ ServiceDevicePage.class.getName() + "- Radio button : " + webElementName + " is set.");
			} catch(NoSuchElementException e) {
				e.printStackTrace();
				Log.info("Failed :" + ServiceDevicePage.class.getName() + "- Radio button : " + webElementName + " not found.");
			}
		}
		else{
			Log.info("Failed :" + ServiceDevicePage.class.getName() + "- Radio button : " + webElementName + " is disabled.");
		}
		return wePh;
	}

	/*Method: setSelectNewMarket
	 Description : To set the value of input(check box) selectNewMarket.
	 Parameter : @
	 Return type : WebElement */
	public WebElement setSelectNewMarket(){
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(selectNewMarket));
		WebElement wePh = selectNewMarket; // WebElement object
				String webElementName = "selectNewMarket"; // WebElement object name string
		if(wePh.isEnabled()){
			try {
				wePh.click();
				Log.info("Passed : "+ ServiceDevicePage.class.getName() + "- CheckBox : " + webElementName + " is checked.");
			} catch(NoSuchElementException e) {
				e.printStackTrace();
				Log.info("Failed :" + ServiceDevicePage.class.getName() + "- CheckBox : " + webElementName + " not found.");
			}
		}
		else{
			Log.info("Failed :" + ServiceDevicePage.class.getName() + "- CheckBox : " + webElementName + " is disabled.");
		}
		return wePh;
	}
	
	
	 
	
	
	 /*Method: setTextAreaCode
	 Description : To set the value of input(text) SetTextAreaCode.
	 Parameter : @value - area code
	 Return type : WebElement */
	
	public WebElement setTextAreaCode(String value)
	{
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(textAreaCode));
		WebElement wePh = textAreaCode; // WebElement object 
		String webElementName = "textAreaCode"; // WebElement object name string
		if(value!=null){
			try
			{
				wePh.clear();
				Log.info("Passed : "+ ServiceDevicePage.class.getName() + "- Textbox : " + webElementName + " is cleared.");
				wePh.sendKeys(value);
				Log.info("Passed : "+ ServiceDevicePage.class.getName() + "- Textbox : " + webElementName + " is set to " + value + ".");
			}
			catch(NoSuchElementException e)
			{
				e.printStackTrace();
				Log.info("Failed :" + ServiceDevicePage.class.getName() + "- Textbox : " + webElementName + " not found.");
			}
		}
		return wePh;
	}
	
	/*Method: setTextExchange
	 Description : To set the value of input(text) textExchange.
	 Parameter : @value - area exchange code
	 Return type : WebElement */
	
	public WebElement setTextExchange(String value)
	{
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(textExchange));
		WebElement wePh = textExchange; // WebElement object 
		String webElementName = "textExchange"; // WebElement object name string
		if(value!=null){
			try
			{
				wePh.clear();
				Log.info("Passed : "+ ServiceDevicePage.class.getName() + "- Textbox : " + webElementName + " is cleared.");
				wePh.sendKeys(value);
				Log.info("Passed : "+ ServiceDevicePage.class.getName() + "- Textbox : " + webElementName + " is set to " + value + ".");
			}
			catch(NoSuchElementException e)
			{
				e.printStackTrace();
				Log.info("Failed :" + ServiceDevicePage.class.getName() + "- Textbox : " + webElementName + " not found.");
			}
		}
		return wePh;
	}
	
	/*Method: clickBtnGetServiceLocations
	Description : To click on  button.
	Parameter : None
	Return type : void */
	public void clickBtnGetServiceLocations()
	{
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(btnGetServiceLocations));
		WebElement wePh = btnGetServiceLocations; // WebElement object 
		String webElementName = "btnGetServiceLocations"; // WebElement object name string
		try {
			wePh.click();
			Log.info("Passed : "+ ServiceDevicePage.class.getName() + "- Button : " + webElementName + " is clicked.");
			} catch(NoSuchElementException e) {
			e.printStackTrace();
			Log.info("Failed :" + ServiceDevicePage.class.getName() + "- Button : " + webElementName + " not found.");
			}
	}
	
	/*Method: sesetSelectServiceLocationt
	Description : To select the value of Select .
	Parameter : @value -  Dallas (default)
	Return type : WebElement */
	public WebElement setSelectServiceLocation(String value)
	{ 
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(selectServiceLocation));
		WebElement wePh = selectServiceLocation; // WebElement object
		String webElementName = "selectServiceLocation"; // WebElement object name string
		if (value!=null) {
			try {
				/* Select selectWE = new Select(wePh);
				 selectWE.selectByValue(value);*/
				wePh.click();
				wePh.sendKeys(value);
				wePh.click();
				 Log.info("Passed : "+ ServiceDevicePage.class.getName() + "- Select : " + webElementName + " is set to " + value + ".");
			} catch(NoSuchElementException e) {
				e.printStackTrace();
				Log.info("Failed :" + ServiceDevicePage.class.getName() + "- Select : " + webElementName + " not found.");
			}
		}
		return wePh;
	}
	
	/*Method: setSelectSpecialNumberReq
	Description : To select the value of Select selectSpecialNumberReq.
	Parameter : @value -  
	Return type : WebElement */
	public WebElement setSelectSpecialNumberReq(String value)
	{ 
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(selectSpecialNumberReq));
		WebElement wePh = selectSpecialNumberReq; // WebElement object
		String webElementName = "selectSpecialNumberReq"; // WebElement object name string
		if (value!=null) {
			try {
				 Select selectWE = new Select(wePh);
				 selectWE.selectByValue(value);
				 Log.info("Passed : "+ ServiceDevicePage.class.getName() + "- Select : " + webElementName + " is set to " + value + ".");
			} catch(NoSuchElementException e) {
				e.printStackTrace();
				Log.info("Failed :" + ServiceDevicePage.class.getName() + "- Select : " + webElementName + " not found.");
			}
		}
		return wePh;
	}
	
	/*Method: setTextSpecialNumberReq
	 Description : To set the value of input(text) textSpecialNumberReq.
	 Parameter : @value - Special Number
	 Return type : WebElement */
	
	public WebElement setTextSpecialNumberReq(String value)
	{
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(textSpecialNumberReq));
		WebElement wePh = textSpecialNumberReq; // WebElement object 
		String webElementName = "textSpecialNumberReq"; // WebElement object name string
		if(value!=null){
			try
			{
				wePh.clear();
				Log.info("Passed : "+ ServiceDevicePage.class.getName() + "- Textbox : " + webElementName + " is cleared.");
				wePh.sendKeys(value);
				Log.info("Passed : "+ ServiceDevicePage.class.getName() + "- Textbox : " + webElementName + " is set to " + value + ".");
			}
			catch(NoSuchElementException e)
			{
				e.printStackTrace();
				Log.info("Failed :" + ServiceDevicePage.class.getName() + "- Textbox : " + webElementName + " not found.");
			}
		}
		return wePh;
	}
	
	/*Method: clickBtnFindReqNum
	Description : To click on  button btnFindReqNum.
	Parameter : None
	Return type : void */
	public ServiceDevicePage clickBtnFindReqNum()
	{
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(btnFindReqNum));
		WebElement wePh = btnFindReqNum; // WebElement object 
		String webElementName = "btnFindReqNum"; // WebElement object name string
		try {
			wePh.click();
			Log.info("Passed : "+ ServiceDevicePage.class.getName() + "- Button : " + webElementName + " is clicked.");
			} catch(NoSuchElementException e) {
			e.printStackTrace();
			Log.info("Failed :" + ServiceDevicePage.class.getName() + "- Button : " + webElementName + " not found.");
			}
		return PageFactory.initElements(driver, ServiceDevicePage.class);
	}
	
	/*Method: setSelectAvailWlsNum
	Description : To select the value of Select selectAvailWlsNum.
	Parameter : @value -  Index 
	Return type : WebElement (Verify the value of selected item by length of CTN i.e 10.)*/
	public void setSelectAvailWlsNum()
	{ 
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(selectAvailWlsNum));
			try {
				
				selectAvailWlsNum.click();
				
				 Log.info("Passed : "+ ServiceDevicePage.class.getName() + "- Select : " + webElementName + " is set to " + "" + ".");
			} catch(NoSuchElementException e) {
				e.printStackTrace();
				Log.info("Failed :" + ServiceDevicePage.class.getName() + "- Select : " + webElementName + " not found.");
			}
		//return ls;
	}
	
	/*Method: clickBtnReserveNum
	Description : To click on  button btnReserveNum.
	Parameter : None
	Return type : Void */
	public ServiceDevicePage clickBtnReserveNum()
	{
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(btnReserveNum));
		WebElement wePh = btnReserveNum; // WebElement object 
		String webElementName = "btnReserveNum"; // WebElement object name string
		if(wePh.isEnabled()){
		try {
			wePh.click();
			Log.info("Passed : "+ ServiceDevicePage.class.getName() + "- Button : " + webElementName + " is clicked.");
			} catch(NoSuchElementException e) {
			e.printStackTrace();
			Log.info("Failed :" + ServiceDevicePage.class.getName() + "- Button : " + webElementName + " not found.");
			}
		}
		else
		{
			Log.info("Failed :" + ServiceDevicePage.class.getName() + "- Button : " + webElementName + " is disabled.");
		}
		return PageFactory.initElements(driver, ServiceDevicePage.class);
	}
	/*Method: clickBtnUseStation
	Description : To click on  button btnUseStation.
	Parameter : None
	Return type : void */
	public void clickBtnUseStation()
	{
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(btnUseStation));
		WebElement wePh = btnUseStation; // WebElement object 
		String webElementName = "btnUseStation"; // WebElement object name string
		try {
			wePh.click();
			Log.info("Passed : "+ ServiceDevicePage.class.getName() + "- Button : " + webElementName + " is clicked.");
			} catch(NoSuchElementException e) {
			e.printStackTrace();
			Log.info("Failed :" + ServiceDevicePage.class.getName() + "- Button : " + webElementName + " not found.");
			}
	}
	
	/*Method: setSelectActivationDate
	Description : To select the value of Select selectActivationDate.
	Parameter : @value -  
	Return type : WebElement */
	public WebElement setSelectActivationDate(String value)
	{ 
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(selectActivationDate));
		WebElement wePh = selectActivationDate; // WebElement object
		String webElementName = "selectActivationDate"; // WebElement object name string
		if (value!=null) {
			try {
				 Select selectWE = new Select(wePh);
				 selectWE.selectByValue(value);
				 Log.info("Passed : "+ ServiceDevicePage.class.getName() + "- Select : " + webElementName + " is set to " + value + ".");
			} catch(NoSuchElementException e) {
				e.printStackTrace();
				Log.info("Failed :" + ServiceDevicePage.class.getName() + "- Select : " + webElementName + " not found.");
			}
		}
		return wePh;
	}
	
	/*Method: setRadioDeviceOptions
	 Description : To set the value of input(radio) radioDeviceOptions.
	 Parameter : None
	 Return type : WebElement */
	public WebElement setRadioDeviceOptions(){
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(radioDeviceOptions));
		WebElement wePh = radioDeviceOptions; // WebElement object
		String webElementName = "radioDeviceOptions"; // WebElement object name string
		if(wePh.isEnabled()){ 
			try {
				wePh.click();
				Log.info("Passed : "+ ServiceDevicePage.class.getName() + "- Radio button : " + webElementName + " is set.");
			} catch(NoSuchElementException e) {
				e.printStackTrace();
				Log.info("Failed :" + ServiceDevicePage.class.getName() + "- Radio button : " + webElementName + " not found.");
			}
		}
		else{
			Log.info("Failed :" + ServiceDevicePage.class.getName() + "- Radio button : " + webElementName + " is disabled.");
		}
		return wePh;
	}
	
	/*Method: setTextSimNumber
	 Description : To set the value of input(text) textSimNumber.
	 Parameter : @value - SIM number (length 20) example: 89014104279999989790
	 Return type : WebElement */
	
	public WebElement setTextSimNumber(String value)
	{
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(textSimNumber));
		WebElement wePh = textSimNumber; // WebElement object 
		String webElementName = "textSimNumber"; // WebElement object name string
		if(value!=null){
			try
			{
				wePh.clear();
				Log.info("Passed : "+ ServiceDevicePage.class.getName() + "- Textbox : " + webElementName + " is cleared.");
				wePh.sendKeys(value);
				Log.info("Passed : "+ ServiceDevicePage.class.getName() + "- Textbox : " + webElementName + " is set to " + value + ".");
			}
			catch(NoSuchElementException e)
			{
				e.printStackTrace();
				Log.info("Failed :" + ServiceDevicePage.class.getName() + "- Textbox : " + webElementName + " not found.");
			}
		}
		return wePh;
	}
	
	/*Method: setTextIMEI
	 Description : To set the value of input(text) textIMEI.
	 Parameter : @value - IMEI number (length 15 digits)
	 Return type : WebElement */
	
	public WebElement setTextIMEI(String value)
	{
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(textIMEI));
		WebElement wePh = textIMEI; // WebElement object 
		String webElementName = "textIMEI"; // WebElement object name string
		if(value!=null){
			try
			{
				wePh.clear();
				Log.info("Passed : "+ ServiceDevicePage.class.getName() + "- Textbox : " + webElementName + " is cleared.");
				wePh.sendKeys(value);
				Log.info("Passed : "+ ServiceDevicePage.class.getName() + "- Textbox : " + webElementName + " is set to " + value + ".");
			}
			catch(NoSuchElementException e)
			{
				e.printStackTrace();
				Log.info("Failed :" + ServiceDevicePage.class.getName() + "- Textbox : " + webElementName + " not found.");
			}
		}
		return wePh;
	}
	
	/*Method: setSelectLineSource
	Description : To select the value of Select selectLineSource.
	Parameter : @value - Sale From Inventory(selected)  
	Return type : WebElement */
	public WebElement setSelectLineSource(String value)
	{ 
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(selectLineSource));
		WebElement wePh = selectLineSource; // WebElement object
		String webElementName = "selectLineSource"; // WebElement object name string
		if (value!=null) {
			try {
				 Select selectWE = new Select(wePh);
				 selectWE.selectByValue(value);
				 Log.info("Passed : "+ ServiceDevicePage.class.getName() + "- Select : " + webElementName + " is set to " + value + ".");
			} catch(NoSuchElementException e) {
				e.printStackTrace();
				Log.info("Failed :" + ServiceDevicePage.class.getName() + "- Select : " + webElementName + " not found.");
			}
		}
		return wePh;
	}
	
	/*Method: setTextItemID
	 Description : To set the value of input(text) textItemID.
	 Parameter : @value - Device SKU , example : 69300
	 Return type : WebElement */
	
	public WebElement setTextItemID(String value)
	{
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(textItemID));
		WebElement wePh = textItemID; // WebElement object 
		String webElementName = "textItemID"; // WebElement object name string
		if(value!=null){
			try
			{
				wePh.clear();
				Log.info("Passed : "+ ServiceDevicePage.class.getName() + "- Textbox : " + webElementName + " is cleared.");
				wePh.sendKeys(value);
				Log.info("Passed : "+ ServiceDevicePage.class.getName() + "- Textbox : " + webElementName + " is set to " + value + ".");
			}
			catch(NoSuchElementException e)
			{
				e.printStackTrace();
				Log.info("Failed :" + ServiceDevicePage.class.getName() + "- Textbox : " + webElementName + " not found.");
			}
		}
		return wePh;
	}
	
	/*Method: clickBtnSearchItem
	Description : To click on  button btnSearchItem.
	Parameter : None
	Return type : void */
	public void clickBtnSearchItem()
	{
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(btnSearchItem));
		WebElement wePh = btnSearchItem; // WebElement object 
		String webElementName = "btnSearchItem"; // WebElement object name string
		try {
			wePh.click();
			Log.info("Passed : "+ ServiceDevicePage.class.getName() + "- Button : " + webElementName + " is clicked.");
			} catch(NoSuchElementException e) {
			e.printStackTrace();
			Log.info("Failed :" + ServiceDevicePage.class.getName() + "- Button : " + webElementName + " not found.");
			}
	}
	
	/*Method: setRadioFirstItem
	 Description : To set the value of input(radio) radioFirstItem.
	 Parameter : None
	 Return type : WebElement */
	public WebElement setRadioFirstItem(){
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(radioFirstItem));
		WebElement wePh = radioFirstItem; // WebElement object
		String webElementName = "radioFirstItem"; // WebElement object name string
		if(wePh.isEnabled()){ 
			try {
				wePh.click();
				Log.info("Passed : "+ ServiceDevicePage.class.getName() + "- Radio button : " + webElementName + " is set.");
			} catch(NoSuchElementException e) {
				e.printStackTrace();
				Log.info("Failed :" + ServiceDevicePage.class.getName() + "- Radio button : " + webElementName + " not found.");
			}
		}
		else{
			Log.info("Failed :" + ServiceDevicePage.class.getName() + "- Radio button : " + webElementName + " is disabled.");
		}
		return wePh;
	}
	
	/*Method: setSelectBillingLanguage
	Description : To select the value of Select selectBillingLanguage.
	Parameter : @value -  English(selected)|Spanish
	Return type : WebElement */
	public WebElement setSelectBillingLanguage(String value)
	{ 
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(selectBillingLanguage));
		WebElement wePh = selectBillingLanguage; // WebElement object
		String webElementName = "selectBillingLanguage"; // WebElement object name string
		if (value!=null) {
			try {
				 Select selectWE = new Select(wePh);
				 selectWE.selectByValue(value);
				 Log.info("Passed : "+ ServiceDevicePage.class.getName() + "- Select : " + webElementName + " is set to " + value + ".");
			} catch(NoSuchElementException e) {
				e.printStackTrace();
				Log.info("Failed :" + ServiceDevicePage.class.getName() + "- Select : " + webElementName + " not found.");
			}
		}
		return wePh;
	}
	
	/*Method: set
	Description : To select the value of Select .
	Parameter : @index -  
	Return type : WebElement */
	public WebElement setSelectBillingCycleDate(int index)
	{ 
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(selectBillingCycleDate));
		WebElement wePh = selectBillingCycleDate; // WebElement object
		String webElementName = "selectBillingCycleDate"; // WebElement object name string
			try {
				 Select selectWE = new Select(wePh);
				 selectWE.selectByIndex(index);
				 WebElement selectedOpt = selectWE.getFirstSelectedOption();
				 String selectedVal = selectedOpt.getAttribute("value");
				 Log.info("Passed : "+ ServiceDevicePage.class.getName() + "- Select : " + webElementName + " is set to " + selectedVal + ".");
			} catch(NoSuchElementException e) {
				e.printStackTrace();
				Log.info("Failed :" + ServiceDevicePage.class.getName() + "- Select : " + webElementName + " not found.");
			}
		return wePh;
	}
	
	/*Method: setTextFirstName
	 Description : To set the value of input(text) textFirstName.
	 Parameter : @value - First name of the user.
	 Return type : WebElement */
	
	public WebElement setTextFirstName(String value)
	{
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(textFirstName));
		WebElement wePh = textFirstName; // WebElement object 
		String webElementName = "textFirstName"; // WebElement object name string
		if(value!=null){
			try
			{
				wePh.clear();
				Log.info("Passed : "+ ServiceDevicePage.class.getName() + "- Textbox : " + webElementName + " is cleared.");
				wePh.sendKeys(value);
				Log.info("Passed : "+ ServiceDevicePage.class.getName() + "- Textbox : " + webElementName + " is set to " + value + ".");
			}
			catch(NoSuchElementException e)
			{
				e.printStackTrace();
				Log.info("Failed :" + ServiceDevicePage.class.getName() + "- Textbox : " + webElementName + " not found.");
			}
		}
		return wePh;
	}
	
	/*Method: setTextLastName
	 Description : To set the value of input(text) textLastName.
	 Parameter : @value - LastName of the user.
	 Return type : WebElement */
	
	public WebElement setTextLastName(String value)
	{
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(textLastName));
		WebElement wePh = textLastName; // WebElement object 
		String webElementName = "textLastName"; // WebElement object name string
		if(value!=null){
			try
			{
				wePh.clear();
				Log.info("Passed : "+ ServiceDevicePage.class.getName() + "- Textbox : " + webElementName + " is cleared.");
				wePh.sendKeys(value);
				Log.info("Passed : "+ ServiceDevicePage.class.getName() + "- Textbox : " + webElementName + " is set to " + value + ".");
			}
			catch(NoSuchElementException e)
			{
				e.printStackTrace();
				Log.info("Failed :" + ServiceDevicePage.class.getName() + "- Textbox : " + webElementName + " not found.");
			}
		}
		return wePh;
	}
	
	/*Method: setChkboxAddAuthUser
	 Description : To set the value of input(check box) chkboxAddAuthUser.
	 Parameter : None
	 Return type : WebElement */
	public WebElement setChkboxAddAuthUser(){
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(chkboxAddAuthUser));
		WebElement wePh = chkboxAddAuthUser; // WebElement object
				String webElementName = "chkboxAddAuthUser"; // WebElement object name string
		if(wePh.isEnabled()){
			try {
				wePh.click();
				Log.info("Passed : "+ ServiceDevicePage.class.getName() + "- CheckBox : " + webElementName + " is checked.");
			} catch(NoSuchElementException e) {
				e.printStackTrace();
				Log.info("Failed :" + ServiceDevicePage.class.getName() + "- CheckBox : " + webElementName + " not found.");
			}
		}
		else{
			Log.info("Failed :" + ServiceDevicePage.class.getName() + "- CheckBox : " + webElementName + " is disabled.");
		}
		return wePh;
	}
	
	/*Method: setSelectAuthTitle
	Description : To select the value of Select selectAuthTitle.
	Parameter : @value - Browse the list from application for available values.
	Return type : WebElement */
	public WebElement setSelectAuthTitle(String value)
	{ 
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(selectAuthTitle));
		WebElement wePh = selectAuthTitle; // WebElement object
		String webElementName = "selectAuthTitle"; // WebElement object name string
		if (value!=null) {
			try {
				 Select selectWE = new Select(wePh);
				 selectWE.selectByValue(value);
				 Log.info("Passed : "+ ServiceDevicePage.class.getName() + "- Select : " + webElementName + " is set to " + value + ".");
			} catch(NoSuchElementException e) {
				e.printStackTrace();
				Log.info("Failed :" + ServiceDevicePage.class.getName() + "- Select : " + webElementName + " not found.");
			}
		}
		return wePh;
	}
	
	/*Method: setTextAuthUserFname
	 Description : To set the value of input(text) textAuthUserFname.
	 Parameter : @value - Authorized User First Name
	 Return type : WebElement */
	
	public WebElement setTextAuthUserFname(String value)
	{
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(textAuthUserFname));
		WebElement wePh = textAuthUserFname; // WebElement object 
		String webElementName = "textAuthUserFname"; // WebElement object name string
		if(value!=null){
			try
			{
				wePh.clear();
				Log.info("Passed : "+ ServiceDevicePage.class.getName() + "- Textbox : " + webElementName + " is cleared.");
				wePh.sendKeys(value);
				Log.info("Passed : "+ ServiceDevicePage.class.getName() + "- Textbox : " + webElementName + " is set to " + value + ".");
			}
			catch(NoSuchElementException e)
			{
				e.printStackTrace();
				Log.info("Failed :" + ServiceDevicePage.class.getName() + "- Textbox : " + webElementName + " not found.");
			}
		}
		return wePh;
	}
	
	/*Method: setTextAuthUserMname
	 Description : To set the value of input(text) textAuthUserMname.
	 Parameter : @value - Authorized User Middle Name
	 Return type : WebElement */
	
	public WebElement setTextAuthUserMname(String value)
	{
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(textAuthUserMname));
		WebElement wePh = textAuthUserMname; // WebElement object 
		String webElementName = "textAuthUserMname"; // WebElement object name string
		if(value!=null){
			try
			{
				wePh.clear();
				Log.info("Passed : "+ ServiceDevicePage.class.getName() + "- Textbox : " + webElementName + " is cleared.");
				wePh.sendKeys(value);
				Log.info("Passed : "+ ServiceDevicePage.class.getName() + "- Textbox : " + webElementName + " is set to " + value + ".");
			}
			catch(NoSuchElementException e)
			{
				e.printStackTrace();
				Log.info("Failed :" + ServiceDevicePage.class.getName() + "- Textbox : " + webElementName + " not found.");
			}
		}
		return wePh;
	}
	
	/*Method: setTextAuthUserLname
	 Description : To set the value of input(text) textAuthUserLname.
	 Parameter : @value - Authorized User Last Name
	 Return type : WebElement */
	
	public WebElement setTextAuthUserLname(String value)
	{
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(textAuthUserLname));
		WebElement wePh = textAuthUserLname; // WebElement object 
		String webElementName = "textAuthUserLname"; // WebElement object name string
		if(value!=null){
			try
			{
				wePh.clear();
				Log.info("Passed : "+ ServiceDevicePage.class.getName() + "- Textbox : " + webElementName + " is cleared.");
				wePh.sendKeys(value);
				Log.info("Passed : "+ ServiceDevicePage.class.getName() + "- Textbox : " + webElementName + " is set to " + value + ".");
			}
			catch(NoSuchElementException e)
			{
				e.printStackTrace();
				Log.info("Failed :" + ServiceDevicePage.class.getName() + "- Textbox : " + webElementName + " not found.");
			}
		}
		return wePh;
	}
	
	/*Method: ssetSelectAuthSuffixet
	Description : To select the value of Select selectAuthSuffix.
	Parameter : @value -  Browse the list from application for available values.
	Return type : WebElement */
	public WebElement setSelectAuthSuffix(String value)
	{ 
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(selectAuthSuffix));
		WebElement wePh = selectAuthSuffix; // WebElement object
		String webElementName = "selectAuthSuffix"; // WebElement object name string
		if (value!=null) {
			try {
				 Select selectWE = new Select(wePh);
				 selectWE.selectByValue(value);
				 Log.info("Passed : "+ ServiceDevicePage.class.getName() + "- Select : " + webElementName + " is set to " + value + ".");
			} catch(NoSuchElementException e) {
				e.printStackTrace();
				Log.info("Failed :" + ServiceDevicePage.class.getName() + "- Select : " + webElementName + " not found.");
			}
		}
		return wePh;
	}
	
	/*Method: setTextAuthComments
	 Description : To set the value of input(text) textAuthComments.
	 Parameter : @value - Authorized user comments.
	 Return type : WebElement */
	
	public WebElement setTextAuthComments(String value)
	{
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(textAuthComments));
		WebElement wePh = textAuthComments; // WebElement object 
		String webElementName = "textAuthComments"; // WebElement object name string
		if(value!=null){
			try
			{
				wePh.clear();
				Log.info("Passed : "+ ServiceDevicePage.class.getName() + "- Textbox : " + webElementName + " is cleared.");
				wePh.sendKeys(value);
				Log.info("Passed : "+ ServiceDevicePage.class.getName() + "- Textbox : " + webElementName + " is set to " + value + ".");
			}
			catch(NoSuchElementException e)
			{
				e.printStackTrace();
				Log.info("Failed :" + ServiceDevicePage.class.getName() + "- Textbox : " + webElementName + " not found.");
			}
		}
		return wePh;
	}
	
	/*Method: clickBtnAddAuthUser
	Description : To click on  button btnAddAuthUser.
	Parameter : None
	Return type : void */
	public void clickBtnAddAuthUser()
	{
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(btnAddAuthUser));
		WebElement wePh = btnAddAuthUser; // WebElement object 
		String webElementName = "btnAddAuthUser"; // WebElement object name string
		try {
			wePh.click();
			Log.info("Passed : "+ ServiceDevicePage.class.getName() + "- Button : " + webElementName + " is clicked.");
			} catch(NoSuchElementException e) {
			e.printStackTrace();
			Log.info("Failed :" + ServiceDevicePage.class.getName() + "- Button : " + webElementName + " not found.");
			}
	}
	
	/*Method: clickBtnCancel
	Description : To click on  button btnCancel.
	Parameter : None
	Return type : void */
	public void clickBtnCancel()
	{
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(btnCancel));
		WebElement wePh = btnCancel; // WebElement object 
		String webElementName = "btnCancel"; // WebElement object name string
		try {
			wePh.click();
			Log.info("Passed : "+ ServiceDevicePage.class.getName() + "- Button : " + webElementName + " is clicked.");
			} catch(NoSuchElementException e) {
			e.printStackTrace();
			Log.info("Failed :" + ServiceDevicePage.class.getName() + "- Button : " + webElementName + " not found.");
			}
	}
	
	/*Method: clickBtnPrevious
	Description : To click on  button btnPrevious.
	Parameter : None
	Return type : void */
	public void clickBtnPrevious()
	{
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(btnPrevious));
		WebElement wePh = btnPrevious; // WebElement object 
		String webElementName = "btnPrevious"; // WebElement object name string
		try {
			wePh.click();
			Log.info("Passed : "+ ServiceDevicePage.class.getName() + "- Button : " + webElementName + " is clicked.");
			} catch(NoSuchElementException e) {
			e.printStackTrace();
			Log.info("Failed :" + ServiceDevicePage.class.getName() + "- Button : " + webElementName + " not found.");
			}
	}
	
	/*Method: clickBtnNext
	Description : To click on  button btnNext.
	Parameter : None
	Return type : void */
	public RatePlanPage clickBtnNext()
	{
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(btnNext));
		WebElement wePh = btnNext; // WebElement object 
		String webElementName = "btnNext"; // WebElement object name string
		try {
			wePh.click();
			Log.info("Passed : "+ ServiceDevicePage.class.getName() + "- Button : " + webElementName + " is clicked.");
			} catch(NoSuchElementException e) {
			e.printStackTrace();
			Log.info("Failed :" + ServiceDevicePage.class.getName() + "- Button : " + webElementName + " not found.");
			}
		return new RatePlanPage(driver);
	}
	
	
	/*Method: setRadioDeviceOptions
	 Description : To set the value of input(radio) radioDeviceOptions.
	 Parameter : None
	 Return type : WebElement */
	public WebElement setRadioDFDeviceOptions(){
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(radioDeviceOptions));
		WebElement wePh = radioDFDeviceOptions; // WebElement object
		String webElementName = "radioDFDeviceOptions"; // WebElement object name string
		if(wePh.isEnabled()){ 
			try {
				wePh.click();
				Log.info("Passed : "+ ServiceDevicePage.class.getName() + "- Radio button : " + webElementName + " is set.");
			} catch(NoSuchElementException e) {
				e.printStackTrace();
				Log.info("Failed :" + ServiceDevicePage.class.getName() + "- Radio button : " + webElementName + " not found.");
			}
		}
		else{
			Log.info("Failed :" + ServiceDevicePage.class.getName() + "- Radio button : " + webElementName + " is disabled.");
		}
		return wePh;
	}
}