/*
Description : This class identify and implement all the web
element and its corresponding action of Installment plan agreement page one of four
Version info : V_0.1
Date : 08/06/2017
Author : Devendra Bhavsar
Copyright notice : Tech Mahindra Ltd
 */
package com.pageobject;

import java.util.NoSuchElementException;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;

import com.utility.Logg;
import com.utility.Util;

public class InstallmentPlanPageOne {
Util u = new Util();
	
	WebDriver driver = u.getDriver();
	 Logger Log = Logg.createLogger();
	public InstallmentPlanPageOne(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(new AjaxElementLocatorFactory(driver,20),this);
	}
		
	
/*-------------------------------------------------------- Page objects ---------------------------------------------------- */
	
	@FindBy(how = How.ID, using = "nextBtn")
	private WebElement btnNext;
	
	/*-------------------------------------------------------- Page actions ---------------------------------------------------- */
	
	/*Method: clickBtnNext
	Description : To click on  button btnNext.
	Parameter : None
	Return type : void */
	public void clickBtnNext()
	{
		WebElement wePh = btnNext; // WebElement object 
		String webElementName = "btnNext"; // WebElement object name string
		try {
			wePh.click();
			Log.info("Passed : "+ InstallmentPlanPageOne.class.getName() + "- Button : " + webElementName + " is clicked.");
			} catch(NoSuchElementException e) {
			e.printStackTrace();
			Log.info("Failed :" + InstallmentPlanPageOne.class.getName() + "- Button : " + webElementName + " not found.");
			}
	}
}
