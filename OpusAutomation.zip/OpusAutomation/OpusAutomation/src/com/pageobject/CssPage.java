/*
Description : This class identify and implement all the web
element and its corresponding action of CS Page
Consent page.
Version info : V_0.1
Date : 05/06/2017
Author : Devendra Bhavsar
Copyright notice : Tech Mahindra Ltd
 */
package com.pageobject;

import java.util.NoSuchElementException;

import org.apache.log4j.Logger;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.utility.Logg;
import com.utility.Util;


public class CssPage {
	Util u = new Util();
	WebDriver driver = u.getDriver();
	Logger Log = Logg.createLogger();

	
	public CssPage(WebDriver driver){
		this.driver = driver;
		PageFactory.initElements(new AjaxElementLocatorFactory(driver, 20), this);
	}
	
	/*-------------------------------------------------------- Page objects ---------------------------------------------------- */
	
	@FindBy(how = How.XPATH, using = "//form/div[2]/div[2]/div[2][contains(text(),'Customer Summary')]")
	public WebElement customersummaryPageHeader;
	
	@FindBy(how = How.XPATH, using = "//div[@id='banlevelCss_EnforcementCheck_popup']/div/div[contains(text(),'Review MySummary and CSS ')]")
	public WebElement reviewMySummaryPageHeader;
	
	
	@FindBy(how = How.XPATH, using = "//span[@id = 'previousSelectedMob']")
	private WebElement spanWirelessNumber;
	

	@FindBy(how=How.XPATH,using="//button[@name='payNow']/b/em/u[contains(text(),'ChkOut')]")
	//div/button[contains(text(),'Check Out�')] 1707 xpath
	////button[@name='payNow']/b/em/u[contains(text(),'ChkOut')]   1706 xpath
	private WebElement checkOut;
	
	@FindBy(how=How.XPATH,using="//div/button[@id='btnWirelessCSS']/b/em")
	private WebElement reviewmysummaryandcss;
	
	@FindBy(how = How.ID, using = "imgCancelWirelessCSS")
	private WebElement imgCross;
	
	@FindBy(how = How.ID, using = "btnCancelWirelessCSS")
	private WebElement btnCancel;
	

	@FindBy(how = How.ID, using = "paynowbutton")
	private WebElement btnPayNow;

	
	
	/*-------------------------------------------------------- Page actions ---------------------------------------------------- */
	
	/*Method: getText
	Description : To get text of element spanWirelessNumber.
	Parameter : None
	Return type : WebElement */
	public WebElement getTextSpanWirelessNumber()
	{
		WebElement wePh = spanWirelessNumber; // WebElement object 
		String webElementName = "spanWirelessNumber"; // WebElement object name string
		try {
			String value = wePh.getText();
			Log.info("Passed : "+ CssPage.class.getName() + "- SPAN : " + webElementName + " has text" + value + ".");
			} catch(NoSuchElementException e) {
			e.printStackTrace();
			Log.info("Failed :" + CssPage.class.getName() + "- SPAN : " + webElementName + " not found.");
			}
		return wePh;
	}
	
	/*Method: clickBtnCheckOut
	Description : To click on  button btnCheckOut.
	Parameter : None
	Return type : void */
	
	/*Method: clickImgCross
	Description : To click on cross image imgCross.
	Parameter : None
	Return type : void */
	public void clickImgCross()
	{
		WebElement wePh = imgCross; // WebElement object 
		String webElementName = "imgCross"; // WebElement object name string
		try {
			wePh.click();
			Log.info("Passed : "+ ServiceDevicePage.class.getName() + "- Image : " + webElementName + " is clicked.");
			} catch(NoSuchElementException e) {
			e.printStackTrace();
			Log.info("Failed :" + ServiceDevicePage.class.getName() + "- Image : " + webElementName + " not found.");
			}
	}
	
	/*Method: clickBtnCancel
	Description : To click on  button btnCancel.
	Parameter : None
	Return type : void */
	public void clickBtnCancel()
	{
		WebElement wePh = btnCancel; // WebElement object 
		String webElementName = "btnCancel"; // WebElement object name string
		try {
			wePh.click();
			Log.info("Passed : "+ ServiceDevicePage.class.getName() + "- Button : " + webElementName + " is clicked.");
			} catch(NoSuchElementException e) {
			e.printStackTrace();
			Log.info("Failed :" + ServiceDevicePage.class.getName() + "- Button : " + webElementName + " not found.");
			}
	}
	
	/*Method: clickBtnView
	Description : To click on  button btnView. 
	Parameter : None
	Return type : void */


	public  CssPage clickonCheckOut(){
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(checkOut));
		if (checkOut!=null) {
			try {
				checkOut.click();
				Log.info(CpniPage.class.getName() +"able to click button");

			} catch(NoSuchElementException e) {
					e.printStackTrace();
					Log.info(CpniPage.class.getName() + "unable to click on button");

			}
		}
		return new CssPage(driver);
	}
	
	public  TaxTypeInfoPage clickonCheckOutIRU(){
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(checkOut));
		if (checkOut!=null) {
			try {
				checkOut.click();
				Log.info(CpniPage.class.getName() +"able to click button");

			} catch(NoSuchElementException e) {
					e.printStackTrace();
					Log.info(CpniPage.class.getName() + "unable to click on button");

			}
		}
		return new TaxTypeInfoPage(driver);
	}
	
	
	
	
		public  WcaPage clickonViewSummary(){
			u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(reviewmysummaryandcss));
			if (reviewmysummaryandcss!=null) {
				try {
					JavascriptExecutor js = (JavascriptExecutor)driver;
					js.executeScript("arguments[0].click();",reviewmysummaryandcss);
				//	reviewmysummaryandcss.click();
					/*Actions a  = new Actions(driver);
					a.clickAndHold(reviewmysummaryandcss).build().perform();*/
					u.waits(20000);
					Log.info(CpniPage.class.getName() +"able to click button");

				} catch(NoSuchElementException e) {
						e.printStackTrace();
						Log.info(CpniPage.class.getName() + "unable to click on button");

				}
			}
			return new WcaPage(driver);

	}
	

	public  CssPage clickBtnPayNow(){
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(btnPayNow));
		if (btnPayNow!=null) {
			try {
				btnPayNow.click();
				Log.info(CpniPage.class.getName() +"able to click button");

			} catch(NoSuchElementException e) {
					e.printStackTrace();
					Log.info(CpniPage.class.getName() + "unable to click on button");

			}
		}
		return new CssPage(driver);
	}
	
	
}
