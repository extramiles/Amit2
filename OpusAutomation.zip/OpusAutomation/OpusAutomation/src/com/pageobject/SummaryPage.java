/* * ClassName : SummaryPage
Description : This class identifies and implements all the web
elements and their corresponding actions of Summary page.
Version info : V_0.1
Date : 01/06/2017
Author : Tech Mahindra
Copyright notice : Tech Mahindra Ltd 
 */

package com.pageobject;

import org.apache.log4j.Logger;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.utility.Logg;
import com.utility.Util;

public class SummaryPage {
	//WebDriver driver;
	String webElementName;
	Util u = new Util();
	WebDriver driver = u.getDriver();
	Logger Log = Logg.createLogger();

	public SummaryPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(new AjaxElementLocatorFactory(driver, 20),
				this);
	}
	@FindBy(how = How.XPATH, using = "//div[@id='column1of1']/h2/b/em[contains(text(),'Summary')]")
	public WebElement summaryPageHeader;

	@FindBy(how = How.XPATH, using = "//input[@name='paperlessBillingEnrollmentOption' and @value='NotEnrolling']")
	private WebElement radioPaperLessNo;

	@FindBy(how = How.CSS, using = "input[name='paperlessBillingEnrollmentOption'] [value='Enrolling']")
	private WebElement radioPaperLessYes;

	@FindBy(how = How.ID, using = "customeremailprimary_emailId")
	private WebElement textPrimaryEmail;

	@FindBy(how = How.NAME, using = "paperlessCustomerEmailPrimaryConfirm.emailId")
	private WebElement textConfirmEmail;

	@FindBy(how = How.ID, using = "btnremove")
	private WebElement btnEnroll;

	@FindBy(how = How.ID, using = "chkBillingOptions")
	private WebElement checkAutoPay;

	@FindBy(how = How.ID, using = "sendToSigCap")
	private WebElement btnUseStation;

	@FindBy(how = How.ID, using = "radautopayCC")
	private WebElement radioCreditCard;

	@FindBy(how = How.ID, using = "radautopayDC")
	private WebElement radioDebitCard;

	@FindBy(how = How.ID, using = "radautopayChecking")
	private WebElement radioCheckingAccount;

	@FindBy(how = How.ID, using = "radautopaySaving")
	private WebElement radioSavingsAccount;

	@FindBy(how = How.ID, using = "accept")
	private WebElement radioAcceptTermsYes;

	@FindBy(how = How.ID, using = "deny")
	private WebElement radioAcceptTermsNo;

	@FindBy(how = How.ID, using = "onclick")
	private WebElement btnImportData;

	@FindBy(how = How.NAME, using = "bankAccountName")
	private WebElement textNameAccount;

	@FindBy(how = How.NAME, using = "bankRoutingNumber")
	private WebElement textRoutingNumber;

	@FindBy(how = How.ID, using = "password_bankAccountNumber")
	private WebElement textAccountNumber;

	@FindBy(how = How.XPATH, using = "//div[@class='buttonArea']/button[text()='view summary']")
	private WebElement btnViewSummary;

	@FindBy(how = How.XPATH, using = "//div[@class='buttonArea']/button/b/em/u[text()='Finished']")
	private WebElement btnFinished;
	
	@FindBy(how = How.XPATH, using = "//div/div[4]/input[@id='reFillRadio']")
	private WebElement radioPinPurchase;
	
	
	@FindBy(how = How.ID, using = "oneTimePaymentRadio")
	private WebElement radioPinAutopay;

	@FindBy(how = How.ID, using = "next")
	private WebElement btnNextGoPh;
	
	@FindBy(how = How.LINK_TEXT, using = "Add an Individual or Mobile Share Subscriber to this Account")
	private WebElement linkFTMultiLine;
	
	@FindBy(how = How.NAME, using = "selectedRatePlanType")
	private WebElement radioNewFT;
	
	@FindBy(how = How.ID, using = "addlinebutton")
	private WebElement btnAddLine;

	/*
	 * Method: public void clickPaperLessNo() Description : To click on NO
	 * option radio button for Paper less billingradio button. Parameter : None
	 * Return type : Void
	 */
	public void clickPaperLessNo() {
		webElementName = "radioPaperLessNo";
		try {
			u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(radioPaperLessNo));
			if (radioPaperLessNo.isSelected()) {
				Log.info("Passed" + SummaryPage.class.getName() + ","
						+ "No option for paperless billing is pre selected");
			} else {
				radioPaperLessNo.click();
				Log.info("Passed" + SummaryPage.class.getName() + ","
						+ "No option for paperless billing selected");
			}
		} catch (NoSuchElementException e) {
			e.printStackTrace();
			Log.info("Failed" + SummaryPage.class.getName() + webElementName
					+ " not found ");
		}
	}

	/*
	 * Method: public void clickPaperLessYes() Description : To click on Yes
	 * option radio button for Paper less billingradio button. Parameter : None
	 * Return type : Void
	 */
	public void clickPaperLessYes() {
		webElementName = "radioPaperLessYes";
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(radioPaperLessYes));
		try {
			if (radioPaperLessYes.isSelected()) {
				Log.info("Passed" + SummaryPage.class.getName() + ","
						+ "Yes option for paperless billing is pre selected");
			} else {
				radioPaperLessYes.click();
				Log.info("Passed" + SummaryPage.class.getName() + ","
						+ "Yes option for paperless billing selected");
			}
		} catch (NoSuchElementException e) {
			e.printStackTrace();
			Log.info("Failed" + SummaryPage.class.getName() + webElementName
					+ " not found ");
		}
	}

	/*
	 * Method: enterPrimaryEmail Description : To enter Primary Email for paper
	 * less billing enrollment. Parameter :
	 * 
	 * @setPrimaryEmail : Parameter to hold input value of primary email id.
	 * Return type : Void
	 */

	public void enterPrimaryEmail(String setPrimaryEmail) {
		webElementName = "textPrimaryEmail";
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(textPrimaryEmail));
		if (setPrimaryEmail != null) {
			try {
				textPrimaryEmail.clear();
				Log.info("Passed" + SummaryPage.class.getName() + ","
						+ webElementName + " cleared ");
				textPrimaryEmail.sendKeys(setPrimaryEmail);
				Log.info("Passed" + SummaryPage.class.getName() + ","
						+ setPrimaryEmail + " entered ");
			} catch (NoSuchElementException e) {
				e.printStackTrace();
				Log.info("Failed" + SummaryPage.class.getName()
						+ webElementName + " not found ");
			}
		}
	}

	/*
	 * Method: enterConfirmEmail Description : To enter Primary Email for paper
	 * less billing enrollment. Parameter :
	 * 
	 * @setConfirmEmail : Parameter to hold input value of primary(confirmation)
	 * email id. Return type : Void
	 */

	public void enterConfirmEmail(String setConfirmEmail) {
		webElementName = "textConfirmEmail";
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(textConfirmEmail));
		if (setConfirmEmail != null) {
			try {
				textPrimaryEmail.clear();
				Log.info("Passed" + SummaryPage.class.getName() + ","
						+ webElementName + " cleared ");
				textPrimaryEmail.sendKeys(setConfirmEmail);
				Log.info("Passed" + SummaryPage.class.getName() + ","
						+ setConfirmEmail + " entered ");
			} catch (NoSuchElementException e) {
				e.printStackTrace();
				Log.info("Failed" + SummaryPage.class.getName()
						+ webElementName + " not found ");
			}
		}
	}

	/*
	 * Method: public void clickEnroll() Description : To click on Enroll button
	 * to enroll in paper less billing . Parameter : None Return type : Void
	 */
	public void clickEnroll() {
		webElementName = "btnEnroll";
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(btnEnroll));
		try {
			btnEnroll.click();
			Log.info("Passed" + SummaryPage.class.getName() + ","
					+ "Enroll button clicked");
		} catch (NoSuchElementException e) {
			e.printStackTrace();
			Log.info("Failed" + SummaryPage.class.getName() + webElementName
					+ " not found ");
		}
	}

	/*
	 * Method: public void clickAutoPay() Description : To click on AutoPay checkbox.
	 * Parameter : None Return type : Void
	 */
	public void clickAutoPay() {
		webElementName = "checkAutoPay";
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(checkAutoPay));
		try {
			checkAutoPay.click();
			Log.info("Passed" + SummaryPage.class.getName() + ","
					+ "AutoPAy checkbox clicked");
		} catch (NoSuchElementException e) {
			e.printStackTrace();
			Log.info("Failed" + SummaryPage.class.getName() + webElementName
					+ " not found ");
		}
	}

	/*
	 * Method: clickUseStation Description : To click on Use Station button to
	 * launch Signature Capture . Parameter : None Return type : Void
	 */
	public void clickUseStation() {
		webElementName = "btnUseStation";
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(btnUseStation));
		try {
			btnUseStation.click();
			Log.info("Passed" + SummaryPage.class.getName() + ","
					+ "Use Station button clicked");
		} catch (NoSuchElementException e) {
			e.printStackTrace();
			Log.info("Failed" + SummaryPage.class.getName() + webElementName
					+ " not found ");
		}
	}

	/*
	 * Method: public void clickCreditCard() Description : To click on Credit
	 * Card radio button for AutoPay enrollmentradio button. Parameter : None
	 * Return type : Void
	 */
	public void clickCreditCard() {
		webElementName = "radioCreditCard";
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(radioCreditCard));
		try {
			if (radioCreditCard.isSelected()) {
				Log.info("Passed" + SummaryPage.class.getName() + ","
						+ "Credit Card radio button is pre selected");
			} else {
				radioCreditCard.click();
				Log.info("Passed" + SummaryPage.class.getName() + ","
						+ "Credit Card radio button selected");
			}
		} catch (NoSuchElementException e) {
			e.printStackTrace();
			Log.info("Failed" + SummaryPage.class.getName() + webElementName
					+ " not found ");
		}
	}

	/*
	 * Method: public void clickDebitCard() Description : To click on Check/
	 * Debit Card radio button for AutoPay enrollment radio button. Parameter :
	 * None Return type : Void
	 */
	public void clickDebitCard() {
		webElementName = "radioDebitCard";
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(radioDebitCard));
		try {
			if (radioDebitCard.isSelected()) {
				Log.info("Passed" + SummaryPage.class.getName() + ","
						+ "Debit Card radio button is pre selected");
			} else {
				radioDebitCard.click();
				Log.info("Passed" + SummaryPage.class.getName() + ","
						+ "Debit Card radio button selected");
			}
		} catch (NoSuchElementException e) {
			e.printStackTrace();
			Log.info("Failed" + SummaryPage.class.getName() + webElementName
					+ " not found ");
		}
	}

	/*
	 * Method: public void clickCheckingAccount() Description : To click on
	 * Checking Account radio button for AutoPay enrollment radio button.
	 * Parameter : None Return type : Void
	 */
	public void clickCheckingAccount() {
		webElementName = "radioCheckingAccount";
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(radioCheckingAccount));
		try {
			if (radioCheckingAccount.isSelected()) {
				Log.info("Passed" + SummaryPage.class.getName() + ","
						+ "Checking Account radio button is pre selected");
			} else {
				radioCheckingAccount.click();
				Log.info("Passed" + SummaryPage.class.getName() + ","
						+ "Checking Account radio button selected");
			}
		} catch (NoSuchElementException e) {
			e.printStackTrace();
			Log.info("Failed" + SummaryPage.class.getName() + webElementName
					+ " not found ");
		}
	}

	/*
	 * Method: public void clickSavingAccount() Description : To click on
	 * Savings Account radio button for AutoPay enrollmentradio button.
	 * Parameter : None Return type : Void
	 */
	public void clickSavingAccount() {
		webElementName = "radioSavingsAccount";
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(radioSavingsAccount));
		try {
			if (radioSavingsAccount.isSelected()) {
				Log.info("Passed" + SummaryPage.class.getName() + ","
						+ "Savings Account radio button is pre selected");
			} else {
				radioSavingsAccount.click();
				Log.info("Passed" + SummaryPage.class.getName() + ","
						+ "Savings Account radio button selected");
			}
		} catch (NoSuchElementException e) {
			e.printStackTrace();
			Log.info("Failed" + SummaryPage.class.getName() + webElementName
					+ " not found ");
		}
	}

	/*
	 * Method: public void clickAcceptTermsYes() Description : To click on Yes
	 * option radio button to Accept Terms radio button. Parameter : None Return
	 * type : Void
	 */
	public void clickAcceptTermsYes() {
		webElementName = "radioAcceptTermsYes";
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(radioAcceptTermsYes));
		try {
			if (radioAcceptTermsYes.isSelected()) {
				Log.info("Passed" + SummaryPage.class.getName() + ","
						+ "Yes option to Accept Terms is pre selected");
			} else {
				radioAcceptTermsYes.click();
				Log.info("Passed" + SummaryPage.class.getName() + ","
						+ "Yes option to Accept Term selected");
			}
		} catch (NoSuchElementException e) {
			e.printStackTrace();
			Log.info("Failed" + SummaryPage.class.getName() + webElementName
					+ " not found ");
		}
	}

	/*
	 * Method: public void clickAcceptTermsNo() Description : To click on No
	 * option radio button to Accept Terms radio button. Parameter : None Return
	 * type : Void
	 */
	public void clickAcceptTermsNo() {
		webElementName = "radioAcceptTermsNo";
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(radioAcceptTermsNo));
		try {
			if (radioAcceptTermsNo.isSelected()) {
				Log.info("Passed" + SummaryPage.class.getName() + ","
						+ "No option to Accept Terms is pre selected");
			} else {
				radioAcceptTermsNo.click();
				Log.info("Passed" + SummaryPage.class.getName() + ","
						+ "No option to Accept Term selected");
			}
		} catch (NoSuchElementException e) {
			e.printStackTrace();
			Log.info("Failed" + SummaryPage.class.getName() + webElementName
					+ " not found ");
		}
	}

	/*
	 * Method: public void clickImportData() Description : To click on Import
	 * Data button to import details . Parameter : None Return type : Void
	 */
	public void clickImportData() {
		webElementName = "btnImportData";
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(btnImportData));
		try {
			btnImportData.click();
			Log.info("Passed" + SummaryPage.class.getName() + ","
					+ "Import Data Button Clicked");
		} catch (NoSuchElementException e) {
			e.printStackTrace();
			Log.info("Failed" + SummaryPage.class.getName() + webElementName
					+ " not found ");
		}
	}

	/*
	 * Method: enterNameOnAccount Description : To enter value in Name on
	 * Account text box. Parameter : @setNameAccount : Parameter to hold input
	 * value of Name on Account. Return type : Void
	 */

	public void enterNameOnAccount(String setNameAccount) {
		webElementName = "textNameAccount";
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(textNameAccount));
		if (setNameAccount != null) {
			try {
				textNameAccount.clear();
				Log.info("Passed" + SummaryPage.class.getName() + ","
						+ webElementName + " cleared ");
				textNameAccount.sendKeys(setNameAccount);
				Log.info("Passed" + SummaryPage.class.getName() + ","
						+ setNameAccount + " entered ");
			} catch (NoSuchElementException e) {
				e.printStackTrace();
				Log.info("Failed" + SummaryPage.class.getName()
						+ webElementName + " not found ");
			}
		}
	}

	/*
	 * Method: enterRoutingNumber Description : To enter value in Routing Number
	 * text box. Parameter : @setRoutingNumber : Parameter to hold input value
	 * of Routing number. Return type : Void
	 */

	public void enterRoutingNumber(String setRoutingNumber) {
		webElementName = "textRoutingNumber";
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(textRoutingNumber));
		if (setRoutingNumber != null) {
			try {
				textRoutingNumber.clear();
				Log.info("Passed" + SummaryPage.class.getName() + ","
						+ webElementName + " cleared ");
				textRoutingNumber.sendKeys(setRoutingNumber);
				Log.info("Passed" + SummaryPage.class.getName() + ","
						+ setRoutingNumber + " entered ");
			} catch (NoSuchElementException e) {
				e.printStackTrace();
				Log.info("Failed" + SummaryPage.class.getName()
						+ webElementName + " not found ");
			}
		}
	}

	/*
	 * Method: enterAccountNumber Description : To enter value in Account Number
	 * text box. Parameter : @setAccountNumber : Parameter to hold input value
	 * of Account number. Return type : Void
	 */

	public void enterAccountNumber(String setAccountNumber) {
		webElementName = "textAccountNumber";
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(textAccountNumber));
		if (setAccountNumber != null) {
			try {
				textAccountNumber.clear();
				Log.info("Passed" + SummaryPage.class.getName() + ","
						+ webElementName + " cleared ");
				textAccountNumber.sendKeys(setAccountNumber);
				Log.info("Passed" + SummaryPage.class.getName() + ","
						+ setAccountNumber + " entered ");
			} catch (NoSuchElementException e) {
				e.printStackTrace();
				Log.info("Failed" + SummaryPage.class.getName()
						+ webElementName + " not found ");
			}
		}
	}

	/*
	 * Method: clickViewSummary Description : To click on View Summary button.
	 * Parameter : None Return type : Void
	 */
	public void clickViewSummary() {
		webElementName = "btnViewSummary";
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(btnViewSummary));
		try {
			btnViewSummary.click();
			Log.info("Passed" + SummaryPage.class.getName() + ","
					+ "View Summary Button clicked");
		} catch (NoSuchElementException e) {
			e.printStackTrace();
			Log.info("Failed" + SummaryPage.class.getName() + webElementName
					+ " not found ");
		}
	}

	/*
	 * Method: clickFinished Description : To click on Finished button.
	 * Parameter : None Return type : Void
	 */
	public NextStepPromoPage clickFinished() {
		webElementName = "btnFinished";
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(btnFinished));
		try {
			btnFinished.click();
			Log.info("Passed" + SummaryPage.class.getName() + ","
					+ "Finished clicked");
		} catch (NoSuchElementException e) {
			e.printStackTrace();
			Log.info("Failed" + SummaryPage.class.getName() + webElementName
					+ " not found ");
		}
		return new NextStepPromoPage(driver);
	}
	
	/*
	 * Method: public void clickPinPurchase() Description : To select PIN purchase for GoPhone. Parameter : None
	 * Return type : Void
	 */
	public void clickPinPurchase() {
		webElementName = "radioPinPurchase";
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(radioPinPurchase));
		try {
			if (radioPinPurchase.isSelected()) {
				Log.info("Passed" + SummaryPage.class.getName() + ","
						+ "PIN purchase option is pre selected");
			} else {
				radioPinPurchase.click();
				Log.info("Passed" + SummaryPage.class.getName() + ","
						+ "PIN purchase option selected");
			}
		} catch (NoSuchElementException e) {
			e.printStackTrace();
			Log.info("Failed" + SummaryPage.class.getName() + webElementName
					+ " not found ");
		}
	}
	
	/*
	 * Method: public void clickPinAutopay() Description : To select PIN purchase with Autopay for GoPhone. Parameter : None
	 * Return type : Void
	 */
	public void clickPinAutopay() {
		webElementName = "radioPinAutopay";
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(radioPinAutopay));
		try {
			if (radioPinAutopay.isSelected()) {
				Log.info("Passed" + SummaryPage.class.getName() + ","
						+ "PIN purchase with Autopay option is pre selected");
			} else {
				radioPinAutopay.click();
				Log.info("Passed" + SummaryPage.class.getName() + ","
						+ "PIN purchase with Autopayoption selected");
			}
		} catch (NoSuchElementException e) {
			e.printStackTrace();
			Log.info("Failed" + SummaryPage.class.getName() + webElementName
					+ " not found ");
		}
	}
	
	/*
	 * Method: clickNextGoPh Description : To click on Next button.
	 * Parameter : None Return type : Void
	 */
	public SellPinPage clickNextGoPh() {
		webElementName = "btnNextGoPh";
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(btnNextGoPh));
		try {
			btnNextGoPh.click();
			Log.info("Passed" + SummaryPage.class.getName() + ","
					+ "Next clicked");
		} catch (NoSuchElementException e) {
			e.printStackTrace();
			Log.info("Failed" + SummaryPage.class.getName() + webElementName
					+ " not found ");
		}
		return new SellPinPage(driver);
	}
	
	/*
	 * Method: clickFamilyTalkMultiline Description : To click on Add new line for FamilyTalk multiline activation .
	 * Parameter : None Return type : Void
	 */
	public void clickFamilyTalkMultiline() {
		webElementName = "linkFTMultiLine";
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(linkFTMultiLine));
		try {
			linkFTMultiLine.click();
			Log.info("Passed" + SummaryPage.class.getName() + ","
					+ "Add a new line link for family talk clicked");
		} catch (NoSuchElementException e) {
			e.printStackTrace();
			Log.info("Failed" + SummaryPage.class.getName() + webElementName
					+ " not found ");
		}
		
	}

	/*
	 * Method: public void clickNewFamilyTalk() Description : To select Click on Start a new FamilyTlk plan. Parameter : None
	 * Return type : Void
	 */
	public void clickNewFamilyTalk() {
		webElementName = "radioNewFT";
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(radioNewFT));
		try {
			if (radioNewFT.isSelected()) {
				Log.info("Passed" + SummaryPage.class.getName() + ","
						+ "Start a new Family Talk option is pre selected");
			} else {
				radioNewFT.click();
				Log.info("Passed" + SummaryPage.class.getName() + ","
						+ "Start a new Family Talk option selected");
			}
		} catch (NoSuchElementException e) {
			e.printStackTrace();
			Log.info("Failed" + SummaryPage.class.getName() + webElementName
					+ " not found ");
		}
	}
	
	/*
	 * Method: clickAddLineFt Description : To click on Add a Line button for FamilyTalk activation.
	 * Parameter : None Return type : Void
	 */
	public void clickAddLineFt() {
		webElementName = "btnAddLine";
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(btnAddLine));
		try {
			btnAddLine.click();
			Log.info("Passed" + SummaryPage.class.getName() + ","
					+ "Add a Line for FamilyTalk clicked");
		} catch (NoSuchElementException e) {
			e.printStackTrace();
			Log.info("Failed" + SummaryPage.class.getName() + webElementName
					+ " not found ");
		}
	}		
	

}
