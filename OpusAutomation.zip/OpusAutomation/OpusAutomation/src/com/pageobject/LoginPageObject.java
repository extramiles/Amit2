package com.pageobject;

import java.util.NoSuchElementException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;



import com.utility.Logg;
import com.utility.Util;

public class LoginPageObject  {
	
	//public WebDriver driver;
	Util u = new Util();
	 WebDriver driver = u.getDriver();
	 org.apache.log4j.Logger l = Logg.createLogger();
	public LoginPageObject(WebDriver driver)
	{
		this.driver=driver;
		PageFactory.initElements(new AjaxElementLocatorFactory(driver, 20),this );
	}

	@FindBy(how=How.XPATH,using="//input[@name='userid' and @type='text']")
	private WebElement username;
	
	@FindBy(how=How.NAME,using="password")
	private WebElement password;
	
	@FindBy(how=How.NAME,using="btnSubmit")
	private WebElement btnSubmit;
	
	

	public WebElement enterUserName(String uname)
	{
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(username));
		if(username!=null){
			try
			{
				username.clear();
				l.info(" Passed" + LoginPageObject.class.getName()+ " clear username text box ");
				username.sendKeys(uname);
				l.info(" Passed" + LoginPageObject.class.getName() + "," + uname + " enter in textbox ");
			}
			catch(NoSuchElementException e)
			{
				e.printStackTrace();
				l.info(" Failed" + LoginPageObject.class.getName() + " unable to enter ");
			}
		}
		return btnSubmit;
	}
	public WebElement enterPassword(String pass)
	{
		if(password!=null)
		{
			try
			{
				password.clear();
				l.info(" Passed" + LoginPageObject.class.getName() + " clear pass text box ");
				password.sendKeys(pass);
				l.info(" Passed" + LoginPageObject.class.getName() + "," + pass + " enter in textbox ");
			}
			catch(NoSuchElementException e)
			{
				e.printStackTrace();
				l.info(" Failed" + LoginPageObject.class.getName() + " unable to enter  ");
			}
		}
		return btnSubmit;
	}

	public RemainedMeLaterPageObject click()
	{
		if(btnSubmit!=null)
		{
			btnSubmit.click();
			l.info(" Passed" + LoginPageObject.class.getName() + " button clicked ");
		}
		return new RemainedMeLaterPageObject(driver);
	}


}
