/* * ClassName : RatePlanPage
Description : This class identifies and implements all the web
elements and their corresponding actions of Rate Plan and Features page.
Version info : V_0.1
Date : 01/06/2017
Author : Tech Mahindra
Copyright notice : Tech Mahindra Ltd 
 */

package com.pageobject;

import java.util.Iterator;
import java.util.List;

import org.apache.log.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;

import com.utility.*;

public class RatePlanPage {
	Util u = new Util();
	//WebDriver driver;
	
	WebDriver driver = u.getDriver();
	org.apache.log4j.Logger Log = Logg.createLogger();	
	String webElementName;
	Select selectD;

	public RatePlanPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(new AjaxElementLocatorFactory(driver, 20),
				this);
	}
	
	@FindBy(how = How.XPATH, using = "//div/div[3]/div[2][contains(text(),'Select Plan & Features')]")
	public WebElement rateplanPageHeader;
	
	@FindBy(how = How.ID, using = "selectedSalesRep")
	// drop down
	private WebElement selectSalesRep;

	@FindBy(how = How.ID, using = "jumpToBottom")
	private WebElement btnJumpToBottom;

	@FindBy(how = How.CLASS_NAME, using = "newPlanTypeSelect")
	// drop down
	private WebElement selectPlanType;

	@FindBy(how = How.XPATH, using = "//div[@class='planSelection']/div[9]/div/label/div[2]/select[@class='newPlanSelect selectWidth100']")
	// //div[@class='planSelection']/div[9]/div/label/div[2]/select[@class='newPlanSelect selectWidth100']
	private WebElement selectPlanSelection;
	
	@FindBy(how = How.XPATH, using = "//div[@class='planSelection']/div[9]/div/label/div[1]/select[@class='newPlanSelect selectWidth100']")
	// //div[@class='planSelection']/div[9]/div/label/div[2]/select[@class='newPlanSelect selectWidth100']
	private WebElement selectPlanSelectionMobile;

	@FindBy(how = How.XPATH, using = "//div/input[@id='addPlan' and @type='button']")
	private WebElement btnAddPlan;

	@FindBy(how = How.ID, using = "radioFinancePlans")
	private WebElement radioFinancePlan;

	@FindBy(how = How.ID, using = "radioServiceContract")
	private WebElement radioServiceContract;

	@FindBy(how = How.XPATH, using = "//div[@id='divContractLength']/div[2]/label/select")
	// drop down for contract length
	private WebElement selectContractLength;

	@FindBy(how = How.ID, using = "radioNoCommit")
	private WebElement radioNoCommitment;

	@FindBy(how = How.ID, using = "assoFeaturesBtn")
	private WebElement btnAssFeaturesExpand;

	@FindBy(how = How.ID, using = "roadAsstAcceptCRS")
	private WebElement radioRadsideAss;

	@FindBy(how = How.ID, using = "roadAsstDecline")
	private WebElement radioRadsideAssDecline;

	@FindBy(how = How.ID, using = "continueNewActiBtn")
	private WebElement btnContinue;
	
	@FindBy(how = How.XPATH, using = "//div/div/div[@id='assoFeaturesBtn']")
	private WebElement FeaturesBtn;
	
	@FindBy(how = How.XPATH, using = "//div[@id='createNewPlanGroupDiv']/input[@id='newPlan']")
	private WebElement newGropuButton;
	/*
	 * Method: selectSalesRep Description : To Select desired sales
	 * representative id from given drop down. Parameter :
	 * 
	 * @setSalesRepName : Parameter to hold input value of sales rep id Return
	 * type : Void
	 */
	public void selectSalesRep(String setSalesRepId) {
		webElementName = "selectSalesRep"; // WebElement String
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(selectSalesRep));
		if (setSalesRepId != null) {
			try {
				selectD = new Select(selectSalesRep);
				selectD.selectByValue(setSalesRepId);
				Log.info("Passed" + RatePlanPage.class.getName() + ","
						+ setSalesRepId + " selected ");
			} catch (NoSuchElementException e) {
				e.printStackTrace();
				Log.info("Failed" + RatePlanPage.class.getName()
						+ webElementName + " not found ");
			}
		}
	}
	
	public void clickNewGroup() {
		webElementName = "newGropuButton"; // WebElement String
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(newGropuButton));
		if (newGropuButton != null) {
			try {
				newGropuButton.click();
				Log.info("Passed" + RatePlanPage.class.getName() + ","
						+ newGropuButton + " selected ");
			} catch (NoSuchElementException e) {
				e.printStackTrace();
				Log.info("Failed" + RatePlanPage.class.getName()
						+ webElementName + " not found ");
			}
		}
	}


	/*
	 * Method: clickJumToBtm Description : To click on Jump to Bottom button.
	 * Parameter : None Return type : Void
	 */
	public void clickJumToBtm() {
		webElementName = "btnJumpToBottom"; // WebElement String
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(btnJumpToBottom));
		try {
			btnJumpToBottom.click();
			Log.info("Passed" + RatePlanPage.class.getName() + ","
					+ "Jump to Bottom button clicked ");
		} catch (NoSuchElementException e) {
			e.printStackTrace();
			Log.info("Failed" + RatePlanPage.class.getName() + webElementName
					+ " not found ");
		}
	}

	/*
	 * Method: selecPlanType Description : To Select desired plan type from
	 * available plan types drop down. Parameter :
	 * 
	 * @setPlanType : Parameter to hold input value of plan type. Return type :
	 * Void Values: value= MS >Mobile Share option value= IN> Individual Plan
	 */
	public void selecPlanType(String setPlanType) {
		webElementName = "selectPlanType";
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(selectPlanType));
		if (setPlanType != null) {
			try {
				/*selectD = new Select(selectPlanType);
				selectD.selectByValue(setPlanType);*/
				Actions ac= new Actions(driver);
				ac.click(selectPlanType).sendKeys(setPlanType).click().build().perform();
				/*selectPlanType.click();
				selectPlanType.sendKeys(setPlanType).;*/
				Log.info("Passed" + RatePlanPage.class.getName() + ","
						+ setPlanType + " selected ");
			} catch (NoSuchElementException e) {
				e.printStackTrace();
				Log.info("Failed" + RatePlanPage.class.getName()
						+ webElementName + " not found");
			}
		}
	}

	/*
	 * Method: seletcPlan Description : To Select desired plan from available
	 * plans drop down. Parameter :
	 * 
	 * @setPlan : Parameter to hold input value of plan. Return type : Void
	 * Values: value= CN1NM0A80> NTN450RUMM5KNW - $39.99/mo Individual Plan
	 * value= SDGN3> Mobile Share Advantage 3GB $40 - $40.00/mo Mobile Share
	 * Plan
	 */
	public void selectPlanMobile(String setPlan) {
		webElementName = "selectPlanSelectionMobile";
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(selectPlanSelectionMobile));
		if (setPlan != null) {
			try {
				selectPlanSelectionMobile.click();
				selectPlanSelectionMobile.sendKeys(setPlan);
				selectPlanSelectionMobile.sendKeys(Keys.ENTER);
				/*Actions ac= new Actions(driver);
				ac.click(selectPlanSelectionMobile).sendKeys(setPlan).click().build().perform();*/
				/*Actions ac = new Actions(driver);
				selectD = new Select(selectPlanSelection);
			List<WebElement> plans = 	selectD.getOptions();
			
			Iterator<WebElement> ele = plans.iterator();
			while(ele.hasNext()){
				String s = ele.next().getText();
				if(s.equalsIgnoreCase(setPlan)){
					System.out.println(s);
					ac.keyDown(ele.next(), Keys.ARROW_DOWN).sendKeys(Keys.ENTER).build().perform();
				//	ac.moveToElement(ele.next()).click(ele.next()).build().perform();
					//selectD.selectByVisibleText(setPlan);
									//	ele.next().click();
					//selectD.selectByVisibleText(setPlan);
					break;
				}
							
			}*/
				//selectD.selectByValue(setPlan);
				/*Actions ac= new Actions(driver);
				ac.click(selectPlanSelection).moveToElement(toElement)
				sendKeys(setPlan).click().build().perform();*/
				/*selectPlanSelection.click();
				selectPlanSelection.sendKeys(setPlan);*/
				
				/*String nameYouWant = setPlan;
				WebElement select = selectPlanSelection;
				WebElement option =select.findElement(By.xpath("//option[contains(text(),'" + nameYouWant + "')]"));
				u.waits(2000);
				option.click();*/
				/*or

				WebElement option =
				select.findElement(By.xpath("//option[text()='" + nameYouWant + "']"));*/
				Log.info("Passed" + RatePlanPage.class.getName() + ","
						+ setPlan + " selected ");
			} catch (NoSuchElementException e) {
				e.printStackTrace();
				Log.info("Failed" + RatePlanPage.class.getName()
						+ webElementName + " not found");
			}
		}
	}

	public void selectPlanInd(String setPlan) {
		webElementName = "selectPlanSelection";
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(selectPlanSelection));
		if (setPlan != null) {
			try {
				selectPlanSelection.click();
				selectPlanSelection.sendKeys(setPlan);
				selectPlanSelection.sendKeys(Keys.ENTER);
				/*Actions ac= new Actions(driver);
				ac.click(selectPlanType).sendKeys(setPlan).click().build().perform();*/
				/*Actions ac = new Actions(driver);
				selectD = new Select(selectPlanSelection);
			List<WebElement> plans = 	selectD.getOptions();
			
			Iterator<WebElement> ele = plans.iterator();
			while(ele.hasNext()){
				String s = ele.next().getText();
				if(s.equalsIgnoreCase(setPlan)){
					System.out.println(s);
					ac.keyDown(ele.next(), Keys.ARROW_DOWN).sendKeys(Keys.ENTER).build().perform();
				//	ac.moveToElement(ele.next()).click(ele.next()).build().perform();
					//selectD.selectByVisibleText(setPlan);
									//	ele.next().click();
					//selectD.selectByVisibleText(setPlan);
					break;
				}
							
			}*/
				//selectD.selectByValue(setPlan);
				/*Actions ac= new Actions(driver);
				ac.click(selectPlanSelection).moveToElement(toElement)
				sendKeys(setPlan).click().build().perform();*/
				/*selectPlanSelection.click();
				selectPlanSelection.sendKeys(setPlan);*/
				
				/*String nameYouWant = setPlan;
				WebElement select = selectPlanSelection;
				WebElement option =select.findElement(By.xpath("//option[contains(text(),'" + nameYouWant + "')]"));
				u.waits(2000);
				option.click();*/
				/*or

				WebElement option =
				select.findElement(By.xpath("//option[text()='" + nameYouWant + "']"));*/
				Log.info("Passed" + RatePlanPage.class.getName() + ","
						+ setPlan + " selected ");
			} catch (NoSuchElementException e) {
				e.printStackTrace();
				Log.info("Failed" + RatePlanPage.class.getName()
						+ webElementName + " not found");
			}
		}
	}
	/*
	 * Method: clickAddPlan Description : To click on Add/Update Plan button.
	 * Parameter : None Return type : Void
	 */
	public void clickAddPlan() {
		webElementName = "btnAddPlan";
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(btnAddPlan));
		try {
			btnAddPlan.click();
			Log.info("Passed" + RatePlanPage.class.getName() + ","
					+ "Add Plan button clicked");
		} catch (NoSuchElementException e) {
			e.printStackTrace();
			Log.info("Failed" + RatePlanPage.class.getName() + webElementName
					+ " not found ");
		}
	}

	/*
	 * Method: public void clickFinancePlans() Description : To click on Finance
	 * Plan radio button. Parameter : None Return type : Void
	 */
	public void clickFinancePlans() {
		webElementName = "radioFinancePlan";
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(radioFinancePlan));
		try {
			radioFinancePlan.click();
			Log.info("Passed" + RatePlanPage.class.getName() + ","
					+ "Finance Plan radio button clicked");
		} catch (NoSuchElementException e) {
			e.printStackTrace();
			Log.info("Failed" + RatePlanPage.class.getName() + webElementName
					+ " not found ");
		}
	}

	/*
	 * Method: public void clickFinancePlans() Description : To click on Service
	 * Contract radio button. Parameter : None Return type : Void
	 */
	public void clickServiceContractPlans() {
		webElementName = "radioServiceContract";
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(FeaturesBtn));
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(radioServiceContract));
		try {
			radioServiceContract.click();
			Log.info("Passed" + RatePlanPage.class.getName() + ","
					+ "Service contract radio button clicked");
		} catch (NoSuchElementException e) {
			e.printStackTrace();
			Log.info("Failed" + RatePlanPage.class.getName() + webElementName
					+ " not found ");
		}
	}

	/*
	 * Method: selectContratcLengthFor Description : To Select desired Contract
	 * term from available contract length drop down. Parameter :
	 * 
	 * @setPlan : Parameter to hold input value of plan. Return type : Void
	 * Values: value= 12> 12 MONTHS COMMITMENT value= 24> 24 MONTHS COMMITMENT
	 */
	public void selectContratcLength(String setContractLength) {
		webElementName = "selectContractLength";
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(selectContractLength));
		if (setContractLength != null) {
			try {
				/*selectD = new Select(selectContractLength);
				selectD.selectByValue(setContractLength);*/
				//u.waits(45000);
				selectContractLength.click();
				selectContractLength.sendKeys(setContractLength);
				selectContractLength.sendKeys(Keys.ENTER);
				Log.info("Passed" + RatePlanPage.class.getName() + ","
						+ setContractLength + " selected ");
			} catch (NoSuchElementException e) {
				e.printStackTrace();
				Log.info("Failed" + RatePlanPage.class.getName()
						+ webElementName + " not found");
			}
		}
	}

	/*
	 * Method: public void clickNoCommitmentPlan() Description : To click on No
	 * Commitment radio button. Parameter : None Return type : Void
	 */
	public void clickNoCommitmentPlan() {
		webElementName = "radioNoCommitment";
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(FeaturesBtn));
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(radioNoCommitment));
		try {
			radioNoCommitment.click();
			Log.info("Passed" + RatePlanPage.class.getName() + ","
					+ "No Commitment radio button clicked");
		} catch (NoSuchElementException e) {
			e.printStackTrace();
			Log.info("Failed" + RatePlanPage.class.getName() + webElementName
					+ " not found ");
		}
	}

	/*
	 * Method: public void clickAssFeaturesExpandBtn() Description : To click on
	 * Associated Features Expand button. Parameter : None Return type : Void
	 */
	public void clickAssFeaturesExpandBtn() {
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(btnAssFeaturesExpand));
		webElementName = "btnAssFeaturesExpand";
		try {
			btnAssFeaturesExpand.click();
			Log.info("Passed" + RatePlanPage.class.getName() + ","
					+ "Associated Features expand button clicked");
		} catch (NoSuchElementException e) {
			e.printStackTrace();
			Log.info("Failed" + RatePlanPage.class.getName() + webElementName
					+ " not found ");
		}
	}

	/*
	 * Method: public void clickRoadsideAss() Description : To click on Roadside
	 * Assistance Radio button. Parameter : None Return type : Void
	 */
	public void clickRoadsideAss() {
		webElementName = "radioRadsideAss";
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(radioRadsideAss));
		try {
			radioRadsideAss.click();
			Log.info("Passed" + RatePlanPage.class.getName() + ","
					+ "Roadside Assistance selected");
		} catch (NoSuchElementException e) {
			e.printStackTrace();
			Log.info("Failed" + RatePlanPage.class.getName() + webElementName
					+ " not found ");
		}
	}

	/*
	 * Method: public void clickRoadsideAss() Description : To click on Roadside
	 * Assistance Radio button. Parameter : None Return type : Void
	 */
	public void clickRoadsideAssDecline() {
		webElementName = "radioRadsideAssDecline";
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(radioRadsideAssDecline));
		try {
			radioRadsideAssDecline.click();
			Log.info("Passed" + RatePlanPage.class.getName() + ","
					+ "Roadside Assistance Decline option clicked");
		} catch (NoSuchElementException e) {
			e.printStackTrace();
			Log.info("Failed" + RatePlanPage.class.getName() + webElementName
					+ " not found ");
		}
	}

	/*
	 * Method: public void clickContinueBtn() Description : To click on Continue
	 * button. Parameter : None Return type : Void
	 */
	public DeviceProEnrollPage clickContinueBtn() {
		webElementName = "btnContinue";
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(btnContinue));
		try {
			btnContinue.click();
			Log.info("Passed" + RatePlanPage.class.getName() + ","
					+ "Continue button clicked");
		} catch (NoSuchElementException e) {
			e.printStackTrace();
			Log.info("Failed" + RatePlanPage.class.getName() + webElementName
					+ " not found ");
		}
		return new DeviceProEnrollPage(driver);
	}

}
