/*
Description : This class identify and implement all the web
element and its corresponding action of Shipment Information page
Version info : V_0.1
Date : 08/06/2017
Author : Devendra Bhavsar
Copyright notice : Tech Mahindra Ltd
 */
package com.pageobject;

import java.util.NoSuchElementException;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;
import org.openqa.selenium.support.ui.Select;


import com.utility.Logg;
import com.utility.Util;

public class ShipmentInfoPage {
Util u = new Util();
	
	WebDriver driver = u.getDriver();
	 Logger Log = Logg.createLogger();
	public ShipmentInfoPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(new AjaxElementLocatorFactory(driver,20),this);
	}
		
	
/*-------------------------------------------------------- Page objects ---------------------------------------------------- */
	
	@FindBy(how = How.NAME, using = "firstName")
	private WebElement textFirstName;
	
	@FindBy(how = How.NAME, using = "lastName")
	private WebElement textLastName;
	
	@FindBy(how = How.NAME, using = "businessName")
	private WebElement textBusinessName;
	
	@FindBy(how = How.NAME, using = "homePhone.npa")
	private WebElement textHPNpa;
	
	@FindBy(how = How.NAME, using = "homePhone.nxx")
	private WebElement textHPNxx;
	
	@FindBy(how = How.NAME, using = "homePhone.line")
	private WebElement textHPLine;
	
	@FindBy(how = How.NAME, using = "workPhone.npa")
	private WebElement textWPNpa;
	
	@FindBy(how = How.NAME, using = "workPhone.nxx")
	private WebElement textWPNxx;
	
	@FindBy(how = How.NAME, using = "workPhone.line")
	private WebElement textWPLine;
	
	@FindBy(how = How.NAME, using = "mobilePhone.npa")
	private WebElement textMobNpa;
	
	@FindBy(how = How.NAME, using = "mobilePhone.nxx")
	private WebElement textMobNxx;
	
	@FindBy(how = How.NAME, using = "mobilePhone.line")
	private WebElement textMobLine;
	
	@FindBy(how = How.NAME, using = "email")
	private WebElement textEmailAdd;
	
	@FindBy(how = How.ID, using = "addressSelect_1")
	private WebElement radioCustAdd;
	
	@FindBy(how = How.ID, using = "addressSelect_2")
	private WebElement radioStoreAdd;
	
	@FindBy(how = How.ID, using = "addressSelect_3")
	private WebElement radioOtherAdd;
	
	@FindBy(how = How.ID, using = "zipcodeForAutoComplete")
	private WebElement textZip;
	
	@FindBy(how = How.NAME, using = "attention")
	private WebElement textAttention;
	
	@FindBy(how = How.NAME, using = "addressLn1")
	private WebElement textAddLineOne;
	
	@FindBy(how = How.NAME, using = "city")
	private WebElement textCity;
	
	@FindBy(how = How.NAME, using = "state")
	private WebElement selectState;
	
	@FindBy(how = How.NAME, using = "shippingMethod")
	private WebElement selectShipMethod;
	
	@FindBy(how = How.NAME, using = "waiveShippingFees")
	private WebElement chkboxWaiveShip;
	
	@FindBy(how = How.ID, using = "")
	private WebElement btnCancel;
	
	@FindBy(how = How.ID, using = "")
	private WebElement btnSubmit;
	

	
	
	
	
	
	
	
	
	
	
	/*-------------------------------------------------------- Page actions ---------------------------------------------------- */
	
	/*Method: setTextFirstName
	 Description : To set the value of input(text) textFirstName.
	 Parameter : @value - First Name of the user
	 Return type : WebElement */
	
	public WebElement setTextFirstName(String value)
	{
		WebElement wePh = textFirstName; // WebElement object 
		String webElementName = "textFirstName"; // WebElement object name string
		if(value!=null){
			try
			{
				wePh.clear();
				Log.info("Passed : "+ ServiceDevicePage.class.getName() + "- Textbox : " + webElementName + " is cleared.");
				wePh.sendKeys(value);
				Log.info("Passed : "+ ServiceDevicePage.class.getName() + "- Textbox : " + webElementName + " is set to " + value + ".");
			}
			catch(NoSuchElementException e)
			{
				e.printStackTrace();
				Log.info("Failed :" + ServiceDevicePage.class.getName() + "- Textbox : " + webElementName + " not found.");
			}
		}
		return wePh;
	}
	
	/*Method: setTextLastName
	 Description : To set the value of input(text) textLastName.
	 Parameter : @value - 
	 Return type : WebElement */
	
	public WebElement setTextLastName(String value)
	{
		WebElement wePh = textLastName; // WebElement object 
		String webElementName = "textLastName"; // WebElement object name string
		if(value!=null){
			try
			{
				wePh.clear();
				Log.info("Passed : "+ ServiceDevicePage.class.getName() + "- Textbox : " + webElementName + " is cleared.");
				wePh.sendKeys(value);
				Log.info("Passed : "+ ServiceDevicePage.class.getName() + "- Textbox : " + webElementName + " is set to " + value + ".");
			}
			catch(NoSuchElementException e)
			{
				e.printStackTrace();
				Log.info("Failed :" + ServiceDevicePage.class.getName() + "- Textbox : " + webElementName + " not found.");
			}
		}
		return wePh;
	}
	
	/*Method: setTextBusinessName
	 Description : To set the value of input(text) textBusinessName.
	 Parameter : @value - 
	 Return type : WebElement */
	
	public WebElement setTextBusinessName(String value)
	{
		WebElement wePh = textBusinessName; // WebElement object 
		String webElementName = "textBusinessName"; // WebElement object name string
		if(value!=null){
			try
			{
				wePh.clear();
				Log.info("Passed : "+ ServiceDevicePage.class.getName() + "- Textbox : " + webElementName + " is cleared.");
				wePh.sendKeys(value);
				Log.info("Passed : "+ ServiceDevicePage.class.getName() + "- Textbox : " + webElementName + " is set to " + value + ".");
			}
			catch(NoSuchElementException e)
			{
				e.printStackTrace();
				Log.info("Failed :" + ServiceDevicePage.class.getName() + "- Textbox : " + webElementName + " not found.");
			}
		}
		return wePh;
	}
	
	/*Method: setTextHPNpa
	 Description : To set the value of input(text) textHPNpa.
	 Parameter : @value - 
	 Return type : WebElement */
	
	public WebElement setTextHPNpa(String value)
	{
		WebElement wePh = textHPNpa; // WebElement object 
		String webElementName = "textHPNpa"; // WebElement object name string
		if(value!=null){
			try
			{
				wePh.clear();
				Log.info("Passed : "+ ServiceDevicePage.class.getName() + "- Textbox : " + webElementName + " is cleared.");
				wePh.sendKeys(value);
				Log.info("Passed : "+ ServiceDevicePage.class.getName() + "- Textbox : " + webElementName + " is set to " + value + ".");
			}
			catch(NoSuchElementException e)
			{
				e.printStackTrace();
				Log.info("Failed :" + ServiceDevicePage.class.getName() + "- Textbox : " + webElementName + " not found.");
			}
		}
		return wePh;
	}
	
	/*Method: setTextHPNxx
	 Description : To set the value of input(text) textHPNxx.
	 Parameter : @value - 
	 Return type : WebElement */
	
	public WebElement setTextHPNxx(String value)
	{
		WebElement wePh = textHPNxx; // WebElement object 
		String webElementName = "textHPNxx"; // WebElement object name string
		if(value!=null){
			try
			{
				wePh.clear();
				Log.info("Passed : "+ ServiceDevicePage.class.getName() + "- Textbox : " + webElementName + " is cleared.");
				wePh.sendKeys(value);
				Log.info("Passed : "+ ServiceDevicePage.class.getName() + "- Textbox : " + webElementName + " is set to " + value + ".");
			}
			catch(NoSuchElementException e)
			{
				e.printStackTrace();
				Log.info("Failed :" + ServiceDevicePage.class.getName() + "- Textbox : " + webElementName + " not found.");
			}
		}
		return wePh;
	}
	
	/*Method: setTextHPLine
	 Description : To set the value of input(text) textHPLine.
	 Parameter : @value - 
	 Return type : WebElement */
	
	public WebElement setTextHPLine(String value)
	{
		WebElement wePh = textHPLine; // WebElement object 
		String webElementName = "textHPLine"; // WebElement object name string
		if(value!=null){
			try
			{
				wePh.clear();
				Log.info("Passed : "+ ServiceDevicePage.class.getName() + "- Textbox : " + webElementName + " is cleared.");
				wePh.sendKeys(value);
				Log.info("Passed : "+ ServiceDevicePage.class.getName() + "- Textbox : " + webElementName + " is set to " + value + ".");
			}
			catch(NoSuchElementException e)
			{
				e.printStackTrace();
				Log.info("Failed :" + ServiceDevicePage.class.getName() + "- Textbox : " + webElementName + " not found.");
			}
		}
		return wePh;
	}
	
	/*Method: setTextWPNpa
	 Description : To set the value of input(text) textWPNpa.
	 Parameter : @value - 
	 Return type : WebElement */
	
	public WebElement setTextWPNpa(String value)
	{
		WebElement wePh = textWPNpa; // WebElement object 
		String webElementName = "textWPNpa"; // WebElement object name string
		if(value!=null){
			try
			{
				wePh.clear();
				Log.info("Passed : "+ ServiceDevicePage.class.getName() + "- Textbox : " + webElementName + " is cleared.");
				wePh.sendKeys(value);
				Log.info("Passed : "+ ServiceDevicePage.class.getName() + "- Textbox : " + webElementName + " is set to " + value + ".");
			}
			catch(NoSuchElementException e)
			{
				e.printStackTrace();
				Log.info("Failed :" + ServiceDevicePage.class.getName() + "- Textbox : " + webElementName + " not found.");
			}
		}
		return wePh;
	}
	
	/*Method: setTextWPNxx
	 Description : To set the value of input(text) textWPNxx.
	 Parameter : @value - 
	 Return type : WebElement */
	
	public WebElement setTextWPNxx(String value)
	{
		WebElement wePh = textWPNxx; // WebElement object 
		String webElementName = "textWPNxx"; // WebElement object name string
		if(value!=null){
			try
			{
				wePh.clear();
				Log.info("Passed : "+ ServiceDevicePage.class.getName() + "- Textbox : " + webElementName + " is cleared.");
				wePh.sendKeys(value);
				Log.info("Passed : "+ ServiceDevicePage.class.getName() + "- Textbox : " + webElementName + " is set to " + value + ".");
			}
			catch(NoSuchElementException e)
			{
				e.printStackTrace();
				Log.info("Failed :" + ServiceDevicePage.class.getName() + "- Textbox : " + webElementName + " not found.");
			}
		}
		return wePh;
	}
	
	/*Method: setTextWPLine
	 Description : To set the value of input(text) textWPLine.
	 Parameter : @value - 
	 Return type : WebElement */
	
	public WebElement setTextWPLine(String value)
	{
		WebElement wePh = textWPLine; // WebElement object 
		String webElementName = "textWPLine"; // WebElement object name string
		if(value!=null){
			try
			{
				wePh.clear();
				Log.info("Passed : "+ ServiceDevicePage.class.getName() + "- Textbox : " + webElementName + " is cleared.");
				wePh.sendKeys(value);
				Log.info("Passed : "+ ServiceDevicePage.class.getName() + "- Textbox : " + webElementName + " is set to " + value + ".");
			}
			catch(NoSuchElementException e)
			{
				e.printStackTrace();
				Log.info("Failed :" + ServiceDevicePage.class.getName() + "- Textbox : " + webElementName + " not found.");
			}
		}
		return wePh;
	}
	
	/*Method: setTextMobNpa
	 Description : To set the value of input(text) textMobNpa.
	 Parameter : @value - 
	 Return type : WebElement */
	
	public WebElement setTextMobNpa(String value)
	{
		WebElement wePh = textMobNpa; // WebElement object 
		String webElementName = "textMobNpa"; // WebElement object name string
		if(value!=null){
			try
			{
				wePh.clear();
				Log.info("Passed : "+ ServiceDevicePage.class.getName() + "- Textbox : " + webElementName + " is cleared.");
				wePh.sendKeys(value);
				Log.info("Passed : "+ ServiceDevicePage.class.getName() + "- Textbox : " + webElementName + " is set to " + value + ".");
			}
			catch(NoSuchElementException e)
			{
				e.printStackTrace();
				Log.info("Failed :" + ServiceDevicePage.class.getName() + "- Textbox : " + webElementName + " not found.");
			}
		}
		return wePh;
	}
	
	/*Method: setTextMobNxx
	 Description : To set the value of input(text) textMobNxx.
	 Parameter : @value - 
	 Return type : WebElement */
	
	public WebElement setTextMobNxx(String value)
	{
		WebElement wePh = textMobNxx; // WebElement object 
		String webElementName = "textMobNxx"; // WebElement object name string
		if(value!=null){
			try
			{
				wePh.clear();
				Log.info("Passed : "+ ServiceDevicePage.class.getName() + "- Textbox : " + webElementName + " is cleared.");
				wePh.sendKeys(value);
				Log.info("Passed : "+ ServiceDevicePage.class.getName() + "- Textbox : " + webElementName + " is set to " + value + ".");
			}
			catch(NoSuchElementException e)
			{
				e.printStackTrace();
				Log.info("Failed :" + ServiceDevicePage.class.getName() + "- Textbox : " + webElementName + " not found.");
			}
		}
		return wePh;
	}
	
	/*Method: setTextMobLine
	 Description : To set the value of input(text) textMobLine.
	 Parameter : @value - 
	 Return type : WebElement */
	
	public WebElement setTextMobLine(String value)
	{
		WebElement wePh = textMobLine; // WebElement object 
		String webElementName = "textMobLine"; // WebElement object name string
		if(value!=null){
			try
			{
				wePh.clear();
				Log.info("Passed : "+ ServiceDevicePage.class.getName() + "- Textbox : " + webElementName + " is cleared.");
				wePh.sendKeys(value);
				Log.info("Passed : "+ ServiceDevicePage.class.getName() + "- Textbox : " + webElementName + " is set to " + value + ".");
			}
			catch(NoSuchElementException e)
			{
				e.printStackTrace();
				Log.info("Failed :" + ServiceDevicePage.class.getName() + "- Textbox : " + webElementName + " not found.");
			}
		}
		return wePh;
	}
	
	/*Method: setTextEmailAdd
	 Description : To set the value of input(text) textEmailAdd.
	 Parameter : @value - 
	 Return type : WebElement */
	
	public WebElement setTextEmailAdd(String value)
	{
		WebElement wePh = textEmailAdd; // WebElement object 
		String webElementName = "textEmailAdd"; // WebElement object name string
		if(value!=null){
			try
			{
				wePh.clear();
				Log.info("Passed : "+ ServiceDevicePage.class.getName() + "- Textbox : " + webElementName + " is cleared.");
				wePh.sendKeys(value);
				Log.info("Passed : "+ ServiceDevicePage.class.getName() + "- Textbox : " + webElementName + " is set to " + value + ".");
			}
			catch(NoSuchElementException e)
			{
				e.printStackTrace();
				Log.info("Failed :" + ServiceDevicePage.class.getName() + "- Textbox : " + webElementName + " not found.");
			}
		}
		return wePh;
	}
	
	/*Method: setRadioCustAdd
	 Description : To set the value of input(radio) radioCustAdd.
	 Parameter : None
	 Return type : WebElement */
	public WebElement setRadioCustAdd(){
		WebElement wePh = radioCustAdd; // WebElement object
		String webElementName = "radioCustAdd"; // WebElement object name string
		if(wePh.isEnabled()){ 
			try {
				wePh.click();
				Log.info("Passed : "+ ServiceDevicePage.class.getName() + "- Radio button : " + webElementName + " is set.");
			} catch(NoSuchElementException e) {
				e.printStackTrace();
				Log.info("Failed :" + ServiceDevicePage.class.getName() + "- Radio button : " + webElementName + " not found.");
			}
		}
		else{
			Log.info("Failed :" + ServiceDevicePage.class.getName() + "- Radio button : " + webElementName + " is disabled.");
		}
		return wePh;
	}
	
	/*Method: setRadioStoreAdd
	 Description : To set the value of input(radio) radioStoreAdd.
	 Parameter : None
	 Return type : WebElement */
	public WebElement setRadioStoreAdd(){
		WebElement wePh = radioStoreAdd; // WebElement object
		String webElementName = "radioStoreAdd"; // WebElement object name string
		if(wePh.isEnabled()){ 
			try {
				wePh.click();
				Log.info("Passed : "+ ServiceDevicePage.class.getName() + "- Radio button : " + webElementName + " is set.");
			} catch(NoSuchElementException e) {
				e.printStackTrace();
				Log.info("Failed :" + ServiceDevicePage.class.getName() + "- Radio button : " + webElementName + " not found.");
			}
		}
		else{
			Log.info("Failed :" + ServiceDevicePage.class.getName() + "- Radio button : " + webElementName + " is disabled.");
		}
		return wePh;
	}
	
	/*Method: setRadioOtherAdd
	 Description : To set the value of input(radio) radioOtherAdd.
	 Parameter : None
	 Return type : WebElement */
	public WebElement setRadioOtherAdd(){
		WebElement wePh = radioOtherAdd; // WebElement object
		String webElementName = "radioOtherAdd"; // WebElement object name string
		if(wePh.isEnabled()){ 
			try {
				wePh.click();
				Log.info("Passed : "+ ServiceDevicePage.class.getName() + "- Radio button : " + webElementName + " is set.");
			} catch(NoSuchElementException e) {
				e.printStackTrace();
				Log.info("Failed :" + ServiceDevicePage.class.getName() + "- Radio button : " + webElementName + " not found.");
			}
		}
		else{
			Log.info("Failed :" + ServiceDevicePage.class.getName() + "- Radio button : " + webElementName + " is disabled.");
		}
		return wePh;
	}
	
	/*Method: setTextZip
	 Description : To set the value of input(text) textZip.
	 Parameter : @value - Preset
	 Return type : WebElement */
	
	public WebElement setTextZip(String value)
	{
		WebElement wePh = textZip; // WebElement object 
		String webElementName = "textZip"; // WebElement object name string
		if(value!=null){
			try
			{
				wePh.clear();
				Log.info("Passed : "+ ServiceDevicePage.class.getName() + "- Textbox : " + webElementName + " is cleared.");
				wePh.sendKeys(value);
				Log.info("Passed : "+ ServiceDevicePage.class.getName() + "- Textbox : " + webElementName + " is set to " + value + ".");
			}
			catch(NoSuchElementException e)
			{
				e.printStackTrace();
				Log.info("Failed :" + ServiceDevicePage.class.getName() + "- Textbox : " + webElementName + " not found.");
			}
		}
		return wePh;
	}
	
	/*Method: setTextAttention
	 Description : To set the value of input(text) textAttention.
	 Parameter : @value - 
	 Return type : WebElement */
	
	public WebElement setTextAttention(String value)
	{
		WebElement wePh = textAttention; // WebElement object 
		String webElementName = "textAttention"; // WebElement object name string
		if(value!=null){
			try
			{
				wePh.clear();
				Log.info("Passed : "+ ServiceDevicePage.class.getName() + "- Textbox : " + webElementName + " is cleared.");
				wePh.sendKeys(value);
				Log.info("Passed : "+ ServiceDevicePage.class.getName() + "- Textbox : " + webElementName + " is set to " + value + ".");
			}
			catch(NoSuchElementException e)
			{
				e.printStackTrace();
				Log.info("Failed :" + ServiceDevicePage.class.getName() + "- Textbox : " + webElementName + " not found.");
			}
		}
		return wePh;
	}
	
	/*Method: setTextAddLineOne
	 Description : To set the value of input(text) textAddLineOne.
	 Parameter : @value - 
	 Return type : WebElement */
	
	public WebElement setTextAddLineOne(String value)
	{
		WebElement wePh = textAddLineOne; // WebElement object 
		String webElementName = "textAddLineOne"; // WebElement object name string
		if(value!=null){
			try
			{
				wePh.clear();
				Log.info("Passed : "+ ServiceDevicePage.class.getName() + "- Textbox : " + webElementName + " is cleared.");
				wePh.sendKeys(value);
				Log.info("Passed : "+ ServiceDevicePage.class.getName() + "- Textbox : " + webElementName + " is set to " + value + ".");
			}
			catch(NoSuchElementException e)
			{
				e.printStackTrace();
				Log.info("Failed :" + ServiceDevicePage.class.getName() + "- Textbox : " + webElementName + " not found.");
			}
		}
		return wePh;
	}
	
	/*Method: setTextCity
	 Description : To set the value of input(text) textCity.
	 Parameter : @value - 
	 Return type : WebElement */
	
	public WebElement setTextCity(String value)
	{
		WebElement wePh = textCity; // WebElement object 
		String webElementName = "textCity"; // WebElement object name string
		if(value!=null){
			try
			{
				wePh.clear();
				Log.info("Passed : "+ ServiceDevicePage.class.getName() + "- Textbox : " + webElementName + " is cleared.");
				wePh.sendKeys(value);
				Log.info("Passed : "+ ServiceDevicePage.class.getName() + "- Textbox : " + webElementName + " is set to " + value + ".");
			}
			catch(NoSuchElementException e)
			{
				e.printStackTrace();
				Log.info("Failed :" + ServiceDevicePage.class.getName() + "- Textbox : " + webElementName + " not found.");
			}
		}
		return wePh;
	}
	
	/*Method: setSelectState
	Description : To select the value of Select selectState.
	Parameter : @value -  
	Return type : WebElement */
	public WebElement setSelectState(String value)
	{ 
		WebElement wePh = selectState; // WebElement object
		String webElementName = "selectState"; // WebElement object name string
		if (value!=null) {
			try {
				 Select selectWE = new Select(wePh);
				 selectWE.selectByValue(value);
				 Log.info("Passed : "+ ServiceDevicePage.class.getName() + "- Select : " + webElementName + " is set to " + value + ".");
			} catch(NoSuchElementException e) {
				e.printStackTrace();
				Log.info("Failed :" + ServiceDevicePage.class.getName() + "- Select : " + webElementName + " not found.");
			}
		}
		return wePh;
	}
	
	
	/*Method: setSelectShipMethod
	Description : To select the value of Select selectShipMethod.
	Parameter : @value - 'ECONOMY $0.00' 
	Return type : WebElement */
	public WebElement setSelectShipMethod(String value)
	{ 
		WebElement wePh = selectShipMethod; // WebElement object
		String webElementName = "selectShipMethod"; // WebElement object name string
		if (value!=null) {
			try {
				 Select selectWE = new Select(wePh);
				 selectWE.selectByValue(value);
				 Log.info("Passed : "+ ServiceDevicePage.class.getName() + "- Select : " + webElementName + " is set to " + value + ".");
			} catch(NoSuchElementException e) {
				e.printStackTrace();
				Log.info("Failed :" + ServiceDevicePage.class.getName() + "- Select : " + webElementName + " not found.");
			}
		}
		return wePh;
	}
	
	/*Method: setChkboxWaiveShip
	 Description : To set the value of input(check box) chkboxWaiveShip.
	 Parameter : None
	 Return type : WebElement */
	public WebElement setChkboxWaiveShip(){
		WebElement wePh = chkboxWaiveShip; // WebElement object
				String webElementName = "chkboxWaiveShip"; // WebElement object name string
		if(wePh.isEnabled()){
			try {
				wePh.click();
				Log.info("Passed : "+ ServiceDevicePage.class.getName() + "- CheckBox : " + webElementName + " is checked.");
			} catch(NoSuchElementException e) {
				e.printStackTrace();
				Log.info("Failed :" + ServiceDevicePage.class.getName() + "- CheckBox : " + webElementName + " not found.");
			}
		}
		else{
			Log.info("Failed :" + ServiceDevicePage.class.getName() + "- CheckBox : " + webElementName + " is disabled.");
		}
		return wePh;
	}
	
	/*Method: clickBtnCancel
	Description : To click on  button btnCancel.
	Parameter : None
	Return type : void */
	public void clickBtnCancel()
	{
		WebElement wePh = btnCancel; // WebElement object 
		String webElementName = "btnCancel"; // WebElement object name string
		try {
			wePh.click();
			Log.info("Passed : "+ ServiceDevicePage.class.getName() + "- Button : " + webElementName + " is clicked.");
			} catch(NoSuchElementException e) {
			e.printStackTrace();
			Log.info("Failed :" + ServiceDevicePage.class.getName() + "- Button : " + webElementName + " not found.");
			}
	}
	
	/*Method: clickBtnSubmit
	Description : To click on  button btnSubmit.
	Parameter : None
	Return type : void */
	public void clickBtnSubmit()
	{
		WebElement wePh = btnSubmit; // WebElement object 
		String webElementName = "btnSubmit"; // WebElement object name string
		try {
			wePh.click();
			Log.info("Passed : "+ ServiceDevicePage.class.getName() + "- Button : " + webElementName + " is clicked.");
			} catch(NoSuchElementException e) {
			e.printStackTrace();
			Log.info("Failed :" + ServiceDevicePage.class.getName() + "- Button : " + webElementName + " not found.");
			}
	}
}
