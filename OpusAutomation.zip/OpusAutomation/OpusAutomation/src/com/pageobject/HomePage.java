 /* ClassName            : HomePage
  * Description          : This class identify and implement all the web
  *                        element and its corresponding action of Home Page.
  * Version info         : V_0.1
  * Author               : Tech Mahindra
  * Copyright notice     : Tech Mahindra Ltd. 
  */

package com.pageobject;

import java.util.NoSuchElementException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.testng.Reporter;

import com.opusbase.TestBase;
import com.pageobject.CommonPageAction;
import com.utility.Logg;
import com.utility.Util;

import  org.apache.log4j.*;

public class HomePage {
	Util u = new Util();
	
	WebDriver driver = u.getDriver();
	 Logger l = Logg.createLogger();
	public HomePage(WebDriver driver)
	{
		//super(driver);
		this.driver=driver;
		
		// TODO Auto-generated constructor stub
		PageFactory.initElements(driver,this);
	}
	/* WebElement locator for Existing customer */
	 //Home Page: Assist Customer Now
	// Web Element Locator for Wireless 
	@FindBy(how=How.XPATH,using="//div/div[2]/div[2][contains(text(),'Home Page: Assist Customer Now ')]")
	public WebElement homePageHeader;
	
	@FindBy(how=How.XPATH,using="//frame[@name='VISIFRAME']")
	private WebElement frameHomePage;
	
	@FindBy(how=How.XPATH,using="//span[@class='menuIcon home']")
	private WebElement homeClick;
	
	@FindBy(how=How.ID, using = "wirelinesearch_button")
	public WebElement eCustomerButton;
	
	@FindBy(how=How.ID, using = "wirelessRadio")
	public WebElement selectWirelessRadio;
	
	@FindBy(how=How.ID, using = "searchMarketSelection")
	public WebElement selectMarketSelection;
	
	@FindBy(how=How.ID,using="criterion")
	public WebElement setSearchFor;
	
	@FindBy(how=How.ID, using = "btnSubmitWireless")
	public WebElement searchButton;
	
	// Web Element Locator for Wire-line
	
	@FindBy(how=How.ID, using = "wirelineRadio")
	public WebElement selectWirelineRadio;
	
	@FindBy(how=How.ID, using = "wirelinedropdown") // Select tag value
	public WebElement selectWirelinedropDown;
	
	@FindBy(how=How.ID, using = "wirelineno") // Search By or Search for AT&T BAN 
	public WebElement setWirelineNumber;
	
	@FindBy(how=How.ID, using = "custCategory1WLN")
	public WebElement cTypeConsumer;
	
	@FindBy(how=How.ID, using = "custCategory2WLN")
	public WebElement cTypeBusiness;
	
	// Web Element locator for New customer
	
	@FindBy(how=How.ID, using = "addresssearch_button")  // New Customer : Service Availability Check 
	public WebElement newCustomerButton;
	
	@FindBy(how=How.ID, using = "addressType")   // Address type select tag
	public WebElement selectAddressType;
	
	@FindBy(how=How.XPATH,using="//input[@name='radio1' and @onclick='setCustomerType('consumer')']")
	private WebElement cConsumerType;
	
	@FindBy(how=How.XPATH,using="//input[@name='radio1' and @onclick='setCustomerType('business')']")
	private WebElement cBusinessType;
	
	@FindBy(how=How.ID, using = "prvi-standard-addressLine1")  // First text box under New Customer 
	public WebElement setAddressText;
	
	@FindBy(how=How.ID, using = "standardAddressTypeKey")
	public WebElement selectAddType;
	
	@FindBy(how=How.ID, using = "standardAddressStructureKey")
	public WebElement selectStructure;
	
	@FindBy(how=How.ID, using = "standardAddressFloorKey")
	public WebElement selectFloor;
	
	@FindBy(how=How.ID, using = "standard-city")
	public WebElement setCity;
	
	@FindBy(how=How.NAME, using = "standardAddress.state")
	public WebElement selectState;
	
	@FindBy(how=How.ID, using = "standard-zip")
	public WebElement setZipCode;
	
	@FindBy(how=How.ID, using = "checkAvailabilityButton")
	public WebElement availabilityButton;
	
	// Web element locator for Quick Sale
	
	@FindBy(how=How.ID, using = "sellitem_button")
	public WebElement quickSale;
	
	@FindBy(how=How.ID, using = "qtyToSell")
	public WebElement setCountItem;
	
	@FindBy(how=How.ID, using = "criteria")      // Item ID, UPC, SIM or IMEI
	public WebElement itemID;
	
	@FindBy(how=How.NAME, using = "salesRep")
	public WebElement salesRepID;
	
	@FindBy(how=How.ID, using = "btnAddItem1")
	public WebElement addItem;
	
	// HomePage function/Action implementation
	
	public void switchToFrameHomePage() {
		u.waitForElement(driver).until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(frameHomePage));
		//StackTraceElement dl = new Exception().getStackTrace()[0];
		// Add code here
		try{
		
	/*	Reporter.log(
		    dl.getClassName()+"/"+dl.getMethodName()+":"+dl.getLineNumber() + " switch to frame  ");*/

		l.info("passed " + HomePage.class.getName()+ " switch to frame  ");
		}catch(Exception we){
		//	Reporter.log(dl.getClassName()+"/"+dl.getMethodName()+":"+dl.getLineNumber() + " unable to switch to frame  ");
			l.info("passed " + HomePage.class.getName()+ "unable to  switch to frame  ");
		}
		
	}
	
	/* Function Name    : enterSearchFor
	 * Description      : To provide input of address of fist text box for address
	 *                    under text boxes.
	 * Parameter        : 
	 * @setAddressvalue : Parameter to hold input value of address
	 * Return           : None 
	 */
	
	public void enterSearchFor(String setAddressvalue){  
		if (setAddressText!=null) {
			try {
				setSearchFor.clear();
				setSearchFor.sendKeys(setAddressvalue);
				l.info(HomePage.class.getName()+ " enter " + setAddressvalue + " on enterSearchFor text box");
			} catch(NoSuchElementException e) {
				e.printStackTrace();
				l.info("Failed " + HomePage.class.getName()+ " unable to enter " + setAddressvalue+ " on enterSearchFor text box ");
			 }
		}
	}
	
	public HomePage click() 
	{
		// TODO Auto-generated method stub
		//u.waitForElement(hp.homeclick, 30);
		
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(homeClick));
		if(homeClick!=null)
		{
		homeClick.click();
		l.info( HomePage.class.getName() + " button click");
		}
		return new HomePage(driver);

	}
	
	public void clickTo() {
		//u.waitForElement(driver).until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(frameHomePage));
		//
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(newCustomerButton));
		if (newCustomerButton!=null)
		{
			try {
				newCustomerButton.click();
				l.info(HomePage.class.getName()+ " newCustomerButton button click");
				u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(setAddressText));
			} catch(NoSuchElementException e) {
					e.printStackTrace();
					l.info("Failed " + HomePage.class.getName()+ " unable to click on button ");
			}
		}
		
	}
	
	public void enterAddressLineOne(String setAddressvalue){
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(setAddressText));
		if (setAddressText!=null)
		{
			try {
				setAddressText.clear();
				l.info(HomePage.class.getName()+ " setAddressText textbox clear");
				setAddressText.sendKeys(setAddressvalue);
				l.info(HomePage.class.getName()+ " "+setAddressvalue+ "enter on setAddressText");
			} catch(NoSuchElementException e) {
				    e.printStackTrace();
				    l.info(HomePage.class.getName()+ " " + setAddressvalue + "failed to enter on setAddressText");
			 }
		}
	}
	
	public void setCityValue(String setCityValue) {
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(setCity));
		if (setCity!=null) {
			try {
				setCity.clear();
				l.info(HomePage.class.getName()+ " setCityValue textbox clear");
				setCity.sendKeys(setCityValue);
				l.info(HomePage.class.getName()+ " "+setCityValue+ "enter on setCityValue");
			} catch(NoSuchElementException e) {
				e.printStackTrace();
			    l.info(HomePage.class.getName()+ " " + setCityValue + "failed to enter on setCityValue");
			 }
		}
	}
	
	public  void selectStateHomePage(String stateValue) {
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(selectState));

		if (selectState!=null) {
			try {
				/*Select stores=new Select(selectState);
				stores.selectByVisibleText(stateValue);*/
				selectState.sendKeys(stateValue);
				l.info(HomePage.class.getName()+ " "+stateValue+ "enter on selectStateHomePage");
			} catch(NoSuchElementException e) {
				e.printStackTrace();
			    l.info(HomePage.class.getName()+ " " + stateValue + "failed to enter on selectStateHomePage");

			}
		}
	}
	
	public void setZipCodeHomePage(String setZipCodeValue) {
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(setZipCode));

		if (setZipCode!=null) {
			try {
				setZipCode.clear();
				l.info(HomePage.class.getName()+ " setZipCodeHomePage textbox clear");
				setZipCode.sendKeys(setZipCodeValue);
				l.info(HomePage.class.getName()+ " "+setZipCodeValue+ "enter on setZipCodeHomePage");
			} catch(NoSuchElementException e) {
				e.printStackTrace();
			    l.info(HomePage.class.getName()+ " " + setZipCodeValue + "failed to enter on setZipCodeHomePage");

			}
		}
	}
	
	public CpniPage clickToCheckAvailability() {
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(availabilityButton));

		if (availabilityButton!=null) {
			try {
				availabilityButton.click();
				l.info(" Passed" + LoginPageObject.class.getName() + " clear pass text box ");
			} catch(NoSuchElementException e) {
					e.printStackTrace();
					l.info(" Failed" + LoginPageObject.class.getName() + " unable to click on checkAvailability ");
			}
		}
		return new CpniPage(driver);	
	}
	
} // class ends here
