package com.pageobject;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.opusbase.TestBase;
import com.utility.Logg;
import com.utility.Util;


public class RemainedMeLaterPageObject {

	Util u = new Util();
	 WebDriver driver = u.getDriver();
	 org.apache.log4j.Logger l = Logg.createLogger();
	public RemainedMeLaterPageObject(WebDriver driver){
		this.driver=driver;
		PageFactory.initElements(driver, this);
		u=new Util();
	}
	
	@FindBy(how=How.NAME,using="successOK")
	public WebElement remianedbutton;
		
	public HomePage click()
	{
	//	u.waitForElement(remianedbutton, 30);
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(remianedbutton));
		if(remianedbutton!=null){
			remianedbutton.click();
			l.info("Passed " + StoreSelectPage.class.getName()+ " button click ");
		}	
		return new HomePage(driver);
	}
}
