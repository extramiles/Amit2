package com.pageobject;

import java.util.NoSuchElementException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;


import com.utility.Logg;
import com.utility.Util;

public class ConfirmOrderPage {
	
	Util u = new Util();
	//WebDriver driver;
	
	WebDriver driver = u.getDriver();
	org.apache.log4j.Logger Log = Logg.createLogger();	
	String webElementName;

	
	// Constructor for class TransactionCmplPage
	public ConfirmOrderPage(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver,this);
	}	
	
	
	// Select tag for submit button
		@FindBy(how=How.ID, using = "btnOK") 
		public WebElement btnSubmit;
			
		// Locator for cancel button
		@FindBy(how=How.ID, using = "btnCancel") 
		public WebElement btnCancel;	
		
	
		/*
		 * Method: public void clickSubmit() Description : To click on Submit
		 * button. Parameter : None Return type : Void
		 */
		public CustomerSignPage clickSubmit() {
			webElementName = "btnSubmit";
			u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(btnSubmit));
			try {
				btnSubmit.click();
				Log.info("Passed" + ConfirmOrderPage.class.getName() + ","
						+ "Submit button clicked");
			} catch (NoSuchElementException e) {
				e.printStackTrace();
				Log.info("Failed" + ConfirmOrderPage.class.getName() + webElementName
						+ " not found ");
			}
			return new CustomerSignPage(driver);
		}	
		
		/*
		 * Method: public void clickCancel() Description : To click on Cancel
		 * button. Parameter : None Return type : Void
		 */
		public void clickCancel() {
			webElementName = "btnCancel";
			u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(btnCancel));
			try {
				btnCancel.click();
				Log.info("Passed" + ConfirmOrderPage.class.getName() + ","
						+ "Cancel button clicked");
			} catch (NoSuchElementException e) {
				e.printStackTrace();
				Log.info("Failed" + ConfirmOrderPage.class.getName() + webElementName
						+ " not found ");
			}
			
		}	
	

}
