package com.pageobject;

import java.util.NoSuchElementException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.utility.Logg;
import com.utility.Util;

public class CustomerCheckoutGoPhPage {
	
	Util u = new Util();
	//WebDriver driver;
	
	WebDriver driver = u.getDriver();
	org.apache.log4j.Logger Log = Logg.createLogger();	
	String webElementName;
	
	public CustomerCheckoutGoPhPage(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver,this);
	}		
	
	//radios
	@FindBy(how=How.XPATH, using = "//form/div[2]//div[@class='bold']/span[2][contains(text(),'$')]") 
	public WebElement amountDue;
	
		@FindBy(how=How.ID, using = "bold_cash") 
		public WebElement radioCash;
		
		@FindBy(how=How.ID, using = "bold_credit_card") 
		public WebElement radioCreditCard;
		
		@FindBy(how=How.ID, using = "bold_travelers_check") 
		public WebElement radioTravelerCheck;
		
		@FindBy(how=How.ID, using = "bold_money_order") 
		public WebElement radioMoneyOrder;
		
		@FindBy(how=How.ID, using = "bold_gifcert") 
		public WebElement radioGiftCerti;
		
		
		@FindBy(how=How.ID, using = "bold_plenti") 
		public WebElement radioPlentiCard;
		
		//-------Cash-------
		
		@FindBy(how=How.XPATH, using = "//label[text()='Cash Amount Received:']/following-sibling::input") 
		public WebElement textCashAmountDue;
		
		//-------------- Credit card
		
		@FindBy(how=How.NAME, using = "amount") 
		public WebElement textCardAmount;
		
		@FindBy(how=How.ID, using = "manualAuth") 
		public WebElement checkManAuth;
		
		@FindBy(how=How.ID, using = "cardHolderName") 
		public WebElement textHolderName;
		
		@FindBy(how=How.ID, using = "cardNumber") 
		public WebElement textCardNumber;
		
		@FindBy(how=How.ID, using = "expMonth") 
		public WebElement textExpiryMonth;
		
		@FindBy(how=How.ID, using = "expYear") 
		public WebElement textExpiryYear;
		
		@FindBy(how=How.ID, using = "customerCode") 
		public WebElement textCustomerCode;
		
		@FindBy(how=How.ID, using = "opusmobileccSubmit") 
		public WebElement btnCreditCardSubmit;
		
		//----------------- Traveler's Check
		
		@FindBy(how=How.ID, using = "travelersCheckAmount") 
		public WebElement textTravelerCheckAmount;
		
		@FindBy(how=How.ID, using = "travelersCheckNumber") 
		public WebElement textTravelerCheckNumber;
		
		//------------ Money Order / Cashier's Check
		
		@FindBy(how=How.ID, using = "moCashiersCheckAmount") 
		public WebElement textMoCashierCheckAmount;
		
		//------------ Gift Certificate
		
		@FindBy(how=How.ID, using = "certAmount") 
		public WebElement textGiftCertiAmount;
		
		@FindBy(how=How.ID, using = "certNumber") 
		public WebElement textGiftCertiNumber;
		
		//--------------- Plenti Points
		
		//radios
		
		@FindBy(how=How.ID, using = "searchTypeCard") 
		public WebElement radioSearchByPlentiCard;
		
		@FindBy(how=How.ID, using = "searchTypePhone") 
		public WebElement radioSearchByPlentiPhone;
		
		@FindBy(how=How.ID, using = "setAccountNumber") 
		public WebElement textPlentiCardNumber;
		
		@FindBy(how=How.ID, using = "pinText") 
		public WebElement textPlentiPin;
		
		@FindBy(how=How.ID, using = "pinSigCapButtonId") 
		public WebElement btnPinPad;
		
		@FindBy(how=How.CSS, using = "button[class='greenButton'][value='Get Plenti Details']") 
		public WebElement btnGetPlentiDetails;
		
		
		@FindBy(how=How.ID, using = "btncancel") 
		public WebElement btnCancel;
		
		@FindBy(how=How.ID, using = "btnSubmit") 
		public WebElement btnSubmit;
		
		
		/*
		 * Method: public void clickCash() Description : To click on Cash
		 *radio button. Parameter : None Return type : Void
		 */
		public void clickCash() {
			webElementName = "radioCash";
			u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(radioCash));
			try {
				radioCash.click();
				Log.info("Passed" + CustomerCheckoutGoPhPage.class.getName() + ","
						+ "Cash payment mode selected");
			} catch (NoSuchElementException e) {
				e.printStackTrace();
				Log.info("Failed" + CustomerCheckoutGoPhPage.class.getName() + webElementName
						+ " not found ");
			}
		}
		
		
		
		
		
		/*
		 * Method: public void clickCreditCard() Description : To click on Credit Card
		 *radio button. Parameter : None Return type : Void
		 */
		public void clickCreditCard() {
			webElementName = "radioCreditCard";
			u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(radioCreditCard));
			try {
				radioCreditCard.click();
				Log.info("Passed" + CustomerCheckoutGoPhPage.class.getName() + ","
						+ "Credit Card payment mode selected");
			} catch (NoSuchElementException e) {
				e.printStackTrace();
				Log.info("Failed" + CustomerCheckoutGoPhPage.class.getName() + webElementName
						+ " not found ");
			}
		}
		
		/*
		 * Method: public void clickTravelerCheck() Description : To click on Traveler's Check
		 *radio button. Parameter : None Return type : Void
		 */
		public void clickTravelerCheck() {
			webElementName = "radioTravelerCheck";
			u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(radioTravelerCheck));
			try {
				radioTravelerCheck.click();
				Log.info("Passed" + CustomerCheckoutGoPhPage.class.getName() + ","
						+ "Credit Card payment mode selected");
			} catch (NoSuchElementException e) {
				e.printStackTrace();
				Log.info("Failed" + CustomerCheckoutGoPhPage.class.getName() + webElementName
						+ " not found ");
			}
		}
		
		/*
		 * Method: public void clickMoneyOrder() Description : To click on Money Order/ Cashier's Check
		 *radio button. Parameter : None Return type : Void
		 */
		public void clickMoneyOrder() {
			webElementName = "radioMoneyOrder";
			u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(radioMoneyOrder));
			try {
				radioMoneyOrder.click();
				Log.info("Passed" + CustomerCheckoutGoPhPage.class.getName() + ","
						+ "Credit Card payment mode selected");
			} catch (NoSuchElementException e) {
				e.printStackTrace();
				Log.info("Failed" + CustomerCheckoutGoPhPage.class.getName() + webElementName
						+ " not found ");
			}
		}
		
		/*
		 * Method: public void clickGiftCertificate() Description : To click on Gift Certificate
		 *radio button. Parameter : None Return type : Void
		 */
		public void clickGiftCertificate() {
			webElementName = "radioGiftCerti";
			u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(radioGiftCerti));
			try {
				radioGiftCerti.click();
				Log.info("Passed" + CustomerCheckoutGoPhPage.class.getName() + ","
						+ "Credit Card payment mode selected");
			} catch (NoSuchElementException e) {
				e.printStackTrace();
				Log.info("Failed" + CustomerCheckoutGoPhPage.class.getName() + webElementName
						+ " not found ");
			}
		}
		
		/*
		 * Method: public void clickPlentiCard() Description : To click on Plenti Card
		 *radio button. Parameter : None Return type : Void
		 */
		public void clickPlentiCard() {
			webElementName = "radioPlentiCard";
			u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(radioPlentiCard));
			try {
				radioPlentiCard.click();
				Log.info("Passed" + CustomerCheckoutGoPhPage.class.getName() + ","
						+ "Credit Card payment mode selected");
			} catch (NoSuchElementException e) {
				e.printStackTrace();
				Log.info("Failed" + CustomerCheckoutGoPhPage.class.getName() + webElementName
						+ " not found ");
			}
		}
		
		
		//Cash
		
		
		/*
		 * Method: enterCashAmount Description : To enter Cash Amount due
		 * card selected. Parameter :
		 * 
		 * @setCashAmount : Parameter to hold input value of Cash Amount due. Return type :
		 * Void
		 */

		public void enterCashAmount(String setCashAmount) {
			webElementName = "textCashAmountDue";
			u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(textCashAmountDue));
			if (setCashAmount != null) {
				try {
					textCashAmountDue.clear();
					Log.info("Passed" + CustomerCheckoutGoPhPage.class.getName()
							+ "," + webElementName + " cleared ");
					textCashAmountDue.sendKeys(setCashAmount);
					Log.info("Passed" + CustomerCheckoutGoPhPage.class.getName()
							+ "," + setCashAmount + " entered ");
				} catch (NoSuchElementException e) {
					e.printStackTrace();
					Log.info("Failed" + CustomerCheckoutGoPhPage.class.getName()
							+ webElementName + " not found ");
				}
			}
		}
		
		
		
		
		
		/*
		 * Method: enterHolderName Description : To enter Card Holder Name corresponding to
		 * card selected. Parameter :
		 * 
		 * @setHolderName : Parameter to hold input value of Holder name. Return type :
		 * Void
		 */

		public void enterHolderName(String setHolderName) {
			webElementName = "textHolderName";
			u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(textHolderName));
			if (setHolderName != null) {
				try {
					textHolderName.clear();
					Log.info("Passed" + CustomerCheckoutGoPhPage.class.getName()
							+ "," + webElementName + " cleared ");
					textHolderName.sendKeys(setHolderName);
					Log.info("Passed" + CustomerCheckoutGoPhPage.class.getName()
							+ "," + setHolderName + " entered ");
				} catch (NoSuchElementException e) {
					e.printStackTrace();
					Log.info("Failed" + CustomerCheckoutGoPhPage.class.getName()
							+ webElementName + " not found ");
				}
			}
		}
		
		/*
		 * Method: enterCardNumber Description : To enter Card Number for the
		 * card selected. Parameter :
		 * 
		 * @setCardNumber : Parameter to hold input value of Card Number. Return type :
		 * Void
		 */

		public void enterCardNumber(String setCardNumber) {
			webElementName = "textCardNumber";
			u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(textCardNumber));
			if (setCardNumber != null) {
				try {
					textCardNumber.clear();
					Log.info("Passed" + CustomerCheckoutGoPhPage.class.getName()
							+ "," + webElementName + " cleared ");
					textCardNumber.sendKeys(setCardNumber);
					Log.info("Passed" + CustomerCheckoutGoPhPage.class.getName()
							+ "," + setCardNumber + " entered ");
				} catch (NoSuchElementException e) {
					e.printStackTrace();
					Log.info("Failed" + CustomerCheckoutGoPhPage.class.getName()
							+ webElementName + " not found ");
				}
			}
		}
		
		/*
		 * Method: enterExpiryMonth Description : To enter Expiry Month for the
		 * card selected. Parameter :
		 * 
		 * @setExpiryMonth : Parameter to hold input value of Expiry Month. Return type :
		 * Void
		 */

		public void enterExpiryMonth(String setExpiryMonth) {
			webElementName = "textExpiryMonth";
			u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(textExpiryMonth));
			if (setExpiryMonth != null) {
				try {
					textExpiryMonth.clear();
					Log.info("Passed" + CustomerCheckoutGoPhPage.class.getName()
							+ "," + webElementName + " cleared ");
					textExpiryMonth.sendKeys(setExpiryMonth);
					Log.info("Passed" + CustomerCheckoutGoPhPage.class.getName()
							+ "," + setExpiryMonth + " entered ");
				} catch (NoSuchElementException e) {
					e.printStackTrace();
					Log.info("Failed" + CustomerCheckoutGoPhPage.class.getName()
							+ webElementName + " not found ");
				}
			}
		}
		
		/*
		 * Method: enterExpiryYear Description : To enter Expiry Year for the
		 * card selected. Parameter :
		 * 
		 * @setExpiryYear : Parameter to hold input value of Expiry Year. Return type :
		 * Void
		 */

		public void enterExpiryYear(String setExpiryYear) {
			webElementName = "textExpiryYear";
			u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(textExpiryYear));
			if (setExpiryYear != null) {
				try {
					textExpiryYear.clear();
					Log.info("Passed" + CustomerCheckoutGoPhPage.class.getName()
							+ "," + webElementName + " cleared ");
					textExpiryYear.sendKeys(setExpiryYear);
					Log.info("Passed" + CustomerCheckoutGoPhPage.class.getName()
							+ "," + setExpiryYear + " entered ");
				} catch (NoSuchElementException e) {
					e.printStackTrace();
					Log.info("Failed" + CustomerCheckoutGoPhPage.class.getName()
							+ webElementName + " not found ");
				}
			}
		}
		
		/*
		 * Method: enterCustomerCode Description : To enter Customer code.
		 *  Parameter :
		 * 
		 * @setCustomerCode : Parameter to hold input value of Customer Code. Return type :
		 * Void
		 */

		public void enterCustomerCode(String setCustomerCode) {
			webElementName = "textCustomerCode";
			u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(textCustomerCode));
			if (setCustomerCode != null) {
				try {
					textCustomerCode.clear();
					Log.info("Passed" + CustomerCheckoutGoPhPage.class.getName()
							+ "," + webElementName + " cleared ");
					textCustomerCode.sendKeys(setCustomerCode);
					Log.info("Passed" + CustomerCheckoutGoPhPage.class.getName()
							+ "," + setCustomerCode + " entered ");
				} catch (NoSuchElementException e) {
					e.printStackTrace();
					Log.info("Failed" + CustomerCheckoutGoPhPage.class.getName()
							+ webElementName + " not found ");
				}
			}
		}
		

		/*
		 * Method: public void clickCreditCardSubmit() Description : To click on Submit button for Card payment
		 * Parameter : None Return type : Void
		 */
		public void clickCreditCardSubmit() {
			webElementName = "btnCreditCardSubmit";
			u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(btnCreditCardSubmit));
			try {
				btnCreditCardSubmit.click();
				Log.info("Passed" + CustomerCheckoutPage.class.getName() + ","
						+ "Cancel button clicked");
			} catch (NoSuchElementException e) {
				e.printStackTrace();
				Log.info("Failed" + CustomerCheckoutPage.class.getName() + webElementName
						+ " not found ");
			}
			
		}
		
		/*
		 * Method: enterTravelerCheckAmount Description : To enter Cash Amount due.
		 * Parameter :
		 * 
		 * @setTravelerChecAmount : Parameter to hold input value of Traveler Check Amount. Return type :
		 * Void
		 */

		public void enterTravelerCheckAmount(String setTravelerCheckAmount) {
			webElementName = "textTravelerCheckAmount";
			u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(textTravelerCheckAmount));
			if (setTravelerCheckAmount != null) {
				try {
					textTravelerCheckAmount.clear();
					Log.info("Passed" + CustomerCheckoutGoPhPage.class.getName()
							+ "," + webElementName + " cleared ");
					textTravelerCheckAmount.sendKeys(setTravelerCheckAmount);
					Log.info("Passed" + CustomerCheckoutGoPhPage.class.getName()
							+ "," + setTravelerCheckAmount + " entered ");
				} catch (NoSuchElementException e) {
					e.printStackTrace();
					Log.info("Failed" + CustomerCheckoutGoPhPage.class.getName()
							+ webElementName + " not found ");
				}
			}
		}
		
		/*
		 * Method: enterTravelerCheckAmount Description : To enter Cash Amount due
		 *  Parameter :
		 * 
		 * @setTravelerChecAmount : Parameter to hold input value of Traveler Check Amount. Return type :
		 * Void
		 */

		public void enterTravelerCheckNumber(String setTravelerCheckNumber) {
			webElementName = "textTravelerCheckNumber";
			u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(textTravelerCheckNumber));
			if (setTravelerCheckNumber != null) {
				try {
					textTravelerCheckNumber.clear();
					Log.info("Passed" + CustomerCheckoutGoPhPage.class.getName()
							+ "," + webElementName + " cleared ");
					textTravelerCheckNumber.sendKeys(setTravelerCheckNumber);
					Log.info("Passed" + CustomerCheckoutGoPhPage.class.getName()
							+ "," + setTravelerCheckNumber + " entered ");
				} catch (NoSuchElementException e) {
					e.printStackTrace();
					Log.info("Failed" + CustomerCheckoutGoPhPage.class.getName()
							+ webElementName + " not found ");
				}
			}
		}
		
		/*
		 * Method: enterMoneyOrderAmount Description : To enter Money Order Amount.
		 *  Parameter :
		 * 
		 * @setTravelerChecAmount : Parameter to hold input value of Traveler Check Amount. Return type :
		 * Void
		 */

		public void enterMoneyOrderAmount(String setMoneyOrderAmount) {
			webElementName = "textMoCashierCheckAmount";
			u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(textMoCashierCheckAmount));
			if (setMoneyOrderAmount != null) {
				try {
					textMoCashierCheckAmount.clear();
					Log.info("Passed" + CustomerCheckoutGoPhPage.class.getName()
							+ "," + webElementName + " cleared ");
					textMoCashierCheckAmount.sendKeys(setMoneyOrderAmount);
					Log.info("Passed" + CustomerCheckoutGoPhPage.class.getName()
							+ "," + setMoneyOrderAmount + " entered ");
				} catch (NoSuchElementException e) {
					e.printStackTrace();
					Log.info("Failed" + CustomerCheckoutGoPhPage.class.getName()
							+ webElementName + " not found ");
				}
			}
		}
		
		
		/*
		 * Method: enterGiftCertiAmount Description : To enter Gift Certificate Amount
		 * card selected. Parameter :
		 * 
		 * @setTravelerChecAmount : Parameter to hold input value of Traveler Check Amount. Return type :
		 * Void
		 */

		public void enterGiftCertiAmount(String setGiftCertiAmount) {
			webElementName = "textGiftCertiAmount";
			u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(textGiftCertiAmount));
			if (setGiftCertiAmount != null) {
				try {
					textGiftCertiAmount.clear();
					Log.info("Passed" + CustomerCheckoutGoPhPage.class.getName()
							+ "," + webElementName + " cleared ");
					textGiftCertiAmount.sendKeys(setGiftCertiAmount);
					Log.info("Passed" + CustomerCheckoutGoPhPage.class.getName()
							+ "," + setGiftCertiAmount + " entered ");
				} catch (NoSuchElementException e) {
					e.printStackTrace();
					Log.info("Failed" + CustomerCheckoutGoPhPage.class.getName()
							+ webElementName + " not found ");
				}
			}
		}
		
		/*
		 * Method: enterGIftCertiNumber Description : To enter Gift Certificate Number.
		 *  Parameter :
		 * 
		 * @setGiftCertiNumber : Parameter to hold input value of Gift Certificate Number. Return type :
		 * Void
		 */

		public void enterGiftCertiNumber(String setGiftCertiNumber) {
			webElementName = "textGiftCertiNumber";
			u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(textGiftCertiNumber));
			if (setGiftCertiNumber != null) {
				try {
					textGiftCertiNumber.clear();
					Log.info("Passed" + CustomerCheckoutGoPhPage.class.getName()
							+ "," + webElementName + " cleared ");
					textGiftCertiNumber.sendKeys(setGiftCertiNumber);
					Log.info("Passed" + CustomerCheckoutGoPhPage.class.getName()
							+ "," + setGiftCertiNumber + " entered ");
				} catch (NoSuchElementException e) {
					e.printStackTrace();
					Log.info("Failed" + CustomerCheckoutGoPhPage.class.getName()
							+ webElementName + " not found ");
				}
			}
		}
		
		
		/*
		 * Method: public void clickSearchByPlentiCard() Description : To click on Search By Plenti Card Number
		 * Parameter : None Return type : Void
		 */
		public void clickSearchByPlentiCard() {
			webElementName = "radioSearchByPlentiCard";
			u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(radioSearchByPlentiCard));
			try {
				radioSearchByPlentiCard.click();
				Log.info("Passed" + CustomerCheckoutGoPhPage.class.getName() + ","
						+ "Search By Plenti Card Number");
			} catch (NoSuchElementException e) {
				e.printStackTrace();
				Log.info("Failed" + CustomerCheckoutGoPhPage.class.getName() + webElementName
						+ " not found ");
			}
		}
		
		/*
		 * Method: public void clickSearchByPlentiPhone() Description : To click on Search By Plenti Phone Number
		 * Parameter : None Return type : Void
		 */
		public void clickSearchByPlentiPhone() {
			webElementName = "radioSearchByPlentiPhone";
			u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(radioSearchByPlentiPhone));
			try {
				radioSearchByPlentiPhone.click();
				Log.info("Passed" + CustomerCheckoutGoPhPage.class.getName() + ","
						+ "Search By Plenti Phone Number");
			} catch (NoSuchElementException e) {
				e.printStackTrace();
				Log.info("Failed" + CustomerCheckoutGoPhPage.class.getName() + webElementName
						+ " not found ");
			}
		}
		
		/*
		 * Method: enterPlentiCardNumber Description : To enter Plenti Card Number.
		 *  Parameter :
		 * 
		 * @setPlentiCardNumber : Parameter to hold input value of Plenti Card Number. Return type :
		 * Void
		 */

		public void enterPlentiCardNumber(String setPlentiCardNumber) {
			webElementName = "textPlentiCardNumber";
			u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(textPlentiCardNumber));
			if (setPlentiCardNumber != null) {
				try {
					textPlentiCardNumber.clear();
					Log.info("Passed" + CustomerCheckoutGoPhPage.class.getName()
							+ "," + webElementName + " cleared ");
					textPlentiCardNumber.sendKeys(setPlentiCardNumber);
					Log.info("Passed" + CustomerCheckoutGoPhPage.class.getName()
							+ "," + setPlentiCardNumber + " entered ");
				} catch (NoSuchElementException e) {
					e.printStackTrace();
					Log.info("Failed" + CustomerCheckoutGoPhPage.class.getName()
							+ webElementName + " not found ");
				}
			}
		}
		
		
		/*
		 * Method: enterPlentiPin Description : To enter Plenti PIN.
		 *  Parameter :
		 * 
		 * @setPlentiPin : Parameter to hold input value of Plenti PIN. Return type :
		 * Void
		 */

		public void enterPlentiPin(String setPlentiPin) {
			webElementName = "textPlentiPin";
			u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(textPlentiPin));
			if (setPlentiPin != null) {
				try {
					textPlentiPin.clear();
					Log.info("Passed" + CustomerCheckoutGoPhPage.class.getName()
							+ "," + webElementName + " cleared ");
					textPlentiPin.sendKeys(setPlentiPin);
					Log.info("Passed" + CustomerCheckoutGoPhPage.class.getName()
							+ "," + setPlentiPin + " entered ");
				} catch (NoSuchElementException e) {
					e.printStackTrace();
					Log.info("Failed" + CustomerCheckoutGoPhPage.class.getName()
							+ webElementName + " not found ");
				}
			}
		}
		
		/*
		 * Method: public void clickPinPad() Description : To click on PIN pad button.
		 * Parameter : None Return type : Void
		 */
		public void clickPinPad() {
			webElementName = "btnPinPad";
			u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(btnPinPad));
			try {
				btnPinPad.click();
				Log.info("Passed" + CustomerCheckoutPage.class.getName() + ","
						+ "PIN Pad button clicked");
			} catch (NoSuchElementException e) {
				e.printStackTrace();
				Log.info("Failed" + CustomerCheckoutPage.class.getName() + webElementName
						+ " not found ");
			}
			
		}
		
		/*
		 * Method: public void clickSubmit() Description : To click on Submit
		 * button. Parameter : None Return type : Void
		 */
		public TransactionCmplPage clickSubmit() {
			webElementName = "btnSubmit";
			u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(btnSubmit));
			try {
				btnSubmit.click();
				Log.info("Passed" + CustomerCheckoutPage.class.getName() + ","
						+ "Submit button clicked");
			} catch (NoSuchElementException e) {
				e.printStackTrace();
				Log.info("Failed" + CustomerCheckoutPage.class.getName() + webElementName
						+ " not found ");
			}
			return new TransactionCmplPage(driver);
		}	
		
		/*
		 * Method: public void clickCancel() Description : To click on Cancel
		 * button. Parameter : None Return type : Void
		 */
		public void clickCancel() {
			webElementName = "btnCancel";
			u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(btnCancel));
			try {
				btnCancel.click();
				Log.info("Passed" + CustomerCheckoutPage.class.getName() + ","
						+ "Cancel button clicked");
			} catch (NoSuchElementException e) {
				e.printStackTrace();
				Log.info("Failed" + CustomerCheckoutPage.class.getName() + webElementName
						+ " not found ");
			}
			
		}	
		

}
