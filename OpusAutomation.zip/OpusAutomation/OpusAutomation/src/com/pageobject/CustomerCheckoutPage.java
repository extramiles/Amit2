package com.pageobject;

import java.util.NoSuchElementException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.utility.Logg;
import com.utility.Util;
public class CustomerCheckoutPage {
	
	Util u = new Util();
	//WebDriver driver;
	
	WebDriver driver = u.getDriver();
	org.apache.log4j.Logger Log = Logg.createLogger();	
	String webElementName;
	
	public CustomerCheckoutPage(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver,this);
	}	

	@FindBy(how=How.ID, using = "useStation") 
	public WebElement btnUseStation;
	
	//radios
	@FindBy(how=How.XPATH, using = "//span/table/tbody/tr/td/div/div/input[@id='bold_credit_card']") 
	public WebElement radioCreditCard;
	
	@FindBy(how=How.ID, using = "bold_isis_card") 
	public WebElement radioIsisCard;
	
	@FindBy(how=How.ID, using = "bold_plenti") 
	public WebElement radioPlentiCard;
	
	//text boxes
	
	@FindBy(how=How.ID, using = "cardHolderName") 
	public WebElement textHolderName;
	
	@FindBy(how=How.ID, using = "cardNumber") 
	public WebElement textCardNumber;
	
	@FindBy(how=How.ID, using = "expMonth") 
	public WebElement textExpiryMonth;
	
	@FindBy(how=How.ID, using = "expYear") 
	public WebElement textExpiryYear;
	
	@FindBy(how=How.ID, using = "customerCode") 
	public WebElement textCustomerCode;
	
	@FindBy(how=How.ID, using = "cardNumberLast4Digite") 
	public WebElement textLastFourDigit;
	
	@FindBy(how=How.ID, using = "password_verificationCode") 
	public WebElement textVerificationCode;
	
	@FindBy(how=How.ID, using = "zipCode") 
	public WebElement textZipCode;
	
	@FindBy(how=How.ID, using = "opusmobileccSubmit") 
	public WebElement btnSubmit;
	
	@FindBy(how=How.CSS, using = "button[class='greyButton'][value='Cancel']") 
	public WebElement btnCancel;
	
	
	/*
	 * Method: public void clickUseStation() Description : To click on Use Station
	 * button. Parameter : None Return type : Void
	 */
	public void clickUseStation() {
		webElementName = "btnUseStation";
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(btnUseStation));
		try {
			btnUseStation.click();
			Log.info("Passed" + CustomerSignPage.class.getName() + ","
					+ "Use Station button clicked");
		} catch (NoSuchElementException e) {
			e.printStackTrace();
			Log.info("Failed" + CustomerSignPage.class.getName() + webElementName
					+ " not found ");
		}
		
	}	
	
	/*
	 * Method: public void clickCreditCard() Description : To click on Credit Card
	 *radio button. Parameter : None Return type : Void
	 */
	public void clickCreditCard() {
		webElementName = "radioCreditCard";
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(radioCreditCard));
		try {
			radioCreditCard.click();
			Log.info("Passed" + CustomerCheckoutPage.class.getName() + ","
					+ "Credit Card payment mode selected");
		} catch (NoSuchElementException e) {
			e.printStackTrace();
			Log.info("Failed" + CustomerCheckoutPage.class.getName() + webElementName
					+ " not found ");
		}
	}
	
	/*
	 * Method: public void clickIsisCard() Description : To click on AT&T ISIS option
	 *radio button. Parameter : None Return type : Void
	 */
	public void clickIsisCard() {
		webElementName = "radioIsisCard";
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(radioIsisCard));
		try {
			radioIsisCard.click();
			Log.info("Passed" + CustomerCheckoutPage.class.getName() + ","
					+ "ISIS payment mode selected");
		} catch (NoSuchElementException e) {
			e.printStackTrace();
			Log.info("Failed" + CustomerCheckoutPage.class.getName() + webElementName
					+ " not found ");
		}
	}
	
	/*
	 * Method: public void clickPlentiCard() Description : To click on AT&T Plenti option
	 *radio button. Parameter : None Return type : Void
	 */
	public void clickPlentiCard() {
		webElementName = "radioPlentiCard";
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(radioPlentiCard));
		try {
			radioPlentiCard.click();
			Log.info("Passed" + CustomerCheckoutPage.class.getName() + ","
					+ "Plenti payment mode selected");
		} catch (NoSuchElementException e) {
			e.printStackTrace();
			Log.info("Failed" + CustomerCheckoutPage.class.getName() + webElementName
					+ " not found ");
		}
	}
	
	/*
	 * Method: enterHolderName Description : To enter Card Holder Name corresponding to
	 * card selected. Parameter :
	 * 
	 * @setHolderName : Parameter to hold input value of Holder name. Return type :
	 * Void
	 */

	public void enterHolderName(String setHolderName) {
		webElementName = "textHolderName";
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(textHolderName));
		if (setHolderName != null) {
			try {
				textHolderName.clear();
				Log.info("Passed" + CustomerCheckoutPage.class.getName()
						+ "," + webElementName + " cleared ");
				textHolderName.sendKeys(setHolderName);
				Log.info("Passed" + CustomerCheckoutPage.class.getName()
						+ "," + setHolderName + " entered ");
			} catch (NoSuchElementException e) {
				e.printStackTrace();
				Log.info("Failed" + CustomerCheckoutPage.class.getName()
						+ webElementName + " not found ");
			}
		}
	}
	
	/*
	 * Method: enterCardNumber Description : To enter Card Number for the
	 * card selected. Parameter :
	 * 
	 * @setCardNumber : Parameter to hold input value of Card Number. Return type :
	 * Void
	 */

	public void enterCardNumber(String setCardNumber) {
		webElementName = "textCardNumber";
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(textCardNumber));
		if (setCardNumber != null) {
			try {
				textCardNumber.clear();
				Log.info("Passed" + CustomerCheckoutPage.class.getName()
						+ "," + webElementName + " cleared ");
				textCardNumber.sendKeys(setCardNumber);
				Log.info("Passed" + CustomerCheckoutPage.class.getName()
						+ "," + setCardNumber + " entered ");
			} catch (NoSuchElementException e) {
				e.printStackTrace();
				Log.info("Failed" + CustomerCheckoutPage.class.getName()
						+ webElementName + " not found ");
			}
		}
	}
	
	/*
	 * Method: enterExpiryMonth Description : To enter Expiry Month for the
	 * card selected. Parameter :
	 * 
	 * @setExpiryMonth : Parameter to hold input value of Expiry Month. Return type :
	 * Void
	 */

	public void enterExpiryMonth(String setExpiryMonth) {
		webElementName = "textExpiryMonth";
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(textExpiryMonth));
		if (setExpiryMonth != null) {
			try {
				textExpiryMonth.clear();
				Log.info("Passed" + CustomerCheckoutPage.class.getName()
						+ "," + webElementName + " cleared ");
				textExpiryMonth.sendKeys(setExpiryMonth);
				Log.info("Passed" + CustomerCheckoutPage.class.getName()
						+ "," + setExpiryMonth + " entered ");
			} catch (NoSuchElementException e) {
				e.printStackTrace();
				Log.info("Failed" + CustomerCheckoutPage.class.getName()
						+ webElementName + " not found ");
			}
		}
	}
	
	/*
	 * Method: enterExpiryYear Description : To enter Expiry Year for the
	 * card selected. Parameter :
	 * 
	 * @setExpiryYear : Parameter to hold input value of Expiry Year. Return type :
	 * Void
	 */

	public void enterExpiryYear(String setExpiryYear) {
		webElementName = "textExpiryYear";
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(textExpiryYear));
		if (setExpiryYear != null) {
			try {
				textExpiryYear.clear();
				Log.info("Passed" + CustomerCheckoutPage.class.getName()
						+ "," + webElementName + " cleared ");
				textExpiryYear.sendKeys(setExpiryYear);
				Log.info("Passed" + CustomerCheckoutPage.class.getName()
						+ "," + setExpiryYear + " entered ");
			} catch (NoSuchElementException e) {
				e.printStackTrace();
				Log.info("Failed" + CustomerCheckoutPage.class.getName()
						+ webElementName + " not found ");
			}
		}
	}
	
	/*
	 * Method: enterCustomerCode Description : To enter Customer code.
	 *  Parameter :
	 * 
	 * @setCustomerCode : Parameter to hold input value of Customer Code. Return type :
	 * Void
	 */

	public void enterCustomerCode(String setCustomerCode) {
		webElementName = "textCustomerCode";
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(textCustomerCode));
		if (setCustomerCode != null) {
			try {
				textCustomerCode.clear();
				Log.info("Passed" + CustomerCheckoutPage.class.getName()
						+ "," + webElementName + " cleared ");
				textCustomerCode.sendKeys(setCustomerCode);
				Log.info("Passed" + CustomerCheckoutPage.class.getName()
						+ "," + setCustomerCode + " entered ");
			} catch (NoSuchElementException e) {
				e.printStackTrace();
				Log.info("Failed" + CustomerCheckoutPage.class.getName()
						+ webElementName + " not found ");
			}
		}
	}
	
	/*
	 * Method: enterLastFourDigit Description : To enter Last 4 Digits.
	 *  Parameter :
	 * 
	 * @setLastFourDigit : Parameter to hold input value of Last 4 Digits. Return type :
	 * Void
	 */

	public void enterLastFourDigit(String setLastFourDigit) {
		webElementName = "textLastFourDigit";
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(textLastFourDigit));
		if (setLastFourDigit != null) {
			try {
				textLastFourDigit.clear();
				Log.info("Passed" + CustomerCheckoutPage.class.getName()
						+ "," + webElementName + " cleared ");
				textCustomerCode.sendKeys(setLastFourDigit);
				Log.info("Passed" + CustomerCheckoutPage.class.getName()
						+ "," + setLastFourDigit + " entered ");
			} catch (NoSuchElementException e) {
				e.printStackTrace();
				Log.info("Failed" + CustomerCheckoutPage.class.getName()
						+ webElementName + " not found ");
			}
		}
	}
	
	/*
	 * Method: enterVerificationCode Description : To enter Verification Code.
	 *  Parameter :
	 * 
	 * @setVerificationCode : Parameter to hold input value of Verification Code. Return type :
	 * Void
	 */

	public void enterVerificationCode(String setVerificationCode) {
		webElementName = "textVerificationCode";
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(textVerificationCode));
		if (setVerificationCode != null) {
			try {
				textVerificationCode.clear();
				Log.info("Passed" + CustomerCheckoutPage.class.getName()
						+ "," + webElementName + " cleared ");
				textVerificationCode.sendKeys(setVerificationCode);
				Log.info("Passed" + CustomerCheckoutPage.class.getName()
						+ "," + setVerificationCode + " entered ");
			} catch (NoSuchElementException e) {
				e.printStackTrace();
				Log.info("Failed" + CustomerCheckoutPage.class.getName()
						+ webElementName + " not found ");
			}
		}
	}
	
	/*
	 * Method: enterZipCode Description : To enter Verification Code.
	 *  Parameter :
	 * 
	 * @setZipCode : Parameter to hold input value of Zip Code. Return type :
	 * Void
	 */

	public void enterZipCode(String setZipCode) {
		webElementName = "textZipCode";
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(textZipCode));
		if (setZipCode != null) {
			try {
				textZipCode.clear();
				Log.info("Passed" + CustomerCheckoutPage.class.getName()
						+ "," + webElementName + " cleared ");
				textZipCode.sendKeys(setZipCode);
				Log.info("Passed" + CustomerCheckoutPage.class.getName()
						+ "," + setZipCode + " entered ");
			} catch (NoSuchElementException e) {
				e.printStackTrace();
				Log.info("Failed" + CustomerCheckoutPage.class.getName()
						+ webElementName + " not found ");
			}
		}
	}
	
	
	/*
	 * Method: public void clickSubmit() Description : To click on Submit
	 * button. Parameter : None Return type : Void
	 */
	public void clickSubmit() {
		webElementName = "btnSubmit";
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(btnSubmit));
		try {
			btnSubmit.click();
			Log.info("Passed" + CustomerCheckoutPage.class.getName() + ","
					+ "Submit button clicked");
		} catch (NoSuchElementException e) {
			e.printStackTrace();
			Log.info("Failed" + CustomerCheckoutPage.class.getName() + webElementName
					+ " not found ");
		}
		//return new CustomerSignPage(driver);
	}	
	
	/*
	 * Method: public void clickCancel() Description : To click on Cancel
	 * button. Parameter : None Return type : Void
	 */
	public void clickCancel() {
		webElementName = "btnCancel";
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(btnCancel));
		try {
			btnCancel.click();
			Log.info("Passed" + CustomerCheckoutPage.class.getName() + ","
					+ "Cancel button clicked");
		} catch (NoSuchElementException e) {
			e.printStackTrace();
			Log.info("Failed" + CustomerCheckoutPage.class.getName() + webElementName
					+ " not found ");
		}
		
	}	
	
	
	
	
	
}
