/*
Description : This class identify and implement all the web
element and its corresponding action of Next Steps - check Promo eligibility Page
Consent page.
Version info : V_0.1
Date : 05/06/2017
Author : Devendra Bhavsar
Copyright notice : Tech Mahindra Ltd
 */
package com.pageobject;

import java.util.NoSuchElementException;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;


import org.openqa.selenium.support.ui.ExpectedConditions;

import com.utility.Logg;
import com.utility.Util;




public class NextStepPromoPage{
	Util u = new Util();
	WebDriver driver = u.getDriver();
	Logger Log = Logg.createLogger();

	public NextStepPromoPage(WebDriver driver){
		this.driver = driver;
		PageFactory.initElements(new AjaxElementLocatorFactory(driver,20), this);
	}
	
	/*-------------------------------------------------------- Page objects ---------------------------------------------------- */
	@FindBy(how = How.XPATH, using = "//div//div[text()='Next Steps']")
	public WebElement nextStepPageHeader;
	
	@FindBy(how = How.XPATH, using = "//input[@name = 'viewPromosSelection' and @value = 'Y']")
	private WebElement radioYes;
	
	@FindBy(how = How.XPATH, using = "//input[@name = 'viewPromosSelection' and @value = 'N']")
	private WebElement radioNo;
	
	@FindBy(how = How.XPATH, using = "//div/input[@id='submitPromoSelectionBtn' and @type='button']")
	private WebElement btnOk;
	
	
	/*-------------------------------------------------------- Page actions ---------------------------------------------------- */
	/*Method: setRadioYes
	 Description : To set the value of input(radio) radioYes.
	 Parameter : None
	 Return type : WebElement */
	public WebElement setRadioYes(){
		WebElement wePh = radioYes; // WebElement object
		String webElementName = "radioYes"; // WebElement object name string
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(radioYes));
		
			try {
				wePh.click();
				Log.info("Passed : "+ NextStepPromoPage.class.getName() + "- Radio button : " + webElementName + " is set.");
			} catch(NoSuchElementException e) {
				e.printStackTrace();
				Log.info("Failed :" + NextStepPromoPage.class.getName() + "- Radio button : " + webElementName + " not found.");
			}
		
		
		return wePh;
	}
	
	/*Method: setRadioNo
	 Description : To set the value of input(radio) radioNo.
	 Parameter : None
	 Return type : WebElement */
	public WebElement setRadioNo(){
		WebElement wePh = radioNo; // WebElement object
		String webElementName = "radioNo"; // WebElement object name string
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(radioNo));
		 
			try {
				wePh.click();
				Log.info("Passed : "+ NextStepPromoPage.class.getName() + "- Radio button : " + webElementName + " is set.");
			} catch(NoSuchElementException e) {
				e.printStackTrace();
				Log.info("Failed :" + NextStepPromoPage.class.getName() + "- Radio button : " + webElementName + " not found.");
			}
		
		return wePh;
	}
	
	/*Method: clickBtnOk
	Description : To click on  button btnOk.
	Parameter : None
	Return type : void */
	public CssPage clickBtnOk()
	{
		WebElement wePh = btnOk; // WebElement object 
		String webElementName = "btnOk"; // WebElement object name string
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(btnOk));

		try {
			wePh.click();
			Log.info("Passed : "+ NextStepPromoPage.class.getName() + "- Button : " + webElementName + " is clicked.");
			} catch(NoSuchElementException e) {
			e.printStackTrace();
			Log.info("Failed :" + NextStepPromoPage.class.getName() + "- Button : " + webElementName + " not found.");
			}
		return new CssPage(driver);
	}


	
}
