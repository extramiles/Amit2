 /* ClassName            : PcaPage
  * Description          : This class identify and implement all the web
  *                        element and its corresponding action of Home Page.
  * Version info         : V_0.1
  * Author               : Tech Mahindra
  * Copyright notice     : Tech Mahindra Ltd. 
  */

package com.pageobject;

import java.util.NoSuchElementException;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.utility.Logg;
import com.utility.Util;

public class PcaPage {

	 Util u = new Util();
	 WebDriver driver = u.getDriver();
	 Logger l = Logg.createLogger();
	
	// Constructor for class PcaPage
	public PcaPage(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver,this);
	}
	
	/* Web Element Locator for Wireless Product */ 
	@FindBy(how=How.XPATH, using = "//div/div[2][text()='Service Profile For New Customer ']") 
	public WebElement pcaHeader;
	// Select Wireless checkbox
	@FindBy(how=How.ID, using = "productWirelessSelected") 
	public WebElement selectWireless;
	
	// Select Postpaid Radio Button
	@FindBy(how=How.ID, using = "wirelessAcctType_1") 
	public WebElement selectPostpaid;
	
	// Select Prepaid Radio Button
	@FindBy(how=How.ID, using = "wirelessAcctType_2") 
	public WebElement selectPrepaid;
	
	// Select Port Number Yes Radio Button
	@FindBy(how=How.ID, using = "portYes_3") 
	public WebElement selectPortNumberYes;
		
	// Select Port Number No Radio Button
	@FindBy(how=How.ID, using = "portNo_4") 
	public WebElement selectPortNumberNo;
	
	
	/* Select begin order Button   */
	@FindBy(how=How.ID, using = "begin")
	public WebElement beginOrder;
	
	
	/* Function Name    : SelectWireless
	 * Description      : This function is implemented to select wireless
	 *                    product.
	 * Parameter        : None 
	 * Return           : Web element 
	 */
	public PcaPage SelectWireless() {
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(selectWireless));
		if (selectWireless!=null) {
			try {
				selectWireless.click();
				l.info("Passed " + PcaPage.class.getName()+ " click on button ");
			} catch(NoSuchElementException e) {
					e.printStackTrace();
					l.info("Failed " + PcaPage.class.getName()+ " unable to click on button ");
			}
		}
		return PageFactory.initElements(driver, PcaPage.class);	
	}
	
	/* Function Name    : SelectPostpaidPlan
	 * Description      : This function is implemented to select Postpaid plan
	 * Parameter        : None 
	 * Return           : Web element 
	 */
	public PcaPage SelectPostpaidPlan() {
		if (selectPostpaid!=null) {
			try {
				selectPostpaid.click();
				l.info("Passed " + PcaPage.class.getName()+ " click on button ");
			} catch(NoSuchElementException e) {
					e.printStackTrace();
					l.info("Failed " + PcaPage.class.getName()+ " unable to click on button ");
			}
		}
		return PageFactory.initElements(driver, PcaPage.class);	
	}
	
	/* Function Name    : SelectPPrepaidPlan
	 * Description      : This function is implemented to select Prepaid plan
	 * Parameter        : None 
	 * Return           : Web element 
	 */
	public PcaPage SelectPPrepaidPlan() {
		if (selectPrepaid!=null) {
			try {
				selectPrepaid.click();
				l.info("Passed " + PcaPage.class.getName()+ " click on button ");
			} catch(NoSuchElementException e) {
					e.printStackTrace();
					l.info("Failed " + PcaPage.class.getName()+ " unable to click on button ");
			}
		}
		return PageFactory.initElements(driver, PcaPage.class);	
	}
	
	/* Function Name    : SetPortNumberYes
	 * Description      : This function is implemented to select Porting number
	 *                    as true.
	 * Parameter        : None 
	 * Return           : Web element 
	 */
	public PcaPage SetPortNumberYes() {
		if (selectPortNumberYes!=null) {
			try {
				selectPortNumberYes.click();
				l.info("Passed " + PcaPage.class.getName()+ " click on button ");
			} catch(NoSuchElementException e) {
					e.printStackTrace();
					l.info("Failed " + PcaPage.class.getName()+ " unable to click on button ");
			}
		}
		return PageFactory.initElements(driver, PcaPage.class);	
	}
	
	/* Function Name    : SetPortNumberNo
	 * Description      : This function is implemented to select Porting number
	 *                    as false.
	 * Parameter        : None 
	 * Return           : Web element 
	 */
	public PcaPage SetPortNumberNo() {
		if (selectPortNumberNo!=null) {
			try {
				selectPortNumberNo.click();
				l.info("Passed " + PcaPage.class.getName()+ " click on button ");
			} catch(NoSuchElementException e) {
					e.printStackTrace();
					l.info("Failed " + PcaPage.class.getName()+ " unable to click on button ");
			}
		}
		return PageFactory.initElements(driver, PcaPage.class);	
	}
	
	/* Function Name    : ClickBeginOrder
	 * Description      : This function is implemented to click on begin order
	 * Parameter        : None 
	 * Return           : Web element 
	 */
	public PcaPage ClickBeginOrder() {
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(beginOrder));
		if (beginOrder.isEnabled()) {
			try {
				beginOrder.click();
				l.info("Passed " + PcaPage.class.getName()+ " click on button ");
			} catch(Exception e) {
					e.printStackTrace();
			}
		}
		else
		{
			l.info("Failed " + PcaPage.class.getName()+ " unable to click on button ");
		}
		return PageFactory.initElements(driver, PcaPage.class);	
	}

} // class PcaPage ends here
