/*
Description : This class identify and implement all the web
element and its corresponding action of Wireless customer agreement page
Consent page.
Version info : V_0.1
Date : 06/06/2017
Author : Devendra Bhavsar
Copyright notice : Tech Mahindra Ltd
 */
package com.pageobject;

import java.util.NoSuchElementException;
import java.util.Set;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.utility.Logg;
import com.utility.Util;

public class WcaPage {
	Util u = new Util();
	WebDriver driver = u.getDriver();
	Logger Log = Logg.createLogger();

	public WcaPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver,this);
	}
		
	
/*-------------------------------------------------------- Page objects ---------------------------------------------------- */
	
	@FindBy(how = How.ID, using = "emailSigCapButtonId")
	private WebElement btnUseStation;
	
	/*@FindBy(how = How.XPATH, using ="//div/div[7]/div[@class='value ml20']/following-sibling::table/tbody/tr/td[1]/input[@name='wcaAcknowledged']")
	private WebElement chkboxWcaAcknowledged;*/
	@FindBy(how = How.NAME, using ="wcaAcknowledged")
	private WebElement chkboxWcaAcknowledged;
	
	@FindBy(how = How.NAME, using = "emailBoxChecked")
	private WebElement chkboxEmailBox;
	
	@FindBy(how = How.ID, using = "emailAddress")
	private WebElement textEmailAdd;
	
	@FindBy(how = How.XPATH, using = "//button[@id='btnSkip']/b/em/u[text()='Skip']")
	private WebElement btnSkip;
	
	@FindBy(how = How.ID, using = "btnNext")
	private WebElement btnNext;
	
	@FindBy(how = How.ID, using = "btnOk")
	private WebElement btnOk;
	
	@FindBy(how = How.XPATH, using = "//div/div/input[@id='dfAcknowledged']")
	private WebElement chkboxDfAcknowledged;
	
	@FindBy(how = How.ID, using = "btnUpg")
	private WebElement btnDFOk;
	
	
	/*-------------------------------------------------------- Page actions ---------------------------------------------------- */
	/*Method: clickBtnUseStation
	Description : To click on  button btnUseStation.
	Parameter : None
	Return type : void */
	public void clickBtnUseStation()
	{
		WebElement wePh = btnUseStation; // WebElement object 
		String webElementName = "btnUseStation"; // WebElement object name string
		try {
			wePh.click();
			Log.info("Passed : "+ WcaPage.class.getName() + "- Button : " + webElementName + " is clicked.");
			} catch(NoSuchElementException e) {
			e.printStackTrace();
			Log.info("Failed :" + WcaPage.class.getName() + "- Button : " + webElementName + " not found.");
			}
	}
	
	/*Method: setChkboxWcaAcknowledged
	 Description : To set the value of input(check box) chkboxWcaAcknowledged.
	 Parameter : None
	 Return type : WebElement */
	public WebElement setChkboxWcaAcknowledged(){
				WebElement wePh = chkboxWcaAcknowledged; // WebElement object
				String webElementName = "chkboxWcaAcknowledged"; // WebElement object name string
				/*String parent =	u.getMainWindowHandle(driver);
				System.out.println("name of parent window: "+ parent);
*/			
				u.closeAllOtherWindows(driver);
			
				
				//Set<String> allwindow=u.getMultipleWindow(driver);
				//System.out.println("child window close:");
				u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(chkboxWcaAcknowledged));
		
			try {
				chkboxWcaAcknowledged.click();
				Log.info("Passed : "+ WcaPage.class.getName() + "- CheckBox : " + webElementName + " is enabled.");
			} catch(NoSuchElementException e) {
				e.printStackTrace();
				Log.info("Failed :" + WcaPage.class.getName() + "- CheckBox : " + webElementName + " not found.");
			}
	
		return wePh;
	}
	
	/*Method: setChkboxEmailBox
	 Description : To set the value of input(check box) chkboxEmailBox.
	 Parameter : None
	 Return type : WebElement */
	public WebElement setChkboxEmailBox(){
		WebElement wePh = chkboxEmailBox; // WebElement object
				String webElementName = "chkboxEmailBox"; // WebElement object name string
		if(wePh.isEnabled()){
			try {
				wePh.click();
				Log.info("Passed : "+ WcaPage.class.getName() + "- CheckBox : " + webElementName + " is checked.");
			} catch(NoSuchElementException e) {
				e.printStackTrace();
				Log.info("Failed :" + WcaPage.class.getName() + "- CheckBox : " + webElementName + " not found.");
			}
		}
		else{
			Log.info("Failed :" + WcaPage.class.getName() + "- CheckBox : " + webElementName + " is disabled.");
		}
		return wePh;
	}
	
	/*Method: setTextEmailAdd
	 Description : To set the value of input(text) textEmailAdd.
	 Parameter : @value - 
	 Return type : WebElement */
	
	public WebElement setTextEmailAdd(String value)
	{
		WebElement wePh = textEmailAdd; // WebElement object 
		String webElementName = "textEmailAdd"; // WebElement object name string
		if(value!=null){
			try
			{
				wePh.clear();
				Log.info("Passed : "+ WcaPage.class.getName() + "- Textbox : " + webElementName + " is cleared.");
				wePh.sendKeys(value);
				Log.info("Passed : "+ WcaPage.class.getName() + "- Textbox : " + webElementName + " is set to " + value + ".");
			}
			catch(NoSuchElementException e)
			{
				e.printStackTrace();
				Log.info("Failed :" + WcaPage.class.getName() + "- Textbox : " + webElementName + " not found.");
			}
		}
		return wePh;
	}
	
	/*Method: clickBtnSkip
	Description : To click on  button btnSkip.
	Parameter : None
	Return type : void */
	public WcaNewActPage clickBtnSkip()
	{
		WebElement wePh = btnSkip; // WebElement object 
		String webElementName = "btnSkip"; // WebElement object name string
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(btnSkip));
		try {
			wePh.click();
			Log.info("Passed : "+ WcaPage.class.getName() + "- Button : " + webElementName + " is clicked.");
			} catch(NoSuchElementException e) {
			e.printStackTrace();
			Log.info("Failed :" + WcaPage.class.getName() + "- Button : " + webElementName + " not found.");
			}
		return new WcaNewActPage(driver);
	}
	
	/*Method: click
	Description : To click on  button.
	Parameter : None
	Return type : void */
	public void clickBtnNext()
	{
		WebElement wePh = btnNext; // WebElement object 
		String webElementName = "btnNext"; // WebElement object name string
		try {
			wePh.click();
			Log.info("Passed : "+ WcaPage.class.getName() + "- Button : " + webElementName + " is clicked.");
			} catch(NoSuchElementException e) {
			e.printStackTrace();
			Log.info("Failed :" + WcaPage.class.getName() + "- Button : " + webElementName + " not found.");
			}
	}
	
	
	/*Method: clickBtnOk
	Description : To click on  button btnOk.
	Parameter : None
	Return type : void */
	public void clickBtnOk()
	{
		WebElement wePh = btnOk; // WebElement object 
		String webElementName = "btnOk"; // WebElement object name string
		try {
			wePh.click();
			Log.info("Passed : "+ WcaPage.class.getName() + "- Button : " + webElementName + " is clicked.");
			} catch(NoSuchElementException e) {
			e.printStackTrace();
			Log.info("Failed :" + WcaPage.class.getName() + "- Button : " + webElementName + " not found.");
			}
		//return new CssPage(driver);
	}
	
	/*Method: setChkboxDfAcknowledged
	 Description : To set the value of input(check box) chkboxDfAcknowledged.
	 Parameter : None
	 Return type : WebElement */
	public WebElement setChkboxDfAcknowledged(){
		WebElement wePh = chkboxDfAcknowledged; // WebElement object
				String webElementName = "chkboxDfAcknowledged"; // WebElement object name string
		if(wePh.isEnabled()){
			try {
				wePh.click();
				Log.info("Passed : "+ WcaPage.class.getName() + "- CheckBox : " + webElementName + " is checked.");
			} catch(NoSuchElementException e) {
				e.printStackTrace();
				Log.info("Failed :" + WcaPage.class.getName() + "- CheckBox : " + webElementName + " not found.");
			}
		}
		else{
			Log.info("Failed :" + WcaPage.class.getName() + "- CheckBox : " + webElementName + " is disabled.");
		}
		return wePh;
	}
	
	/*Method: clickBtnDFOk
	Description : To click on  button btnDFOk.
	Parameter : None
	Return type : void */
	public void clickBtnDFOk()
	{
		WebElement wePh = btnDFOk; // WebElement object 
		String webElementName = "btnDFOk"; // WebElement object name string
		try {
			wePh.click();
			Log.info("Passed : "+ WcaPage.class.getName() + "- Button : " + webElementName + " is clicked.");
			} catch(NoSuchElementException e) {
			e.printStackTrace();
			Log.info("Failed :" + WcaPage.class.getName() + "- Button : " + webElementName + " not found.");
			}
	}
	
	
}
