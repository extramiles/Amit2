package com.pageobject;

import java.util.NoSuchElementException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;


import com.utility.Logg;
import com.utility.Util;

public class CustomerSignPage {

	Util u = new Util();
	//WebDriver driver;
	
	WebDriver driver = u.getDriver();
	org.apache.log4j.Logger Log = Logg.createLogger();	
	String webElementName;
	
	public CustomerSignPage(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver,this);
	}	
	
	@FindBy(how=How.ID, using = "useStation") 
	public WebElement btnUseStation;
	
	@FindBy(how=How.ID, using = "btnView") 
	public WebElement btnViewSign;
	
	@FindBy(how=How.ID, using = "btnClear") 
	public WebElement btnClearSign;
	
	@FindBy(how=How.ID, using = "btnSkip") 
	public WebElement btnSkip;
	
	@FindBy(how=How.ID, using = "btnContinue") 
	public WebElement btnSubmit;


	/*
	 * Method: public void clickUseStation() Description : To click on Use Station
	 * button. Parameter : None Return type : Void
	 */
	public void clickUseStation() {
		webElementName = "btnUseStation";
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(btnUseStation));
		try {
			btnUseStation.click();
			Log.info("Passed" + CustomerSignPage.class.getName() + ","
					+ "Use Station button clicked");
		} catch (NoSuchElementException e) {
			e.printStackTrace();
			Log.info("Failed" + CustomerSignPage.class.getName() + webElementName
					+ " not found ");
		}
		
	}	
	
	/*
	 * Method: public void clickViewSign() Description : To click on View Signature
	 * button. Parameter : None Return type : Void
	 */
	public void clickViewSign() {
		webElementName = "btnViewSign";
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(btnViewSign));
		try {
			btnViewSign.click();
			Log.info("Passed" + CustomerSignPage.class.getName() + ","
					+ "View Signature button clicked");
		} catch (NoSuchElementException e) {
			e.printStackTrace();
			Log.info("Failed" + CustomerSignPage.class.getName() + webElementName
					+ " not found ");
		}
		
	}	
	
	
	
	/*
	 * Method: public void clickClearSignature() Description : To click on Clear Signature
	 * button. Parameter : None Return type : Void
	 */
	public void clickClearSignature() {
		webElementName = "btnClearSign";
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(btnClearSign));
		try {
			btnClearSign.click();
			Log.info("Passed" + CustomerSignPage.class.getName() + ","
					+ "Clear Station button clicked");
		} catch (NoSuchElementException e) {
			e.printStackTrace();
			Log.info("Failed" + CustomerSignPage.class.getName() + webElementName
					+ " not found ");
		}
		
	}	
	
	/*
	 * Method: public void clickSubmit() Description : To click on Submit
	 * button. Parameter : None Return type : Void
	 */
	public void clickSubmit() {
		webElementName = "btnSubmit";
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(btnSubmit));
		try {
			btnSubmit.click();
			Log.info("Passed" + CustomerSignPage.class.getName() + ","
					+ "Submit button clicked");
		} catch (NoSuchElementException e) {
			e.printStackTrace();
			Log.info("Failed" + CustomerSignPage.class.getName() + webElementName
					+ " not found ");
		}
		
	}	
	
	/*
	 * Method: public void clickSkip() Description : To click on Skip
	 * button. Parameter : None Return type : Void
	 */
	public TaxTypeInfoPage clickSkip() {
		webElementName = "btnSkip";
		u.waitForElement(driver).until(ExpectedConditions.elementToBeClickable(btnSkip));
		try {
			btnSkip.click();
			Log.info("Passed" + CustomerSignPage.class.getName() + ","
					+ "Skip button clicked");
		} catch (NoSuchElementException e) {
			e.printStackTrace();
			Log.info("Failed" + CustomerSignPage.class.getName() + webElementName
					+ " not found ");
		}
		return new TaxTypeInfoPage(driver);
	}	
	
}
