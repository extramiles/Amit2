package com.pageobject;

import java.util.NoSuchElementException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.opusbase.TestBase;

import com.utility.Logg;
import com.utility.Util;

/* ClassName : StoreSelectPage
Description : This class identify and implement all the web
element and its corresponding action of StoreSelectPage
Consent page.
Version info : V_0.1
Date : 01/06/2017
Author : Tech Mahindra
*/

public class StoreSelectPage extends CommonPageAction{
	
		
	 private String storeTitle="OPUS Login";
	 Util u = new Util();
	 org.apache.log4j.Logger l = Logg.createLogger();
	
	public StoreSelectPage(WebDriver driver)
	{
		super(driver);
		this.driver=driver;
		
		
		PageFactory.initElements(driver, this);
	}
	@FindBy(how=How.NAME,using="homeURL")
	private WebElement store;
	
	@FindBy(how=How.ID,using="btnLogin")
	private WebElement loginbutton;
	
	
	//@Override
	
	/*Function Name : selectDropDownsd
	Description : To slect store from dropdown
	under store dropdown.
	Parameter :
	@setAddressvalue : Parameter to hold input value of dropdown
	Return : None
	**/
	
	public  WebElement selectDropDownsd(String value) 
	{
			u.waitForElement(driver).until(ExpectedConditions.visibilityOf(store));
		
		if(store!=null)
		{
			try{
				Select stores=new Select(store);
				stores.selectByVisibleText(value);
				//store.sendKeys(value);
				l.info("store " + value + " selected from " + StoreSelectPage.class.getName());
			}
			catch(NoSuchElementException e){
				e.printStackTrace();
				l.info("Failed Store " + value  + "Not Found in " + StoreSelectPage.class.getName());
			}
		}
		return loginbutton;
		
	}
	
	/*Function Name : enterSearchFor
	Description : To provide input of address of fist text box for address
	under text boxes.
	Parameter :
	@setAddressvalue : Parameter to hold input value of address
	Return : None
	**/
	public LoginPageObject click() {
		// TODO Auto-generated method stub
		
		if(loginbutton!=null)
		{
			try
			{
				loginbutton.click();
				l.info(StoreSelectPage.class.getName()+ " button click");
			}
			catch(NoSuchElementException e)
			{
				e.printStackTrace();
				l.info("Failed " + StoreSelectPage.class.getName()+ " unable to click on button ");
			}
		}
		return PageFactory.initElements(driver, LoginPageObject.class);	

	
	}
	
	/*Function Name : getStoreSelectionPageTitle
	Description : To provide input of address of fist text box for address
	under text boxes.
	Parameter :
	@setAddressvalue : Parameter to hold input value of address
	Return : None
	**/
   public String getStoreSelectionPageTitle(){
	   String title=driver.getTitle();
		l.info(StoreSelectPage.class.getName()+ " getting page title ");
	   return title;
	   
   }
	
   /*Function Name : enterSearchFor
	Description : To provide input of address of fist text box for address
	under text boxes.
	Parameter :
	@setAddressvalue : Parameter to hold input value of address
	Return : None
	**/
	public boolean verifyStoreSelectionPageTitle(String storeTitle)
	{
		l.info(StoreSelectPage.class.getName()+ " Verifying store page title ");
		return getStoreSelectionPageTitle().contains(storeTitle);
	}


}
