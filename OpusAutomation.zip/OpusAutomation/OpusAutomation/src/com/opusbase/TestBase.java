package com.opusbase;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.ITestContext;

import com.excelutils.ReadingExcel;
import com.otherutil.DataSet;
import com.utility.Util;

public class TestBase extends Util 
{
	Properties con = new Properties();
	private File f=null;
	private FileInputStream fis =null;
	//File ef;
	//FileInputStream fi;
	String s;
	DataSet dataread;
	//Properties p = new Properties();
	

	public void setUp() throws InterruptedException
	{
		
		//PropertyConfigurator.configure(System.getProperty("user.dir")+"/Log4j.properties");
		loadPropertyFile();
		connectDatabase();
		/* s = p.getProperty("log4j.appender.dest1.File");
		System.out.println(s);*/
		SelectBrowser(con.getProperty("browser"));
		launchUrl(con.getProperty("opusurl"));
		//Thread.sleep(30000);	
		//driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
	}
	
	public void loadPropertyFile()
	{
		try
		{
		f = new File(System.getProperty("user.dir")+"/Config/config.properties");
		fis = new FileInputStream(f);
		con.load(fis);
		/* ef = new File(System.getProperty("user.dir")+"/Log4j.properties");
		 fi = new FileInputStream(ef);
		p.load(fi);*/
		//connectDatabase(con);
		}
		catch(FileNotFoundException fne)
		{
			fne.printStackTrace();
		}
		catch(IOException fne)
		{
			fne.printStackTrace();
		}
	}
	
	public static String[] getDataFromExcel(String testcasename,String sheetname)
	{
		LinkedList<String> d = ReadingExcel.testData(testcasename,sheetname);
		
		Object[] exceldata = d.toArray();
		String[] s = new String[exceldata.length];
		for(int i = 0;i<exceldata.length;i++){
			s[i]=(String) exceldata[i];
		}
		
		return s;
	}
	
	public void createLogFile(String d,String testname){
		File file = new File("d:/sampleFile.txt");

	}
	
	public void connectDatabase()
	{
		//System.out.println(con.getProperty("conurl"));
		 dataread = new DataSet(con.getProperty("conurl"),con.getProperty("dburl"),
			     con.getProperty("username"),con.getProperty("password"));
		System.out.println("database connected");
	}
	
	
	public void DataValidation(){
		
		HashMap<Integer, String> colData = new HashMap<Integer, String>();
		
		try {
			colData=dataread.ExecQuery(1,"select rl_number,cs_id from wg_trans_log");
			Set set = colData.entrySet();
			Iterator i = set.iterator();
			
			while(i.hasNext()){
			  Map.Entry me= (Map.Entry)i.next();
			  System.out.print(me.getKey() + ": ");
			  System.out.println(me.getValue());
			}
				System.out.println(); 
			
		} catch (Exception e) {
			e.printStackTrace();
		}

	}
	
	
	public String verifyTransactions(String csid,int colindex){
		//d = new DataSet();
					/*try {
						Thread.sleep(10000);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}*/
		String query= "select cs_id from wg_trans_log where cs_id = '"+csid+"'";
	String s=	dataread.ExecDbQuery(query,colindex);
	return s;
	}
	
	public void tearDown()
	{
		driver.close();
		driver.quit();
	}
	
}
